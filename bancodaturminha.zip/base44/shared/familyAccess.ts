// Limite de tentativas para o acesso da família (código da turma + login + nascimento),
// compartilhado por entrarFamilia e registrarTarefa.
const WINDOW_MINUTES = 10;
const MAX_FAILURES_PER_CLIENT = 6;
const MAX_FAILURES_PER_CODE = 30;

export const FAMILY_NOT_FOUND =
  'Não encontramos essa ficha. Confira o código da turma, o login e a data de aniversário.';

export const TOO_MANY_TRIES = 'Muitas tentativas em pouco tempo. Espere alguns minutos e tente de novo.';

// A chave do limite não pode sair de cabeçalhos que o cliente escolhe (x-forwarded-for
// e x-real-ip). Usa o usuário autenticado quando existe e, para visitantes, o IP real
// atribuído pela plataforma; sem ele, todas as chamadas dividem o mesmo balde — o que
// deixa o limite mais rígido, nunca mais frouxo.
export const familyClientKey = (req, user, prefix = 'familia') => {
  if (user?.id) return `${prefix}:${user.id}`;
  const ip = String(req.headers.get('cf-connecting-ip') || '').trim();
  return `${prefix}:${ip || 'sem-ip'}`;
};

export async function familyRateLimited(base44, key, classCode) {
  const since = new Date(Date.now() - WINDOW_MINUTES * 60000).toISOString();
  const [byClient, byCode] = await Promise.all([
    base44.asServiceRole.entities.ClassCodeAttempt.count({ user_id: key, at: { $gte: since } }),
    classCode
      ? base44.asServiceRole.entities.ClassCodeAttempt.count({ code: classCode, at: { $gte: since } })
      : Promise.resolve(0),
  ]);
  return byClient >= MAX_FAILURES_PER_CLIENT || byCode >= MAX_FAILURES_PER_CODE;
}

export async function recordFamilyFailure(base44, key, classCode) {
  await base44.asServiceRole.entities.ClassCodeAttempt.create({
    user_id: key,
    code: classCode || '',
    at: new Date().toISOString(),
  }).catch(() => null);
}