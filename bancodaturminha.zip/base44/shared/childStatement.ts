const sumOf = (agg) => Number((agg.rows || [])[0]?.sum_amount) || 0;

const toTx = (tx) => ({
  id: tx.id,
  type: tx.type,
  category: tx.category,
  amount: tx.amount,
  description: tx.description,
  date: tx.date,
});

export async function buildChildStatement(base44, child, weekStart, weekEnd) {
  const [recent, weekTxs, marks, badges, ganhos, gastos] = await Promise.all([
    base44.asServiceRole.entities.Transaction.filter(
      { child_id: child.id },
      { sort: '-date', limit: 20 }
    ),
    base44.asServiceRole.entities.Transaction.filter(
      { child_id: child.id, date: { $gte: weekStart, $lte: weekEnd } },
      { limit: 200 }
    ),
    base44.asServiceRole.entities.LearningMark.filter(
      { child_id: child.id },
      { sort: '-week_start', limit: 4 }
    ),
    base44.asServiceRole.entities.Badge.filter(
      { child_id: child.id },
      { sort: '-date', limit: 12 }
    ),
    base44.asServiceRole.entities.Transaction.aggregate({
      query: { child_id: child.id, type: 'ganho' },
      sum: ['amount'],
    }),
    base44.asServiceRole.entities.Transaction.aggregate({
      query: { child_id: child.id, type: 'gasto' },
      sum: ['amount'],
    }),
  ]);

  let weekGanho = 0;
  let weekGasto = 0;
  for (const tx of weekTxs.items || []) {
    const amount = Number(tx.amount) || 0;
    if (tx.type === 'gasto') weekGasto += amount;
    else weekGanho += amount;
  }

  return {
    id: child.id,
    name: child.name,
    nickname: child.nickname,
    login: child.login || '',
    symbol: child.symbol,
    cover: child.cover,
    card_code: child.card_code,
    class_id: child.class_id || '',
    saldo: sumOf(ganhos) - sumOf(gastos),
    week_ganho: weekGanho,
    week_gasto: weekGasto,
    learning: (marks.items || []).map((m) => ({
      id: m.id,
      week_start: m.week_start,
      skills: m.skills || [],
      note: m.note || '',
    })),
    badges: (badges.items || []).map((b) => ({
      id: b.id,
      badge_id: b.badge_id,
      note: b.note || '',
      date: b.date,
    })),
    transactions: (recent.items || []).map(toTx),
    week_transactions: (weekTxs.items || [])
      .slice()
      .sort((a, b) => String(a.date).localeCompare(String(b.date)))
      .map(toTx),
  };
}

export const normalizeLogin = (value) =>
  String(value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();

export const normalizeClassCode = (value) =>
  String(value || '')
    .toUpperCase()
    .normalize('NFD')
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 12);