import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { normalizeClassCode, normalizeLogin } from '../../shared/childStatement.ts';
import { TOO_MANY_TRIES, familyClientKey, familyRateLimited, recordFamilyFailure } from '../../shared/familyAccess.ts';

const pad = (n) => String(n).padStart(2, '0');
const isoDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);

    let user = null;
    try {
      user = await base44.auth.me();
    } catch {
      user = null;
    }
    const body = await req.json().catch(() => ({}));
    const childId = String(body.child_id || '').slice(0, 40);
    const taskId = String(body.task_id || '').slice(0, 40);
    const note = String(body.note || '').trim().slice(0, 120);

    if (!childId || !taskId) {
      return Response.json({ error: 'Escolha a criança e a tarefa.' }, { status: 400 });
    }

    const child = await base44.asServiceRole.entities.Child.get(childId).catch(() => null);
    let mine = false;
    if (user?.id && child) {
      mine =
        child.guardian_user_id === user.id ||
        (child.guardian_email && child.guardian_email === user.email);
    }
    if (!mine && child) {
      // Família que entrou com código da turma + login + data de aniversário.
      const classCode = normalizeClassCode(body.class_code);
      const login = normalizeLogin(body.login);
      const birthDate = String(body.birth_date || '').trim();
      if (classCode && login && /^\d{4}-\d{2}-\d{2}$/.test(birthDate)) {
        const attemptKey = familyClientKey(req, user);
        if (await familyRateLimited(base44, attemptKey, classCode)) {
          return Response.json({ error: TOO_MANY_TRIES }, { status: 429 });
        }
        const turmas = await base44.asServiceRole.entities.Turma.filter({ code: classCode }, { limit: 5 });
        const turma = (turmas.items || []).find((t) => t.active !== false);
        mine = Boolean(
          turma &&
            turma.id === child.class_id &&
            normalizeLogin(child.login) === login &&
            String(child.birth_date || '') === birthDate
        );
        if (!mine) await recordFamilyFailure(base44, attemptKey, classCode);
      }
    }
    if (!mine) {
      return Response.json({ error: 'Essa criança não está vinculada ao seu acesso.' }, { status: 403 });
    }

    const task = await base44.asServiceRole.entities.Task.get(taskId).catch(() => null);
    if (!task || task.active === false) {
      return Response.json({ error: 'Essa tarefa está indisponível.' }, { status: 400 });
    }
    if (task.class_id && task.class_id !== (child.class_id || '')) {
      return Response.json({ error: 'Essa tarefa não é da turma dessa criança.' }, { status: 400 });
    }

    const amount = Number(task.value) || 0;
    if (amount <= 0) {
      return Response.json({ error: 'Essa tarefa ainda está sem valor.' }, { status: 400 });
    }

    const today = isoDate(new Date());
    const todays = await base44.asServiceRole.entities.Transaction.filter(
      { child_id: child.id, date: today, category: 'tarefa' },
      { limit: 100 }
    );
    const taskTitleOf = (description) =>
      String(description || '')
        .replace(/ \(casa\)$/, '')
        .split(' · ')[0];
    const alreadyDone = (todays.items || []).some((tx) => taskTitleOf(tx.description) === task.title);
    if (alreadyDone) {
      return Response.json(
        { error: 'Essa tarefa já foi registrada hoje para essa criança.' },
        { status: 409 }
      );
    }

    const transaction = await base44.asServiceRole.entities.Transaction.create({
      child_id: child.id,
      child_name: child.name,
      class_id: child.class_id || '',
      type: 'ganho',
      category: 'tarefa',
      amount,
      description: `${task.title}${note ? ` · ${note}` : ''} (casa)`,
      date: isoDate(new Date()),
    });

    return Response.json({ ok: true, amount, title: task.title, transaction_id: transaction.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}