import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { buildChildStatement, normalizeClassCode, normalizeLogin } from '../../shared/childStatement.ts';
import {
  FAMILY_NOT_FOUND,
  TOO_MANY_TRIES,
  familyClientKey,
  familyRateLimited,
  recordFamilyFailure,
} from '../../shared/familyAccess.ts';

const pad = (n) => String(n).padStart(2, '0');
const isoDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));

    const classCode = normalizeClassCode(body.class_code);
    const login = normalizeLogin(body.login);
    const birthDate = String(body.birth_date || '').trim();

    if (!classCode || !login || !/^\d{4}-\d{2}-\d{2}$/.test(birthDate)) {
      return Response.json(
        { error: 'Informe o código da turma, o login e a data de aniversário.' },
        { status: 400 }
      );
    }

    let user = null;
    try {
      user = await base44.auth.me();
    } catch {
      user = null;
    }
    const attemptKey = familyClientKey(req, user);

    if (await familyRateLimited(base44, attemptKey, classCode)) {
      return Response.json({ error: TOO_MANY_TRIES }, { status: 429 });
    }

    const turmas = await base44.asServiceRole.entities.Turma.filter({ code: classCode }, { limit: 5 });
    const turma = (turmas.items || []).find((t) => t.active !== false);
    if (!turma) {
      await recordFamilyFailure(base44, attemptKey, classCode);
      return Response.json({ error: FAMILY_NOT_FOUND }, { status: 404 });
    }

    const children = await base44.asServiceRole.entities.Child.filter(
      { class_id: turma.id },
      { limit: 200 }
    );

    const child = (children.items || []).find((c) => {
      if (c.active === false) return false;
      const matchesLogin =
        normalizeLogin(c.login) === login ||
        (!c.login && (normalizeLogin(c.nickname) === login || normalizeLogin(c.name) === login));
      return matchesLogin && String(c.birth_date || '') === birthDate;
    });

    if (!child) {
      await recordFamilyFailure(base44, attemptKey, classCode);
      return Response.json({ error: FAMILY_NOT_FOUND }, { status: 404 });
    }

    const today = new Date();
    const weekday = today.getDay();
    const monday = new Date(today);
    monday.setDate(today.getDate() + (weekday === 0 ? -6 : 1 - weekday));

    const statement = await buildChildStatement(base44, child, isoDate(monday), isoDate(today));

    return Response.json({
      child: statement,
      class_name: turma.name || '',
      class_code: turma.code || classCode,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}