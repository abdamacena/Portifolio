import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { normalizeLogin } from '../../shared/childStatement.ts';
import { familyClientKey } from '../../shared/familyAccess.ts';

const SYMBOLS = ['🐻', '🐰', '🦊', '🐸', '🐱', '🐶', '🦁', '🐼', '🐨', '🐧', '🦄', '🐢', '🐝', '🐙', '🦋', '🐠'];
const COVERS = ['manga', 'menta', 'coral', 'lilas', 'tinta'];
const MAX_CHILDREN_PER_ACCOUNT = 4;
const CODE_WINDOW_MINUTES = 10;
const MAX_WRONG_CODES = 8;

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));

    let user = null;
    try {
      user = await base44.auth.me();
    } catch {
      user = null;
    }
    const requesterKey = familyClientKey(req, user, 'ficha');

    const text = (value, max) => String(value ?? '').trim().slice(0, max);
    const name = text(body.name, 80);
    const nickname = text(body.nickname, 30);
    const guardianName = text(body.guardian_name, 80);
    const contact = text(body.guardian_contact, 40);
    const email = text(user?.email || body.guardian_email, 120);
    const birthDate = /^\d{4}-\d{2}-\d{2}$/.test(String(body.birth_date || '')) ? body.birth_date : '';
    const symbol = SYMBOLS.includes(body.symbol) ? body.symbol : '🐻';
    const cover = COVERS.includes(body.cover) ? body.cover : 'manga';
    const login = normalizeLogin(body.login)
      .replace(/\s+/g, '')
      .replace(/[^a-z0-9._-]/g, '')
      .slice(0, 20);

    if (name.length < 2) {
      return Response.json({ error: 'Escreva o nome da criança.' }, { status: 400 });
    }
    if (login.length < 3) {
      return Response.json(
        { error: 'Escolha o login da criança com pelo menos 3 letras ou números.' },
        { status: 400 }
      );
    }
    if (guardianName.length < 2) {
      return Response.json({ error: 'Escreva o nome do responsável.' }, { status: 400 });
    }
    if (contact.length < 8) {
      return Response.json({ error: 'Informe um telefone com DDD.' }, { status: 400 });
    }
    if (body.authorized !== true) {
      return Response.json({ error: 'É preciso autorizar a participação.' }, { status: 400 });
    }
    if (!birthDate) {
      return Response.json(
        { error: 'Informe a data de nascimento: ela confirma o acesso da família ao extrato.' },
        { status: 400 }
      );
    }

    if (user?.id) {
      const mine = await base44.asServiceRole.entities.Child.count({ guardian_user_id: user.id });
      if (mine >= MAX_CHILDREN_PER_ACCOUNT) {
        return Response.json(
          {
            error: `Sua conta já tem ${MAX_CHILDREN_PER_ACCOUNT} fichas. Fale com a professora se precisar incluir outra criança.`,
          },
          { status: 409 }
        );
      }
    }

    const classCode = String(body.class_code ?? '')
      .toUpperCase()
      .normalize('NFD')
      .replace(/[^A-Z0-9]/g, '')
      .slice(0, 12);
    if (!classCode) {
      return Response.json(
        { error: 'Informe o código da turma que a professora passou.' },
        { status: 400 }
      );
    }

    const since = new Date(Date.now() - CODE_WINDOW_MINUTES * 60000).toISOString();
    const wrongCodes = await base44.asServiceRole.entities.ClassCodeAttempt.count({
      user_id: requesterKey,
      at: { $gte: since },
    });
    if (wrongCodes >= MAX_WRONG_CODES) {
      return Response.json(
        { error: 'Muitos códigos errados. Espere alguns minutos e tente de novo com a professora.' },
        { status: 429 }
      );
    }

    const turmas = await base44.asServiceRole.entities.Turma.filter({ code: classCode }, { limit: 1 });
    const turma = (turmas.items || [])[0];
    if (!turma || turma.active === false) {
      await base44.asServiceRole.entities.ClassCodeAttempt.create({
        user_id: requesterKey,
        code: classCode,
        at: new Date().toISOString(),
      });
      return Response.json(
        { error: 'Não encontramos essa turma. Confira o código com a professora.' },
        { status: 400 }
      );
    }

    const existing = await base44.asServiceRole.entities.Child.filter(
      { class_id: turma.id },
      { limit: 200 }
    );
    const used = new Set(
      (existing.items || []).map((child) => Number(child.card_code)).filter((n) => Number.isFinite(n))
    );
    const loginTaken = (existing.items || []).some(
      (child) => normalizeLogin(child.login) === login
    );
    if (loginTaken) {
      return Response.json(
        { error: 'Esse login já está em uso nesta turma. Escolha outro.' },
        { status: 409 }
      );
    }
    let next = 1;
    while (used.has(next)) next += 1;
    const cardCode = String(next).padStart(2, '0');

    const child = await base44.asServiceRole.entities.Child.create({
      name,
      nickname,
      login,
      birth_date: birthDate,
      symbol,
      cover,
      guardian_name: guardianName,
      guardian_contact: contact,
      guardian_email: email,
      guardian_user_id: user?.id || '',
      authorized: true,
      card_code: cardCode,
      class_id: turma.id,
      teacher_user_id: turma.created_by_id || '',
      active: true,
    });

    return Response.json({
      ok: true,
      id: child.id,
      name,
      nickname,
      login,
      symbol,
      cover,
      card_code: cardCode,
      class_name: turma.name,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}