import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { buildChildStatement } from '../../shared/childStatement.ts';

const pad = (n) => String(n).padStart(2, '0');
const isoDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);

    let user = null;
    try {
      user = await base44.auth.me();
    } catch {
      user = null;
    }
    if (!user?.id) {
      return Response.json({ error: 'Entre para ver o extrato.' }, { status: 401 });
    }

    const today = new Date();
    const weekday = today.getDay();
    const monday = new Date(today);
    monday.setDate(today.getDate() + (weekday === 0 ? -6 : 1 - weekday));
    const weekStart = isoDate(monday);
    const weekEnd = isoDate(today);

    const email = String(user.email || '').trim().toLowerCase();
    const emailVariants = email ? [email, email.toUpperCase()] : [];

    const byUser = await base44.asServiceRole.entities.Child.filter(
      { guardian_user_id: user.id },
      { limit: 20 }
    );
    const byEmail = emailVariants.length
      ? await base44.asServiceRole.entities.Child.filter(
          { guardian_email: { $in: emailVariants } },
          { limit: 20 }
        )
      : { items: [] };

    const seen = new Set();
    const children = [];
    for (const child of [...(byUser.items || []), ...(byEmail.items || [])]) {
      if (seen.has(child.id)) continue;
      // Um cadastro já vinculado a outra conta nunca entra pelo e-mail, só pelo dono do vínculo.
      if (child.guardian_user_id && child.guardian_user_id !== user.id) continue;
      // Sem vínculo de conta: entra apenas quando o e-mail do cadastro é o do chamador.
      if (!child.guardian_user_id) {
        const owner = String(child.guardian_email || '').trim().toLowerCase();
        if (!owner || owner !== email) continue;
      }
      seen.add(child.id);
      children.push(child);
    }

    const result = await Promise.all(
      children.map((child) => buildChildStatement(base44, child, weekStart, weekEnd))
    );

    return Response.json({ children: result });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}