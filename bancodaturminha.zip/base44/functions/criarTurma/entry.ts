import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const COLORS = ['manga', 'menta', 'coral', 'lilas', 'tinta'];

const normalizeCode = (value) =>
  String(value || '')
    .toUpperCase()
    .normalize('NFD')
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 12);

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user?.id) {
      return Response.json({ error: 'Entre para criar a turma.' }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const name = String(body.name || '').trim().slice(0, 80);
    const school = String(body.school || '').trim().slice(0, 80);
    const year = String(body.year || '').trim().slice(0, 12);
    const color = COLORS.includes(body.color) ? body.color : 'manga';
    const code = normalizeCode(body.code);

    if (school.length < 2) {
      return Response.json({ error: 'Escreva o nome da escola.' }, { status: 400 });
    }
    if (name.length < 3) {
      return Response.json({ error: 'Escreva o nome da turma, como “Maternal II Amarelo”.' }, { status: 400 });
    }
    if (code.length < 6) {
      return Response.json(
        { error: 'Escolha o código da turma com pelo menos 6 letras ou números.' },
        { status: 400 }
      );
    }

    const existing = await base44.asServiceRole.entities.Turma.filter({ code }, { limit: 1 });
    if ((existing.items || []).length > 0) {
      return Response.json(
        { error: 'Esse código já está em uso em outra turma. Escolha outro para não misturar as crianças.' },
        { status: 409 }
      );
    }

    // Criada como o próprio usuário: a turma fica vinculada à conta da professora.
    const turma = await base44.entities.Turma.create({
      name,
      school,
      year,
      color,
      code,
      teacher_name: String(body.teacher_name || user.full_name || '').trim().slice(0, 80),
      teacher_email: user.email || '',
      active: true,
      created_by_id: user.id,
    });

    return Response.json({ turma });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}