import { Printer } from 'lucide-react';
import Logo from '@/components/brand/Logo';
import CardCover from '@/components/brand/CardCover';
import { symbols } from '@/lib/money';
import { useClassroom } from '@/lib/ClassContext';

function Line({ label, wide }) {
  return (
    <div className={wide ? 'sm:col-span-2' : ''}>
      <p className="text-[9px] uppercase tracking-[0.18em] text-[#10203A]/45">{label}</p>
      <div className="mt-1 h-7 border-b border-dashed border-[#10203A]/35" />
    </div>
  );
}

export default function Cadastro() {
  const { active } = useClassroom();

  return (
    <div className="mx-auto max-w-4xl px-5 pb-4 pt-8">
      <div className="no-print mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[11px] uppercase tracking-[0.28em] text-[#10203A]/40">Impressos</p>
          <h1 className="mt-1 font-display text-3xl leading-none tracking-[-0.03em] sm:text-4xl">
            Ficha para as famílias
          </h1>
          <p className="mt-2 max-w-md text-sm text-[#10203A]/55">
            Uma folha por criança. Imprima e envie na mochila; volta preenchida e assinada.
          </p>
        </div>
        <button
          type="button"
          onClick={() => window.print()}
          className="inline-flex items-center gap-2 rounded-full bg-[#10203A] px-5 py-3 text-sm text-[#FFF8EF]"
        >
          <Printer className="h-4 w-4" /> Imprimir ficha
        </button>
      </div>

      <div className="print-sheet rounded-[32px] bg-white p-7 brand-hairline sm:p-10">
        <div className="flex items-start justify-between gap-4 border-b border-[#10203A]/12 pb-5">
          <div>
            <Logo size="md" />
            <p className="mt-2 text-[10px] uppercase tracking-[0.22em] text-[#10203A]/40">
              {active?.name || 'Turma'} · Ficha de cadastro
            </p>
          </div>
          <CardCover variant="manga" holder="Eu" compact className="w-28 rounded-[10px] shadow-none" />
        </div>

        <p className="mt-5 text-sm leading-relaxed text-[#10203A]/65">
          Nesta turma, cada criança tem um cartão com um animal. Ao longo da semana registramos os ganhos (tarefas em
          casa, atividades, apresentações, vendas de desenhos) e os gastos (compras e doações). Toda sexta-feira
          enviamos o relatório da semana.
        </p>

        <div className="mt-6">
          <p className="mb-3 font-heading text-base font-bold">1. A criança</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <Line label="Nome completo" wide />
            <Line label="Data de nascimento" />
            <Line label="Como quer ser chamada(o) no cartão" />
          </div>

          <div className="mt-4">
            <p className="text-[9px] uppercase tracking-[0.18em] text-[#10203A]/45">Animal escolhido</p>
            <div className="mt-2 grid grid-cols-8 gap-2">
              {symbols.map((s) => (
                <span
                  key={s}
                  className="flex h-9 items-center justify-center rounded-lg border border-[#10203A]/20 text-lg"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-6">
          <p className="mb-3 font-heading text-base font-bold">2. A família</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <Line label="Nome do responsável" />
            <Line label="Parentesco" />
            <Line label="Telefone / WhatsApp" />
            <Line label="E-mail" />
          </div>
        </div>

        <div className="mt-6">
          <p className="mb-3 font-heading text-base font-bold">3. Autorização</p>
          <div className="space-y-2.5 text-xs leading-relaxed text-[#10203A]/70">
            <p className="flex gap-2">
              <span className="mt-0.5 inline-block h-3.5 w-3.5 shrink-0 rounded border border-[#10203A]/40" />
              Autorizo meu filho(a) a participar do Banco da Turminha.
            </p>
            <p className="flex gap-2">
              <span className="mt-0.5 inline-block h-3.5 w-3.5 shrink-0 rounded border border-[#10203A]/40" />
              Autorizo o registro das atividades para fins pedagógicos e o relatório semanal.
            </p>
          </div>
        </div>

        <div className="mt-8 flex items-end justify-between gap-6 border-t border-[#10203A]/12 pt-6">
          <div className="flex-1">
            <div className="h-8 border-b border-dashed border-[#10203A]/35" />
            <p className="mt-1.5 text-[9px] uppercase tracking-[0.18em] text-[#10203A]/45">
              Assinatura do responsável
            </p>
          </div>
          <div className="w-40">
            <div className="h-8 border-b border-dashed border-[#10203A]/35" />
            <p className="mt-1.5 text-[9px] uppercase tracking-[0.18em] text-[#10203A]/45">Data</p>
          </div>
        </div>

        <div className="mt-7 grid gap-3 rounded-2xl bg-[#FFF8EF] p-4 sm:grid-cols-3">
          {[
            ['1', 'Cartão com animal', 'A criança escolhe o bicho e recebe o cartão impresso.'],
            ['2', 'Registro na escola', 'A professora lê o cartão e anota o ganho ou o gasto.'],
            ['3', 'Relatório na sexta', 'A família recebe a folha da semana assinada.'],
          ].map(([n, t, d]) => (
            <div key={n} className="flex gap-2.5">
              <span
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#FFB627] font-display text-xs"
                style={{ fontWeight: 1000 }}
              >
                {n}
              </span>
              <div>
                <p className="text-[11px] font-bold text-[#10203A]">{t}</p>
                <p className="mt-0.5 text-[10px] leading-snug text-[#10203A]/55">{d}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <p className="no-print mt-4 text-center text-xs text-[#10203A]/40">
        No diálogo de impressão, escolha “retrato” e uma cópia por família.
      </p>
    </div>
  );
}