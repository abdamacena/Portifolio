import { Link } from 'react-router-dom';
import { ArrowRight, Heart, Pencil } from 'lucide-react';
import { LogoMark, LogoWordmark } from '@/components/brand/Logo';
import CardCover from '@/components/brand/CardCover';
import PaletteGrid from '@/components/brand/PaletteGrid';
import TypeSpecimen from '@/components/brand/TypeSpecimen';
import { Image } from '@/components/ui/image';
import { cardVariants } from '@/lib/brand';

const tone = [
  ['Fala com a criança', 'Uma ideia por frase. Nada de “crédito”, “tarifa” ou “limite”.'],
  ['Explica com bicho', 'O animal do cartão é a identidade. Aparece no app, na ficha e no relatório.'],
  ['Termina com conquista', 'Toda tela de gasto lembra o que ainda dá para conquistar.'],
];

export default function Marca() {
  return (
    <div className="mx-auto max-w-6xl px-5 pb-4 pt-10">
      <div className="grid items-center gap-10 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <span className="mb-4 inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.3em] text-[#10203A]/45">
            <span className="h-1.5 w-1.5 rounded-full bg-[#FFB627]" />
            Manual da marca
          </span>
          <LogoWordmark className="text-[clamp(2.6rem,7vw,4.2rem)]" stacked />
          <p className="mt-6 max-w-md text-base leading-relaxed text-[#10203A]/65">
            O banco de uma turma de educação infantil. Um cartão com animal para cada criança, a professora com o
            registro na mão e a família acompanhando de casa.
          </p>
          <p className="mt-4 font-heading text-lg text-[#10203A]/50">Moedinhas que ensinam a cuidar.</p>
        </div>

        <div className="relative mx-auto w-full max-w-sm">
          <div className="absolute -left-4 top-4 w-full rotate-[-8deg]">
            <CardCover variant="lilas" holder="Theo" symbol="🦊" compact />
          </div>
          <div className="relative mt-8 rotate-[3deg]">
            <CardCover variant="manga" holder="Lia" symbol="🐻" />
          </div>
        </div>
      </div>

      {/* Símbolo */}
      <section className="mt-16">
        <h2 className="mb-6 font-heading text-2xl font-bold">O símbolo</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="flex flex-col items-center justify-center gap-3 rounded-[28px] bg-[#FFB627] p-8">
            <LogoMark className="h-20 w-20" />
            <span className="text-[10px] uppercase tracking-[0.18em] text-[#10203A]/50">Cheio</span>
          </div>
          <div className="flex flex-col items-center justify-center gap-3 rounded-[28px] bg-[#10203A] p-8">
            <LogoMark className="h-20 w-20" mono />
            <span className="text-[10px] uppercase tracking-[0.18em] text-[#FFF8EF]/40">Negativo</span>
          </div>
          <div className="flex flex-col items-center justify-center gap-3 rounded-[28px] bg-white p-8 brand-hairline">
            <span className="flex h-16 w-16 items-center justify-center rounded-[18px] bg-[#FFB627]">
              <LogoMark className="h-11 w-11" bg="#FFB627" />
            </span>
            <span className="text-[10px] uppercase tracking-[0.18em] text-[#10203A]/40">Ícone do app</span>
          </div>
          <div className="flex flex-col items-center justify-center gap-3 rounded-[28px] bg-white p-8 brand-hairline">
            <LogoMark className="h-20 w-20" bg="#FFF8EF" fg="#10203A" />
            <span className="text-[10px] uppercase tracking-[0.18em] text-[#10203A]/40">Uma cor</span>
          </div>
        </div>
      </section>

      {/* Paleta */}
      <section className="mt-14">
        <h2 className="mb-2 font-heading text-2xl font-bold">Paleta</h2>
        <p className="mb-6 max-w-xl text-sm text-[#10203A]/55">
          Toque para copiar. As cores fortes marcam as ações; os tons claros são o papel onde as crianças desenham.
        </p>
        <PaletteGrid />
      </section>

      {/* Tipografia */}
      <section className="mt-14">
        <h2 className="mb-2 font-heading text-2xl font-bold">Tipografia</h2>
        <p className="mb-6 max-w-xl text-sm text-[#10203A]/55">
          Redonda e grande para a criança ler pelo formato das letras; serifada para acolher as famílias.
        </p>
        <TypeSpecimen />
      </section>

      {/* Mascote */}
      <section className="mt-14 grid items-center gap-8 rounded-[32px] border border-[#10203A]/10 bg-white p-7 sm:p-10 lg:grid-cols-[1fr_0.8fr]">
        <div>
          <h2 className="font-heading text-2xl font-bold">A moedinha</h2>
          <p className="mt-3 max-w-md text-sm leading-relaxed text-[#10203A]/60">
            A moeda que sorri é quem dá as boas-vindas e comemora cada meta. Ela pode aparecer como desenho, adesivo
            ou carimbo no relatório — nunca segurando dinheiro.
          </p>
          <p className="mt-4 flex items-center gap-2 text-xs text-[#10203A]/45">
            <Heart className="h-3.5 w-3.5 text-[#FF6B57]" /> Sempre desenhada de contorno cheio, com o broto na cabeça.
          </p>
        </div>
        <div className="rounded-[24px] bg-[#FFF8EF] p-3">
          <Image
            src="https://media.base44.com/images/public/6aef51b8d3f430ea0cca3ff1/93eb0cc57_generated_image.png"
            alt="A moedinha, mascote da marca"
            className="aspect-square w-full rounded-[18px]"
            fittingType="fit"
          />
        </div>
      </section>

      {/* Tom */}
      <section className="mt-14">
        <h2 className="mb-6 font-heading text-2xl font-bold">Como a marca fala</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          {tone.map(([t, d]) => (
            <div key={t} className="rounded-[26px] border border-[#10203A]/10 bg-white p-6">
              <h3 className="font-heading text-base font-bold">{t}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-[#10203A]/55">{d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Cartões */}
      <section className="mt-14">
        <div className="mb-4 flex items-end justify-between">
          <h2 className="font-heading text-2xl font-bold">Capas dos cartões</h2>
          <Link to="/cartoes" className="inline-flex items-center gap-1.5 text-sm text-[#10203A]/55">
            Abrir <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {cardVariants.map((c) => (
            <CardCover key={c.id} variant={c} holder={c.name} compact />
          ))}
        </div>
      </section>

      {/* Impressos */}
      <section className="mt-14 rounded-[32px] bg-[#10203A] p-7 text-[#FFF8EF] sm:p-10">
        <h2 className="font-heading text-2xl font-bold">Impressos</h2>
        <p className="mt-2 max-w-lg text-sm text-[#FFF8EF]/60">
          Ficha A4 e cartões em papel 300 g. Margens de 12 mm, corte reto e cantos arredondados de 3 mm.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link
            to="/cadastro"
            className="inline-flex items-center gap-2 rounded-full bg-[#FFB627] px-5 py-3 text-sm text-[#10203A]"
          >
            <Pencil className="h-4 w-4" /> Abrir ficha
          </Link>
          <Link
            to="/cartoes"
            className="inline-flex items-center gap-2 rounded-full border border-white/25 px-5 py-3 text-sm text-[#FFF8EF]"
          >
            Abrir cartões
          </Link>
        </div>
      </section>
    </div>
  );
}