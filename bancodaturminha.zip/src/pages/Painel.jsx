import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import SkillChart from '@/components/reports/SkillChart';
import ChildBars from '@/components/reports/ChildBars';
import BadgeTally from '@/components/reports/BadgeTally';
import { useClassroom } from '@/lib/ClassContext';
import { learningSkills, skillOf } from '@/lib/learning';
import { badgeCatalog } from '@/lib/badges';

const chartColors = ['#12C2A0', '#FFB627', '#8B7CF6', '#FF6B57', '#5AA9E6', '#E86AA6'];

export default function Painel() {
  const { active, activeId } = useClassroom();
  const [data, setData] = useState(null);

  useEffect(() => {
    let alive = true;
    setData(null);
    (async () => {
      const [kidsPage, marksPage, badgesPage] = await Promise.all([
        base44.entities.Child.filter({ class_id: activeId }, { sort: 'name', limit: 200 }),
        base44.entities.LearningMark.filter({ class_id: activeId }, { limit: 300 }),
        base44.entities.Badge.filter({ class_id: activeId }, { limit: 300 }),
      ]);
      if (!alive) return;

      const kids = kidsPage.items || [];
      const marks = marksPage.items || [];
      const badges = badgesPage.items || [];

      const skillCount = {};
      const perKid = {};
      kids.forEach((k) => {
        perKid[k.id] = { boas: 0, apoio: 0 };
      });

      marks.forEach((mark) => {
        (mark.skills || []).forEach((id) => {
          skillCount[id] = (skillCount[id] || 0) + 1;
          const row = perKid[mark.child_id];
          if (row) row[skillOf(id).tone === 'good' ? 'boas' : 'apoio'] += 1;
        });
      });

      const skillData = learningSkills
        .filter((s) => s.tone === 'good' && skillCount[s.id])
        .sort((a, b) => skillCount[b.id] - skillCount[a.id])
        .slice(0, 6)
        .map((s, i) => ({ id: s.id, label: s.label, count: skillCount[s.id], color: chartColors[i % chartColors.length] }));

      const kidData = kids.map((k) => ({
        id: k.id,
        name: k.nickname || k.name.split(' ')[0],
        boas: perKid[k.id]?.boas || 0,
        apoio: perKid[k.id]?.apoio || 0,
      }));

      const badgeData = badgeCatalog
        .map((b) => ({
          id: b.id,
          label: b.label,
          color: b.color,
          count: badges.filter((x) => x.badge_id === b.id).length,
        }))
        .filter((b) => b.count > 0)
        .sort((a, b) => b.count - a.count);

      setData({
        kids: kids.length,
        marked: marks.filter((m) => (m.skills || []).length > 0).length,
        badgeTotal: badges.length,
        skillData,
        kidData,
        badgeData,
      });
    })();
    return () => {
      alive = false;
    };
  }, [activeId]);

  if (!data) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
      </div>
    );
  }

  const stats = [
    { label: 'Crianças', value: `${data.kids}`, bg: 'bg-[#FFF1D6]' },
    { label: 'Semanas marcadas', value: `${data.marked}`, bg: 'bg-[#EAE6FF]' },
    { label: 'Selos entregues', value: `${data.badgeTotal}`, bg: 'bg-[#D4F7EE]' },
  ];

  return (
    <div className="mx-auto max-w-3xl px-5 pb-4 pt-8">
      <div className="mb-5">
        <p className="text-[11px] uppercase tracking-[0.28em] text-[#10203A]/40">
          Painel · {active?.name || 'turma'}
        </p>
        <h1 className="mt-1 font-display text-3xl leading-none tracking-[-0.03em] sm:text-4xl">
          Progresso da turma
        </h1>
        <p className="mt-2 max-w-xl text-sm leading-relaxed text-[#10203A]/55">
          Gráficos das habilidades marcadas em Desempenho e das medalhas entregues para as crianças.
        </p>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {stats.map((s) => (
          <div key={s.label} className={`rounded-[22px] ${s.bg} px-3 py-3`}>
            <p className="font-display text-2xl leading-none" style={{ fontWeight: 1000 }}>
              {s.value}
            </p>
            <p className="mt-1 text-[10px] leading-tight text-[#10203A]/55">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-3 space-y-3">
        <SkillChart data={data.skillData} />
        <ChildBars data={data.kidData} />
        <BadgeTally data={data.badgeData} />
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <Link
          to="/desempenho"
          className="rounded-full bg-[#10203A] px-5 py-3 text-sm text-[#FFF8EF]"
        >
          Marcar a semana
        </Link>
        <Link
          to="/alunos"
          className="rounded-full border border-[#10203A]/15 px-5 py-3 text-sm text-[#10203A]/70"
        >
          Dar selos às crianças
        </Link>
      </div>
    </div>
  );
}