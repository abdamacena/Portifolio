import { useState } from 'react';
import { Check, Copy, Plus } from 'lucide-react';
import ClassForm from '@/components/class/ClassForm';
import { useClassroom } from '@/lib/ClassContext';
import { cardVariants } from '@/lib/brand';

export default function Turmas() {
  const { classes, activeId, select, loading, reload } = useClassroom();
  const [creating, setCreating] = useState(false);
  const [copied, setCopied] = useState('');

  const copy = async (code) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(code);
      setTimeout(() => setCopied(''), 2000);
    } catch {
      setCopied('');
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-5 pb-4 pt-8">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[11px] uppercase tracking-[0.28em] text-[#10203A]/40">Suas salas</p>
          <h1 className="mt-1 font-display text-3xl leading-none tracking-[-0.03em] sm:text-4xl">Minhas turmas</h1>
        </div>
        <button
          type="button"
          onClick={() => setCreating((v) => !v)}
          className="inline-flex items-center gap-2 rounded-full bg-[#10203A] px-5 py-3 text-sm text-[#FFF8EF]"
        >
          <Plus className="h-4 w-4" /> Nova turma
        </button>
      </div>

      {creating && (
        <div className="mb-5">
          <ClassForm
            onCreated={() => {
              setCreating(false);
              reload();
            }}
          />
        </div>
      )}

      <div className="space-y-3">
        {classes.map((c) => {
          const variant = cardVariants.find((v) => v.id === c.color) || cardVariants[0];
          const isActive = c.id === activeId;
          return (
            <div
              key={c.id}
              className="rounded-[26px] bg-white p-4 brand-hairline"
              style={{ borderLeft: `6px solid ${variant.base}` }}
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate font-heading text-lg font-bold leading-tight">{c.name}</p>
                  <p className="text-[11px] text-[#10203A]/45">
                    {c.year ? `${c.year} · ` : ''}código para as famílias
                  </p>
                </div>
                {isActive ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-[#D4F7EE] px-3 py-1.5 text-[11px] text-[#0E9B80]">
                    <Check className="h-3.5 w-3.5" /> Em uso
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => select(c.id)}
                    className="rounded-full border border-[#10203A]/15 px-4 py-2 text-[12px] text-[#10203A]/70"
                  >
                    Usar esta turma
                  </button>
                )}
              </div>

              <div className="mt-3 flex items-center justify-between gap-3 rounded-2xl bg-[#FFF8EF] px-3 py-2.5">
                <span className="font-mono text-base tracking-[0.18em] text-[#10203A]">{c.code}</span>
                <button
                  type="button"
                  onClick={() => copy(c.code)}
                  className="inline-flex items-center gap-1.5 text-[11px] text-[#10203A]/55"
                >
                  {copied === c.code ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                  {copied === c.code ? 'Copiado' : 'Copiar'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <p className="mt-5 rounded-2xl bg-[#FFF1D6] px-4 py-3 text-[12px] leading-relaxed text-[#10203A]/60">
        A família usa esse código na ficha do site para a criança entrar na turma certa. Cada turma tem as suas
        crianças, tarefas e cartões — trocar de turma não mistura os registros.
      </p>
    </div>
  );
}