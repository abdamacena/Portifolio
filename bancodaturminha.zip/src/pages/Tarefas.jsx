import { useEffect, useState } from 'react';
import { Loader2, Plus } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import TaskValueRow from '@/components/app/TaskValueRow';
import { useClassroom } from '@/lib/ClassContext';
import { formatMoney } from '@/lib/money';

const emojis = ['🧹', '🛏️', '🪥', '📚', '🍽️', '🧺', '🐶', '🚿', '🧸', '🌱', '✏️', '🧼'];

export default function Tarefas() {
  const { active, activeId } = useClassroom();
  const [tasks, setTasks] = useState(null);
  const [draft, setDraft] = useState({ title: '', emoji: '🧹', value: 0.5 });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    base44.entities.Task.filter({ class_id: activeId }, { sort: 'title', limit: 100 }).then((page) =>
      setTasks(page.items || [])
    );
  }, [activeId]);

  const patch = (id, changes) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...changes } : t)));
    setSaved(false);
  };

  const add = async (e) => {
    e.preventDefault();
    setError('');
    if (draft.title.trim().length < 2) {
      setError('Escreva o nome da tarefa.');
      return;
    }
    const created = await base44.entities.Task.create({
      title: draft.title.trim(),
      emoji: draft.emoji,
      value: Number(draft.value) || 0,
      active: true,
      class_id: activeId,
    });
    setTasks((prev) => [...prev, created].sort((a, b) => a.title.localeCompare(b.title)));
    setDraft({ title: '', emoji: '🧹', value: 0.5 });
  };

  const save = async () => {
    setSaving(true);
    setError('');
    try {
      await base44.entities.Task.bulkUpdate(
        tasks.map((t) => ({
          id: t.id,
          title: t.title,
          emoji: t.emoji,
          value: Number(t.value) || 0,
          active: t.active,
        }))
      );
      setSaved(true);
    } catch (err) {
      setError(err?.message || 'Não foi possível salvar.');
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id) => {
    await base44.entities.Task.delete(id);
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  if (!tasks) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
      </div>
    );
  }

  const ativas = tasks.filter((t) => t.active).length;

  return (
    <div className="mx-auto max-w-3xl px-5 pb-4 pt-8">
      <div className="mb-6">
        <p className="text-[11px] uppercase tracking-[0.28em] text-[#10203A]/40">
          Tarefas de casa · {active?.name || 'turma'}
        </p>
        <h1 className="mt-1 font-display text-3xl leading-none tracking-[-0.03em] sm:text-4xl">
          Tabela de valores
        </h1>
        <p className="mt-2 max-w-xl text-sm leading-relaxed text-[#10203A]/55">
          Escolha o quanto vale cada tarefa. As famílias só conseguem registrar as tarefas ativas, sempre pelo valor
          definido aqui.
        </p>
      </div>

      <form onSubmit={add} className="mb-5 rounded-[26px] bg-[#FFFDF9] p-4 brand-hairline">
        <p className="mb-2 text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">Nova tarefa</p>
        <div className="flex flex-wrap items-center gap-2 sm:flex-nowrap">
          <input
            value={draft.title}
            onChange={(e) => setDraft((d) => ({ ...d, title: e.target.value }))}
            placeholder="Ex.: Guardar os brinquedos"
            className="h-11 min-w-0 flex-1 rounded-xl border border-[#10203A]/10 bg-white px-3 text-sm outline-none focus:border-[#10203A]/40"
          />
          <div className="flex h-11 items-center gap-1 rounded-xl border border-[#10203A]/10 bg-white px-3">
            <span className="text-[11px] text-[#10203A]/40">R$</span>
            <input
              type="number"
              step="0.25"
              min="0"
              value={draft.value}
              onChange={(e) => setDraft((d) => ({ ...d, value: e.target.value }))}
              className="w-20 bg-transparent text-sm outline-none"
              aria-label="Valor da nova tarefa"
            />
          </div>
          <button
            type="submit"
            className="inline-flex h-11 items-center gap-2 rounded-xl bg-[#10203A] px-4 text-sm text-[#FFF8EF]"
          >
            <Plus className="h-4 w-4" /> Adicionar
          </button>
        </div>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {emojis.map((e) => (
            <button
              key={e}
              type="button"
              onClick={() => setDraft((d) => ({ ...d, emoji: e }))}
              className={`flex h-9 w-9 items-center justify-center rounded-lg border text-base transition ${
                draft.emoji === e ? 'border-[#10203A] bg-[#FFB627]/20' : 'border-[#10203A]/10 bg-white'
              }`}
              aria-label={`Ícone ${e}`}
            >
              {e}
            </button>
          ))}
        </div>
      </form>

      <div className="space-y-2">
        {tasks.map((t) => (
          <TaskValueRow
            key={t.id}
            task={t}
            onChange={(changes) => patch(t.id, changes)}
            onDelete={() => remove(t.id)}
          />
        ))}
        {tasks.length === 0 && (
          <p className="rounded-[22px] bg-white p-5 text-center text-sm text-[#10203A]/50 brand-hairline">
            Nenhuma tarefa ainda. Crie a primeira acima.
          </p>
        )}
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={save}
          disabled={saving || tasks.length === 0}
          className="inline-flex items-center gap-2 rounded-full bg-[#FFB627] px-6 py-3 text-sm text-[#10203A] disabled:opacity-50"
        >
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          {saving ? 'Salvando…' : 'Salvar alterações'}
        </button>
        <p className="text-[12px] text-[#10203A]/45">
          {ativas} tarefa{ativas === 1 ? '' : 's'} ativa{ativas === 1 ? '' : 's'} · total até{' '}
          {formatMoney(tasks.filter((t) => t.active).reduce((sum, t) => sum + (Number(t.value) || 0), 0))}
        </p>
        {saved && <span className="text-[12px] font-semibold text-[#0E9B80]">Valores salvos</span>}
      </div>

      {error && <p className="mt-3 rounded-2xl bg-[#FFE1DB] px-4 py-3 text-[13px] text-[#B23A28]">{error}</p>}
    </div>
  );
}