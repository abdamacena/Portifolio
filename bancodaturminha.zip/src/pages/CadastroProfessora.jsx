import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Loader2, School } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import Logo from '@/components/brand/Logo';
import ClassForm from '@/components/class/ClassForm';
import GoogleSignInButton from '@/components/site/GoogleSignInButton';
import TeacherSignupForm from '@/components/teacher/TeacherSignupForm';

export default function CadastroProfessora() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(true);
  const [created, setCreated] = useState(null);

  useEffect(() => {
    base44.auth
      .isAuthenticated()
      .then((ok) => (ok ? base44.auth.me() : null))
      .then((me) => setUser(me))
      .catch(() => setUser(null))
      .finally(() => setChecking(false));
  }, []);

  return (
    <div className="min-h-screen bg-[#FFF8EF] px-5 py-10">
      <div className="mx-auto w-full max-w-md">
        <Link to="/login" aria-label="Banco da Turminha">
          <Logo size="md" />
        </Link>

        {checking && (
          <div className="flex min-h-[40vh] items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin text-[#10203A]/30" />
          </div>
        )}

        {!checking && !user && (
          <>
            <p className="mt-8 text-[10px] uppercase tracking-[0.26em] text-[#10203A]/40">Professora</p>
            <h1 className="balance mt-2 font-display text-[2rem] leading-[0.95] tracking-[-0.035em]">
              Criar a conta da professora.
            </h1>
            <p className="mt-2 text-[13px] leading-relaxed text-[#10203A]/55">
              Crie a conta com e-mail e senha, ou entre com o Google. Depois você cria a escola e a turma.
            </p>

            <div className="mt-5 space-y-3 rounded-[28px] border border-[#10203A]/10 bg-[#FFFDF9] p-4">
              <TeacherSignupForm />
              <div className="flex items-center gap-3">
                <span className="h-px flex-1 bg-[#10203A]/10" />
                <span className="text-[10px] uppercase tracking-[0.2em] text-[#10203A]/35">ou</span>
                <span className="h-px flex-1 bg-[#10203A]/10" />
              </div>
              <GoogleSignInButton
                label="Criar conta com o Google"
                returnTo="/cadastro-professora"
                className="h-14 border-[#10203A] text-[16px]"
              />
              <p className="text-center text-[12px] text-[#10203A]/55">
                Já tem conta?{' '}
                <Link to="/login" className="underline">
                  Entrar
                </Link>
              </p>
            </div>
          </>
        )}

        {!checking && user && !created && (
          <>
            <p className="mt-8 flex items-center gap-2 text-[10px] uppercase tracking-[0.26em] text-[#10203A]/40">
              <School className="h-3.5 w-3.5" /> Escola e turma
            </p>
            <h1 className="balance mt-2 font-display text-[2rem] leading-[0.95] tracking-[-0.035em]">
              Agora a sua escola e a turma.
            </h1>
            <p className="mt-2 text-[13px] leading-relaxed text-[#10203A]/55">
              Cada turma tem as suas crianças, tarefas e cartões. Aqui você escolhe o código que as famílias vão digitar
              na ficha.
            </p>
            <div className="mt-5">
              <ClassForm teacherName={user.display_name || user.full_name} onCreated={setCreated} />
            </div>
          </>
        )}

        {!checking && user && created && (
          <>
            <p className="mt-8 flex items-center gap-2 text-[10px] uppercase tracking-[0.26em] text-[#10203A]/40">
              <School className="h-3.5 w-3.5" /> Turma criada
            </p>
            <h1 className="balance mt-2 font-display text-[2rem] leading-[0.95] tracking-[-0.035em]">
              Sua turma está pronta.
            </h1>
            <div className="mt-5 rounded-[28px] border border-[#10203A]/10 bg-[#FFFDF9] p-5 text-center">
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">Código da turma</p>
              <p className="mt-2 font-mono text-3xl tracking-[0.2em] text-[#10203A]">{created.code}</p>
              <p className="mt-2 text-[12px] leading-relaxed text-[#10203A]/50">
                {created.name}
                {created.school ? ` · ${created.school}` : ''} — passe este código para as famílias na ficha da
                criança.
              </p>
              <button
                type="button"
                onClick={() => window.location.replace('/inicio')}
                className="mt-4 flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-[#10203A] text-[15px] text-[#FFF8EF]"
              >
                Entrar no meu banco <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}