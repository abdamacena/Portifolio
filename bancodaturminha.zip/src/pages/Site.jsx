import { Link } from 'react-router-dom';
import Logo from '@/components/brand/Logo';
import PublicNav from '@/components/site/PublicNav';
import SiteHero from '@/components/site/SiteHero';
import HowItWorks from '@/components/site/HowItWorks';
import CoinSources from '@/components/site/CoinSources';
import CardShowcase from '@/components/site/CardShowcase';
import RegistrationForm from '@/components/site/RegistrationForm';
import SiteTabBar from '@/components/site/SiteTabBar';

export default function Site() {
  return (
    <div className="min-h-screen bg-[#EDE3D3]">
      <div className="relative mx-auto min-h-screen w-full max-w-[430px] bg-[#FFF8EF] pb-24 shadow-[0_30px_90px_-40px_rgba(16,32,58,0.5)] sm:my-8 sm:min-h-[calc(100vh-4rem)] sm:rounded-[40px] sm:border sm:border-[#10203A]/10">
        <PublicNav />

        <main>
          <SiteHero />
          <HowItWorks />
          <CoinSources />
          <CardShowcase />
          <RegistrationForm />
        </main>

        <footer className="mt-12 border-t border-[#10203A]/10 px-5 pb-4 pt-7">
          <Logo size="sm" />
          <p className="mt-3 text-[11px] leading-relaxed text-[#10203A]/45">
            Moedinhas que ensinam a cuidar. Um banco para a turma inteira: um cartão com animal para cada criança, do
            tamanho que a turma tiver.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px]">
            <Link to="/familia" className="text-[#10203A]/55">
              Área da criança
            </Link>
            <Link to="/professora" className="text-[#10203A]/55">
              Área da professora
            </Link>
          </div>
          <p className="mt-5 border-t border-[#10203A]/10 pt-4 text-[10px] leading-relaxed text-[#10203A]/40">
            Um projeto desenvolvido por Ana Bárbara Damacena para a Escola Infantil Cícero Pereira.
          </p>
        </footer>

        <SiteTabBar />
      </div>
    </div>
  );
}