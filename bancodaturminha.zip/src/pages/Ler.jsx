import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, Nfc, QrCode } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import QrScanner from '@/components/app/QrScanner';
import ChildPicker from '@/components/app/ChildPicker';
import CrayonDoodles from '@/components/kid/CrayonDoodles';
import { codeFromCardText, nfcSupported, readCardTag, studentIdFromCardText } from '@/lib/nfc';
import { useClassroom } from '@/lib/ClassContext';

export default function Ler() {
  const navigate = useNavigate();
  const { active, activeId } = useClassroom();
  const [kids, setKids] = useState([]);
  const [loading, setLoading] = useState(true);
  const [code, setCode] = useState('');
  const [qrOpen, setQrOpen] = useState(false);
  const [nfcOn, setNfcOn] = useState(false);
  const [msg, setMsg] = useState('');
  const controllerRef = useRef(null);

  const supported = nfcSupported();

  useEffect(() => {
    let alive = true;
    (async () => {
      const page = await base44.entities.Child.filter({ class_id: activeId }, { sort: 'name' });
      if (!alive) return;
      setKids(page.items || []);
      setLoading(false);
    })();
    return () => {
      alive = false;
      controllerRef.current?.abort();
    };
  }, [activeId]);

  const openChild = (text) => {
    const studentId = studentIdFromCardText(text);
    if (studentId) {
      const found = kids.find((k) => k.id === studentId);
      if (found) {
        navigate(`/alunos/${found.id}`);
        return;
      }
      setMsg('Esse cartão é de outra turma. Troque a turma no topo da tela.');
      return;
    }

    const digits = codeFromCardText(text);
    const found = kids.find((k) => k.card_code === digits);
    if (found) {
      navigate(`/alunos/${found.id}`);
      return;
    }
    setMsg('Não reconheci esse cartão. Confira os cartões na aba “Cartões”.');
  };

  const stopNfc = () => {
    controllerRef.current?.abort();
    controllerRef.current = null;
    setNfcOn(false);
  };

  const startNfc = async () => {
    setMsg('');
    try {
      const controller = new AbortController();
      controllerRef.current = controller;
      setNfcOn(true);
      await readCardTag({
        signal: controller.signal,
        onCard: (text) => {
          stopNfc();
          openChild(text);
        },
        onError: (m) => setMsg(m),
      });
    } catch (error) {
      stopNfc();
      setMsg(
        error?.name === 'NotAllowedError'
          ? 'Libere o NFC para o navegador poder ler o cartão.'
          : 'Este aparelho não abriu o leitor NFC. Use o QR abaixo.'
      );
    }
  };

  const onCode = (value) => {
    const digits = value.replace(/\D/g, '').slice(0, 3);
    setCode(digits);
    const found = kids.find((k) => k.card_code === digits);
    if (found) navigate(`/alunos/${found.id}`);
  };

  if (loading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-5 pb-6 pt-8">
      <p className="text-[11px] uppercase tracking-[0.28em] text-[#10203A]/40">Leitor · {active?.name || 'turma'}</p>
      <h1 className="mt-1 font-display text-3xl leading-none tracking-[-0.03em] sm:text-4xl">Encoste o cartão</h1>
      <p className="mt-3 max-w-md text-sm leading-relaxed text-[#10203A]/55">
        Cada cartão tem uma etiqueta NFC. Ao encostar, a página da criança abre com saldo, ganhos, gastos e selos.
      </p>

      {qrOpen && (
        <QrScanner
          onResult={(text) => {
            setQrOpen(false);
            openChild(text);
          }}
          onClose={() => setQrOpen(false)}
        />
      )}

      <div className="relative mt-6 overflow-hidden rounded-[32px] bg-[#FFB627] p-6">
        <CrayonDoodles />
        <div className="relative flex flex-col items-center text-center">
          <button
            type="button"
            onClick={() => (nfcOn ? stopNfc() : startNfc())}
            className="relative flex h-32 w-32 items-center justify-center rounded-full bg-[#10203A] text-[#FFF8EF] transition active:scale-95"
          >
            {nfcOn && <span className="absolute inset-0 animate-ping rounded-full bg-[#10203A]/25" />}
            {nfcOn ? <Loader2 className="h-12 w-12 animate-spin" /> : <Nfc className="h-12 w-12" />}
          </button>
          <p className="mt-4 font-display text-xl leading-tight" style={{ fontWeight: 1000 }}>
            {nfcOn ? 'Encoste o cartão no celular…' : 'Ler etiqueta NFC'}
          </p>
          <p className="mt-1 max-w-xs text-xs leading-snug text-[#10203A]/65">
            {nfcOn
              ? 'Aproxime o cartão da parte de trás do aparelho. Toque no círculo para parar.'
              : 'Toque no círculo e aproxime o cartão. A página da criança abre na hora.'}
          </p>
          {!supported && (
            <p className="mt-3 max-w-xs rounded-2xl bg-white/70 px-3 py-2 text-[11px] leading-snug text-[#10203A]/70">
              Este navegador não lê NFC. No iPhone, aproxime o cartão do topo do aparelho que o próprio sistema abre a
              página. Se não abrir, use o QR ou o número do cartão.
            </p>
          )}
          {msg && <p className="mt-3 max-w-xs text-[11px] leading-snug text-[#10203A]/70">{msg}</p>}
        </div>
      </div>

      <div className="mt-6 rounded-[32px] bg-white p-5 brand-hairline sm:p-6">
        <button
          type="button"
          onClick={() => {
            setMsg('');
            setQrOpen(true);
          }}
          className="flex w-full items-center justify-center gap-2 rounded-full border border-[#10203A]/15 py-3 text-sm text-[#10203A]/75 hover:bg-[#10203A]/5"
        >
          <QrCode className="h-4 w-4" /> Ler QR do cartão
        </button>

        <label className="mt-5 block">
          <span className="mb-2 block text-[10px] uppercase tracking-[0.24em] text-[#10203A]/40">
            Número do cartão
          </span>
          <input
            value={code}
            onChange={(e) => onCode(e.target.value)}
            inputMode="numeric"
            placeholder="00"
            className="h-[54px] w-full rounded-2xl border border-[#10203A]/12 bg-[#FFF8EF] px-4 font-display text-2xl tracking-[0.2em] outline-none transition focus:border-[#10203A] focus:ring-4 focus:ring-[#FFB627]/25"
            style={{ fontWeight: 1000 }}
          />
        </label>

        <div className="mt-5">
          <p className="mb-2 text-[10px] uppercase tracking-[0.24em] text-[#10203A]/40">Ou toque no nome</p>
          <ChildPicker
            children={kids}
            selectedId=""
            onSelect={(child) => navigate(`/alunos/${child.id}`)}
          />
        </div>
      </div>
    </div>
  );
}