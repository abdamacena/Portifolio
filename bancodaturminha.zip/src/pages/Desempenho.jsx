import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Printer } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import LearningRow from '@/components/learning/LearningRow';
import SkillPicker from '@/components/learning/SkillPicker';
import ClassProgress from '@/components/learning/ClassProgress';
import FollowTips from '@/components/learning/FollowTips';
import { useClassroom } from '@/lib/ClassContext';
import { loadBalances, loadWeekByChild } from '@/lib/balances';
import { isoDate, shiftWeek, weekLabel, weekRange } from '@/lib/money';

export default function Desempenho() {
  const { active, activeId } = useClassroom();
  const [offset, setOffset] = useState(0);
  const [tab, setTab] = useState('marcar');
  const [rows, setRows] = useState(null);
  const [teacherId, setTeacherId] = useState('');
  const [openChildId, setOpenChildId] = useState('');

  const range = weekRange(shiftWeek(new Date(), offset));
  const from = isoDate(range.start);
  const to = isoDate(range.end);

  useEffect(() => {
    base44.auth
      .me()
      .then((u) => setTeacherId(u?.id || ''))
      .catch(() => setTeacherId(''));
  }, []);

  useEffect(() => {
    let alive = true;
    setRows(null);
    (async () => {
      const [kidsPage, marksPage, week, saldos] = await Promise.all([
        base44.entities.Child.filter({ class_id: activeId }, { sort: 'name', limit: 200 }),
        base44.entities.LearningMark.filter({ class_id: activeId, week_start: from }, { limit: 200 }),
        loadWeekByChild(from, to, activeId),
        loadBalances(activeId),
      ]);
      if (!alive) return;

      const marks = {};
      (marksPage.items || []).forEach((m) => {
        marks[m.child_id] = m;
      });

      const list = (kidsPage.items || []).map((kid) => ({
        kid,
        ganho: 0,
        gasto: 0,
        saldo: saldos[kid.id] || 0,
        mark: marks[kid.id] || null,
      }));
      const byId = {};
      list.forEach((r) => {
        byId[r.kid.id] = r;
      });
      (week.ganhos || []).forEach((r) => {
        if (byId[r.child_id]) byId[r.child_id].ganho = r.sum_amount || 0;
      });
      (week.gastos || []).forEach((r) => {
        if (byId[r.child_id]) byId[r.child_id].gasto = r.sum_amount || 0;
      });

      setRows(list);
    })();
    return () => {
      alive = false;
    };
  }, [activeId, from, to]);

  const openRow = rows ? rows.find((r) => r.kid.id === openChildId) : null;

  const onSaved = (mark) => {
    setRows((prev) =>
      prev.map((r) => (r.kid.id === openChildId ? { ...r, mark: mark || null } : r))
    );
    setOpenChildId('');
  };

  if (!rows) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
      </div>
    );
  }

  const marked = rows.filter((r) => (r.mark?.skills || []).length > 0).length;

  return (
    <div className="mx-auto max-w-3xl px-5 pb-4 pt-8">
      <div className="no-print mb-5">
        <p className="text-[11px] uppercase tracking-[0.28em] text-[#10203A]/40">
          Aprender · {active?.name || 'turma'}
        </p>
        <h1 className="mt-1 font-display text-3xl leading-none tracking-[-0.03em] sm:text-4xl">
          Desempenho
        </h1>
        <p className="mt-2 max-w-xl text-sm leading-relaxed text-[#10203A]/55">
          Marque o que cada criança praticou na semana. O relatório mostra a turma inteira, o progresso de cada um
          e o recado que as famílias enxergam no extrato.
        </p>
      </div>

      <div className="no-print mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setOffset((o) => o - 1)}
            className="rounded-full border border-[#10203A]/15 p-2.5 text-[#10203A]/70 hover:bg-[#10203A]/5"
            aria-label="Semana anterior"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="min-w-[165px] text-center text-sm text-[#10203A]/70">{weekLabel(range)}</span>
          <button
            type="button"
            onClick={() => setOffset((o) => o + 1)}
            disabled={offset >= 0}
            className="rounded-full border border-[#10203A]/15 p-2.5 text-[#10203A]/70 disabled:opacity-30 hover:bg-[#10203A]/5"
            aria-label="Próxima semana"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>

        {tab === 'relatorio' && (
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 rounded-full bg-[#10203A] px-5 py-3 text-sm text-[#FFF8EF]"
          >
            <Printer className="h-4 w-4" /> Imprimir relatório
          </button>
        )}
      </div>

      <div className="no-print mb-4 flex gap-1 rounded-full bg-[#10203A]/5 p-1">
        {[
          { id: 'marcar', label: `Marcar a semana` },
          { id: 'relatorio', label: 'Relatório e dicas' },
        ].map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`flex-1 rounded-full px-4 py-2.5 text-[13px] transition ${
              tab === t.id ? 'bg-[#10203A] text-[#FFF8EF]' : 'text-[#10203A]/60'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'marcar' ? (
        <div>
          <p className="mb-3 text-[12px] text-[#10203A]/50">
            {marked} de {rows.length} crianças marcadas nesta semana.
          </p>
          <div className="space-y-2">
            {rows.map((r) => (
              <LearningRow
                key={r.kid.id}
                kid={r.kid}
                mark={r.mark}
                onOpen={() => setOpenChildId(r.kid.id)}
              />
            ))}
            {rows.length === 0 && (
              <p className="rounded-[22px] bg-white p-5 text-center text-sm text-[#10203A]/50 brand-hairline">
                Nenhuma criança nesta turma ainda.
              </p>
            )}
          </div>
        </div>
      ) : (
        <div>
          <ClassProgress rows={rows} className={active?.name} weekText={weekLabel(range)} />
          <FollowTips />
        </div>
      )}

      {openRow && teacherId && (
        <SkillPicker
          child={openRow.kid}
          mark={openRow.mark}
          weekStart={from}
          classId={activeId}
          teacherUserId={teacherId}
          onClose={() => setOpenChildId('')}
          onSaved={onSaved}
        />
      )}
    </div>
  );
}