import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Printer } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import Logo from '@/components/brand/Logo';
import ChildAvatar from '@/components/kid/ChildAvatar';
import { loadBalances, loadWeekByChild } from '@/lib/balances';
import { useClassroom } from '@/lib/ClassContext';
import { formatMoney, isoDate, shiftWeek, weekLabel, weekRange } from '@/lib/money';

export default function Relatorios() {
  const { active, activeId } = useClassroom();
  const [offset, setOffset] = useState(0);
  const [kids, setKids] = useState([]);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  const range = weekRange(shiftWeek(new Date(), offset));
  const from = isoDate(range.start);
  const to = isoDate(range.end);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    (async () => {
      const [kidsPage, week, saldos] = await Promise.all([
        base44.entities.Child.filter({ class_id: activeId }, { sort: 'name' }),
        loadWeekByChild(from, to, activeId),
        loadBalances(activeId),
      ]);
      if (!alive) return;

      const list = kidsPage.items || [];
      const map = {};
      list.forEach((k) => {
        map[k.id] = { kid: k, ganho: 0, gasto: 0, saldo: saldos[k.id] || 0 };
      });
      const add = (rows, field) => {
        (rows || []).forEach((r) => {
          if (map[r.child_id]) map[r.child_id][field] = r.sum_amount;
        });
      };
      add(week.ganhos, 'ganho');
      add(week.gastos, 'gasto');

      setKids(list);
      setRows(Object.values(map));
      setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, [from, to, activeId]);

  const totals = rows.reduce(
    (acc, r) => ({
      ganho: acc.ganho + r.ganho,
      gasto: acc.gasto + r.gasto,
      saldo: acc.saldo + r.saldo,
    }),
    { ganho: 0, gasto: 0, saldo: 0 }
  );

  return (
    <div className="mx-auto max-w-4xl px-5 pb-4 pt-8">
      <div className="no-print mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[11px] uppercase tracking-[0.28em] text-[#10203A]/40">Para as famílias</p>
          <h1 className="mt-1 font-display text-3xl leading-none tracking-[-0.03em] sm:text-4xl">
            Relatório da semana
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setOffset((o) => o - 1)}
            className="rounded-full border border-[#10203A]/15 p-2.5 text-[#10203A]/70 hover:bg-[#10203A]/5"
            aria-label="Semana anterior"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="min-w-[170px] text-center text-sm text-[#10203A]/70">{weekLabel(range)}</span>
          <button
            type="button"
            onClick={() => setOffset((o) => o + 1)}
            disabled={offset >= 0}
            className="rounded-full border border-[#10203A]/15 p-2.5 text-[#10203A]/70 disabled:opacity-30 hover:bg-[#10203A]/5"
            aria-label="Próxima semana"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="ml-2 inline-flex items-center gap-2 rounded-full bg-[#10203A] px-5 py-3 text-sm text-[#FFF8EF]"
          >
            <Printer className="h-4 w-4" /> Imprimir
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex min-h-[40vh] items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
        </div>
      ) : (
        <div className="print-sheet rounded-[32px] bg-white p-6 brand-hairline sm:p-8">
          <div className="mb-6 flex items-start justify-between gap-4 border-b border-[#10203A]/10 pb-5">
            <div>
              <Logo size="sm" />
              <p className="mt-2 text-xs uppercase tracking-[0.2em] text-[#10203A]/40">
                Relatório semanal · {active?.name || 'turma'}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">Semana</p>
              <p className="text-sm">{weekLabel(range)}</p>
            </div>
          </div>

          <table className="w-full text-left">
            <thead>
              <tr className="text-[10px] uppercase tracking-[0.16em] text-[#10203A]/40">
                <th className="pb-2 font-normal">Criança</th>
                <th className="pb-2 text-right font-normal">Ganhou</th>
                <th className="pb-2 text-right font-normal">Gastou</th>
                <th className="pb-2 text-right font-normal">Saldo</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.kid.id} className="border-t border-[#10203A]/8">
                  <td className="py-2.5">
                    <span className="flex items-center gap-2 text-sm">
                      <ChildAvatar child={r.kid} size="sm" />
                      {r.kid.name}
                    </span>
                  </td>
                  <td className="py-2.5 text-right text-sm text-[#0E9B80]">
                    {r.ganho ? formatMoney(r.ganho) : '—'}
                  </td>
                  <td className="py-2.5 text-right text-sm text-[#E04A36]">
                    {r.gasto ? formatMoney(r.gasto) : '—'}
                  </td>
                  <td className="py-2.5 text-right text-sm font-bold">
                    {formatMoney(r.saldo)}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-[#10203A]/15">
                <td className="pt-3 text-[11px] uppercase tracking-[0.16em] text-[#10203A]/45">Turma</td>
                <td className="pt-3 text-right text-sm font-bold text-[#0E9B80]">{formatMoney(totals.ganho)}</td>
                <td className="pt-3 text-right text-sm font-bold text-[#E04A36]">{formatMoney(totals.gasto)}</td>
                <td className="pt-3 text-right font-display text-base" style={{ fontWeight: 1000 }}>
                  {formatMoney(totals.saldo)}
                </td>
              </tr>
            </tfoot>
          </table>

          {rows.length === 0 && (
            <p className="py-8 text-center text-sm text-[#10203A]/45">Nenhuma criança cadastrada.</p>
          )}

          <div className="mt-8 flex items-end justify-between gap-6 border-t border-[#10203A]/10 pt-5">
            <p className="max-w-sm text-[11px] leading-relaxed text-[#10203A]/45">
              Cada ganho foi conquistado em casa, na escola ou com os amigos. Devolva esta folha assinada até
              sexta-feira.
            </p>
            <div className="text-right">
              <div className="mb-1 w-44 border-b border-[#10203A]/30" />
              <p className="text-[10px] uppercase tracking-[0.18em] text-[#10203A]/35">Assinatura da família</p>
            </div>
          </div>
        </div>
      )}

      {!loading && kids.length === 0 && (
        <p className="no-print mt-4 text-center text-sm text-[#10203A]/45">
          Cadastre as crianças para gerar o relatório.
        </p>
      )}
    </div>
  );
}