import PhoneFrame from '@/components/brand/PhoneFrame';
import OnboardingScreen from '@/components/brand/screens/OnboardingScreen';
import HomeScreen from '@/components/brand/screens/HomeScreen';
import GoalsScreen from '@/components/brand/screens/GoalsScreen';
import StatementScreen from '@/components/brand/screens/StatementScreen';
import CardScreen from '@/components/brand/screens/CardScreen';

const screens = [
  {
    label: 'Boas-vindas',
    Screen: OnboardingScreen,
    note: 'Fundo em cor cheia da marca, símbolo grande e uma promessa. Um único botão.',
  },
  {
    label: 'Início',
    Screen: HomeScreen,
    note: 'Saldo no topo em display, quatro atalhos, meta em destaque.',
  },
  {
    label: 'Metas',
    Screen: GoalsScreen,
    note: 'Uma barra por sonho. A cor da barra vem da categoria.',
  },
  {
    label: 'Extrato',
    Screen: StatementScreen,
    note: 'Entradas em menta, saídas em tinta. Nunca vermelho para gasto comum.',
  },
  {
    label: 'Cartão',
    Screen: CardScreen,
    note: 'A capa escolhida no cadastro aparece aqui, com bloqueio rápido.',
  },
];

export default function AppMockups() {
  return (
    <div className="mx-auto max-w-6xl px-6 pb-8 pt-14">
      <span className="mb-4 inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.32em] text-[#10203A]/45">
        <span className="h-1.5 w-1.5 rounded-full bg-[#8B7CF6]" />
        Telas do app
      </span>
      <h1 className="balance max-w-2xl font-display text-[clamp(2.2rem,6vw,3.6rem)] leading-[0.94] tracking-[-0.035em]">
        O app em cinco telas.
      </h1>
      <p className="mt-5 max-w-xl text-base leading-relaxed text-[#10203A]/60">
        A mesma paleta, o mesmo display redondo e o mesmo jeito de falar. No FlutterFlow, cada tela vira uma página com
        as cores e os raios já definidos aqui.
      </p>

      <div className="mt-14 grid gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-5 lg:gap-x-4">
        {screens.map(({ label, Screen, note }) => (
          <div key={label} className="flex flex-col items-center gap-4">
            <PhoneFrame label={label}>
              <Screen />
            </PhoneFrame>
            <p className="max-w-[220px] text-center text-xs leading-relaxed text-[#10203A]/50">{note}</p>
          </div>
        ))}
      </div>

      <div className="mt-16 grid gap-4 rounded-[36px] border border-[#10203A]/10 bg-white p-8 sm:grid-cols-3 sm:p-10">
        {[
          ['Componentes base', 'Botão pílula · campo 52 · cartão 24 · barra 8'],
          ['Navegação', 'Barra inferior com 4 itens e ícone preenchido quando ativo'],
          ['Ícones', 'Traço de 2 px, pontas arredondadas, sempre na tinta'],
        ].map(([t, d]) => (
          <div key={t}>
            <p className="mb-1.5 font-heading text-base font-bold">{t}</p>
            <p className="text-sm leading-relaxed text-[#10203A]/55">{d}</p>
          </div>
        ))}
      </div>
    </div>
  );
}