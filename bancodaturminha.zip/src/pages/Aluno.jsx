import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ChildAvatar from '@/components/kid/ChildAvatar';
import Modal from '@/components/kid/Modal';
import TransactionSheet from '@/components/app/TransactionSheet';
import ChildBadges from '@/components/badges/ChildBadges';
import { invalidateBalances, loadChildTotals } from '@/lib/balances';
import { categoryOf, formatMoney, isoDate, shortDate, weekLabel, weekRange } from '@/lib/money';

export default function Aluno() {
  const { id } = useParams();
  const [child, setChild] = useState(null);
  const [txs, setTxs] = useState([]);
  const [sums, setSums] = useState({ ganho: 0, gasto: 0, weekGanho: 0, weekGasto: 0 });
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [reload, setReload] = useState(0);

  const range = weekRange();

  useEffect(() => {
    let alive = true;
    (async () => {
      const [record, page, totals] = await Promise.all([
        base44.entities.Child.get(id),
        base44.entities.Transaction.filter({ child_id: id }, { sort: '-date', limit: 40 }),
        loadChildTotals(id, isoDate(range.start), isoDate(range.end)),
      ]);
      if (!alive) return;
      setChild(record);
      setTxs(page.items || []);
      setSums(totals);
      setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, [id, reload]);

  if (loading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
      </div>
    );
  }

  if (!child) {
    return (
      <div className="mx-auto max-w-lg px-5 py-24 text-center">
        <h1 className="font-display text-3xl">Criança não encontrada</h1>
        <Link to="/alunos" className="mt-6 inline-block rounded-full bg-[#10203A] px-5 py-3 text-sm text-[#FFF8EF]">
          Voltar para a turma
        </Link>
      </div>
    );
  }

  const balance = sums.ganho - sums.gasto;

  const remove = async (txId) => {
    await base44.entities.Transaction.delete(txId);
    invalidateBalances();
    setReload((r) => r + 1);
  };

  return (
    <div className="mx-auto max-w-4xl px-5 pb-4 pt-6">
      <Link to="/alunos" className="inline-flex items-center gap-1.5 text-sm text-[#10203A]/50 hover:text-[#10203A]">
        <ArrowLeft className="h-4 w-4" /> A turma
      </Link>

      <div className="mt-4 flex flex-wrap items-center gap-4 rounded-[32px] bg-white p-5 brand-hairline sm:p-6">
        <ChildAvatar child={child} size="lg" />
        <div className="min-w-0 flex-1">
          <h1 className="font-display text-2xl leading-none tracking-[-0.03em]">{child.name}</h1>
          <p className="mt-1 text-xs text-[#10203A]/45">Cartão #{child.card_code}</p>
          <p className="mt-3 font-display text-3xl leading-none" style={{ fontWeight: 1000 }}>
            {formatMoney(balance)}
          </p>
        </div>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-2 rounded-full bg-[#10203A] px-5 py-3 text-sm text-[#FFF8EF]"
        >
          <Plus className="h-4 w-4" /> Registrar
        </button>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-3">
        <div className="rounded-[24px] bg-[#D4F7EE] p-4">
          <p className="text-[10px] uppercase tracking-[0.22em] text-[#10203A]/45">Ganhos da semana</p>
          <p className="mt-1 font-display text-xl text-[#0E9B80]" style={{ fontWeight: 1000 }}>
            {formatMoney(sums.weekGanho)}
          </p>
        </div>
        <div className="rounded-[24px] bg-[#FFE1DB] p-4">
          <p className="text-[10px] uppercase tracking-[0.22em] text-[#10203A]/45">Gastos da semana</p>
          <p className="mt-1 font-display text-xl text-[#E04A36]" style={{ fontWeight: 1000 }}>
            {formatMoney(sums.weekGasto)}
          </p>
        </div>
      </div>

      <ChildBadges child={child} classId={child.class_id} />

      <h2 className="mb-3 mt-8 font-heading text-lg font-bold">Histórico</h2>

      {txs.length === 0 ? (
        <p className="rounded-[24px] border border-dashed border-[#10203A]/20 p-8 text-center text-sm text-[#10203A]/45">
          Nenhum registro para {child.name.split(' ')[0]} ainda.
        </p>
      ) : (
        <div className="divide-y divide-[#10203A]/8 overflow-hidden rounded-[24px] bg-white brand-hairline">
          {txs.map((t) => {
            const cat = categoryOf(t.category);
            const income = t.type === 'ganho';
            return (
              <div key={t.id} className="flex items-center gap-3 px-4 py-3">
                <span
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-base"
                  style={{ background: `${cat.color}22` }}
                >
                  {cat.emoji}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-[#10203A]">{cat.label}</p>
                  <p className="truncate text-[11px] text-[#10203A]/45">
                    {shortDate(t.date)}
                    {t.description ? ` · ${t.description}` : ''}
                  </p>
                </div>
                <span
                  className="text-sm"
                  style={{ color: income ? '#0E9B80' : '#E04A36', fontWeight: 700 }}
                >
                  {income ? '+' : '−'} {formatMoney(t.amount)}
                </span>
                <button
                  type="button"
                  onClick={() => remove(t.id)}
                  className="rounded-full p-1.5 text-[#10203A]/25 transition hover:bg-[#FFE1DB] hover:text-[#E04A36]"
                  aria-label="Apagar registro"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      <p className="mt-4 text-xs text-[#10203A]/40">Semana de {weekLabel(range)}</p>

      <Modal open={open} onClose={() => setOpen(false)} title="Novo registro">
        <TransactionSheet
          child={child}
          balance={balance}
          onSaved={() => {
            setOpen(false);
            setReload((r) => r + 1);
          }}
          onCancel={() => setOpen(false)}
        />
      </Modal>
    </div>
  );
}