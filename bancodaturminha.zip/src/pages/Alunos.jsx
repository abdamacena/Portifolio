import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Pencil } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ChildAvatar from '@/components/kid/ChildAvatar';
import ChildForm from '@/components/app/ChildForm';
import { loadBalances } from '@/lib/balances';
import { useClassroom } from '@/lib/ClassContext';
import { formatMoney } from '@/lib/money';

export default function Alunos() {
  const { active, activeId } = useClassroom();
  const [kids, setKids] = useState([]);
  const [balances, setBalances] = useState({});
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [creating, setCreating] = useState(false);
  const [reload, setReload] = useState(0);

  useEffect(() => {
    let alive = true;
    (async () => {
      const [kidsPage, saldos] = await Promise.all([
        base44.entities.Child.filter({ class_id: activeId }, { sort: 'name' }),
        loadBalances(activeId),
      ]);
      if (!alive) return;
      const list = kidsPage.items || [];
      const map = {};
      list.forEach((k) => {
        map[k.id] = saldos[k.id] || 0;
      });
      setKids(list);
      setBalances(map);
      setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, [reload, activeId]);

  const nextCode = String(
    Math.max(0, ...kids.map((k) => Number(k.card_code) || 0)) + 1
  ).padStart(2, '0');

  if (loading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-5 pb-4 pt-8">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[11px] uppercase tracking-[0.28em] text-[#10203A]/40">{active?.name || 'A turma'}</p>
          <h1 className="mt-1 font-display text-3xl leading-none tracking-[-0.03em] sm:text-4xl">
            {kids.length} crianças
          </h1>
        </div>
        <button
          type="button"
          onClick={() => setCreating(true)}
          className="inline-flex items-center gap-2 rounded-full bg-[#10203A] px-5 py-3 text-sm text-[#FFF8EF]"
        >
          <Plus className="h-4 w-4" /> Nova criança
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {kids.map((k) => (
          <div
            key={k.id}
            className="group relative flex items-center gap-3 rounded-[26px] bg-white p-4 brand-hairline"
          >
            <Link to={`/alunos/${k.id}`} className="flex min-w-0 flex-1 items-center gap-3">
              <ChildAvatar child={k} size="md" />
              <div className="min-w-0">
                <p className="truncate text-sm leading-tight text-[#10203A]">{k.name}</p>
                <p className="text-[11px] text-[#10203A]/45">
                  Cartão #{k.card_code} · {formatMoney(balances[k.id] || 0)}
                </p>
              </div>
            </Link>
            <button
              type="button"
              onClick={() => setEditing(k)}
              className="rounded-full p-2 text-[#10203A]/35 transition hover:bg-[#10203A]/5 hover:text-[#10203A]"
              aria-label={`Editar ${k.name}`}
            >
              <Pencil className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>

      {creating && (
        <ChildForm
          nextCode={nextCode}
          classId={activeId}
          onClose={() => setCreating(false)}
          onSaved={() => {
            setCreating(false);
            setReload((r) => r + 1);
          }}
        />
      )}

      {editing && (
        <ChildForm
          child={editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            setReload((r) => r + 1);
          }}
        />
      )}
    </div>
  );
}