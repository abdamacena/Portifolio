import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Printer } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import CardCover from '@/components/brand/CardCover';
import Logo from '@/components/brand/Logo';
import NfcWriter from '@/components/app/NfcWriter';
import { cardVariants } from '@/lib/brand';
import { useClassroom } from '@/lib/ClassContext';

export default function Cartoes() {
  const { active: turma, activeId } = useClassroom();
  const [active, setActive] = useState('manga');
  const [holder, setHolder] = useState('Lia');
  const [kids, setKids] = useState([]);
  const selected = cardVariants.find((c) => c.id === active) || cardVariants[0];

  useEffect(() => {
    (async () => {
      const page = await base44.entities.Child.filter({ class_id: activeId }, { sort: 'name' });
      setKids(page.items || []);
    })();
  }, [activeId]);

  return (
    <div className="mx-auto max-w-6xl px-5 pb-4 pt-8">
      <div className="no-print">
        <p className="text-[11px] uppercase tracking-[0.28em] text-[#10203A]/40">Cartões · {turma?.name || 'turma'}</p>
        <h1 className="mt-1 font-display text-3xl leading-none tracking-[-0.03em] sm:text-4xl">
          Cada criança com o seu cartão
        </h1>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-[#10203A]/55">
          Cada criança recebe um animal, um número e uma etiqueta NFC. É pelo animal que ela reconhece o cartão; encostar
          a etiqueta no celular abre a página da criança.
        </p>

        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_1fr] lg:items-start">
          <div className="rounded-[32px] bg-white p-5 brand-hairline sm:p-6">
            <div className="mx-auto max-w-sm">
              <CardCover variant={selected} holder={holder || 'Lia'} />
            </div>
            <div className="mx-auto mt-6 max-w-sm space-y-4">
              <label className="block">
                <span className="mb-2 block text-[10px] uppercase tracking-[0.24em] text-[#10203A]/40">
                  Nome no cartão
                </span>
                <input
                  value={holder}
                  onChange={(e) => setHolder(e.target.value.slice(0, 14))}
                  placeholder="Lia"
                  className="h-[50px] w-full rounded-2xl border border-[#10203A]/12 bg-[#FFF8EF] px-4 text-[15px] uppercase tracking-wide outline-none focus:border-[#10203A] focus:ring-4 focus:ring-[#FFB627]/25"
                />
              </label>
              <div>
                <span className="mb-2 block text-[10px] uppercase tracking-[0.24em] text-[#10203A]/40">Capa</span>
                <div className="flex flex-wrap gap-2">
                  {cardVariants.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setActive(c.id)}
                      className={`flex items-center gap-2 rounded-full border py-1.5 pl-1.5 pr-4 text-sm transition ${
                        active === c.id
                          ? 'border-[#10203A] bg-[#10203A] text-[#FFF8EF]'
                          : 'border-[#10203A]/12 text-[#10203A]/70 hover:border-[#10203A]/30'
                      }`}
                    >
                      <span
                        className="h-6 w-6 rounded-full"
                        style={{ background: c.base, boxShadow: 'inset 0 0 0 1px rgba(16,32,58,.15)' }}
                      />
                      {c.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {cardVariants.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setActive(c.id)}
                className={`flex w-full items-center gap-4 rounded-[26px] border p-3 text-left transition ${
                  active === c.id
                    ? 'border-[#10203A]/25 bg-white shadow-[0_20px_50px_-34px_rgba(16,32,58,0.5)]'
                    : 'border-[#10203A]/10 bg-white/60 hover:bg-white'
                }`}
              >
                <div className="w-24 shrink-0">
                  <CardCover variant={c} holder="Lia" compact className="rounded-[10px] shadow-none" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-heading text-lg font-bold leading-none">{c.name}</h3>
                    <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-[#10203A]/35">
                      {c.base}
                    </span>
                  </div>
                  <p className="mt-1.5 text-sm leading-snug text-[#10203A]/55">{c.note}</p>
                </div>
              </button>
            ))}

            <Link
              to="/cadastro"
              className="flex items-center justify-between rounded-[26px] border border-dashed border-[#10203A]/25 p-4 text-sm text-[#10203A]/60 hover:border-[#10203A]/45"
            >
              Ficha de cadastro para as famílias
              <span>→</span>
            </Link>
          </div>
        </div>

        <NfcWriter kids={kids} />

        <div className="mt-12 flex flex-wrap items-center justify-between gap-3 border-t border-[#10203A]/10 pt-6">
          <div>
            <h2 className="font-heading text-xl font-bold">Folha pronta para imprimir</h2>
            <p className="mt-1 text-sm text-[#10203A]/50">
              Um cartão por criança, com marca de corte. Imprima em papel couché 300 g.
            </p>
          </div>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 rounded-full bg-[#10203A] px-5 py-3 text-sm text-[#FFF8EF]"
          >
            <Printer className="h-4 w-4" /> Imprimir cartões
          </button>
        </div>
      </div>

      {/* Folha de impressão */}
      <div className="print-sheet mt-6 rounded-[32px] bg-white p-6 brand-hairline">
        <div className="mb-5 flex items-center justify-between border-b border-[#10203A]/10 pb-4">
          <Logo size="sm" />
          <p className="text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">
            {turma?.name || 'Cartões'} · {kids.length} crianças
          </p>
        </div>

        {kids.length === 0 ? (
          <p className="py-10 text-center text-sm text-[#10203A]/45">
            Cadastre as crianças em “Crianças” para gerar a folha de cartões.
          </p>
        ) : (
          <div className="cards-a4 grid gap-4 sm:grid-cols-2">
            {kids.map((k) => (
              <div
                key={k.id}
                className="print-break rounded-2xl border border-dashed border-[#10203A]/25 p-2.5"
              >
                <CardCover
                  variant={k.cover}
                  holder={k.nickname || k.name}
                  symbol={k.symbol || '🐻'}
                  login={k.login}
                  childId={k.id}
                  compact
                  className="rounded-[12px] shadow-none"
                />
                <p className="card-caption mt-2 px-1 text-[10px] leading-relaxed text-[#10203A]/55">
                  <span className="text-[13px] leading-none">{k.symbol || '🐻'}</span>{' '}
                  <strong className="font-semibold text-[#10203A]">{k.nickname || k.name}</strong>
                  {' · cartão #'}
                  {k.card_code}
                  {k.login ? ` · login ${k.login}` : ''}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}