import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { forgetFamilyAccess } from '@/lib/familyDevice';
import PublicNav from '@/components/site/PublicNav';
import SiteTabBar from '@/components/site/SiteTabBar';
import FamilyAccess from '@/components/site/FamilyAccess';
import FamilyStatement from '@/components/site/FamilyStatement';
import FamilyTasks from '@/components/site/FamilyTasks';

export default function Familia() {
  const [state, setState] = useState('loading');
  const [data, setData] = useState({ children: [] });
  const [email, setEmail] = useState('');
  const [access, setAccess] = useState(null);
  const [error, setError] = useState('');

  const loadDevice = async (creds, silent = false) => {
    if (!silent) setState('loading');
    setError('');
    try {
      const res = await base44.functions.invoke('entrarFamilia', creds);
      if (res.data?.error) throw new Error(res.data.error);
      setData({ children: [res.data.child] });
      setEmail(`@${res.data.child?.login || creds.login}`);
      setAccess(creds);
      setState('ready');
    } catch (err) {
      setError(err?.response?.data?.error || err?.message || 'Não foi possível carregar o extrato agora.');
      setState('error');
    }
  };

  const load = async (silent = false) => {
    if (!silent) setState('loading');
    setError('');
    try {
      const me = await base44.auth.me();
      setEmail(me?.email || '');
    } catch {
      setState('anon');
      return;
    }

    try {
      const res = await base44.functions.invoke('extratoFamilia', {});
      if (res.data?.error) throw new Error(res.data.error);
      setData(res.data || { children: [] });
      setAccess(null);
      setState('ready');
    } catch (err) {
      setError(err?.response?.data?.error || err?.message || 'Não foi possível carregar o extrato agora.');
      setState('error');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const enter = (creds) => {
    if (creds?.class_code && creds?.login && creds?.birth_date) {
      loadDevice(creds);
      return;
    }
    load();
  };

  const refresh = () => (access ? loadDevice(access, true) : load(true));

  const sair = () => {
    forgetFamilyAccess();
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-[#EDE3D3]">
      <div className="relative mx-auto min-h-screen w-full max-w-[430px] bg-[#FFF8EF] pb-24 shadow-[0_30px_90px_-40px_rgba(16,32,58,0.5)]">
        <PublicNav />

        {state === 'loading' && (
          <div className="flex min-h-[50vh] items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin text-[#10203A]/30" />
          </div>
        )}

        {state === 'anon' && <FamilyAccess onLoggedIn={enter} />}

        {state === 'ready' && (data.children || []).length === 0 && <FamilyAccess onLoggedIn={enter} />}

        {state === 'ready' && (data.children || []).length > 0 && (
          <FamilyStatement children={data.children || []} email={email} onExit={access ? sair : undefined} />
        )}

        {state === 'ready' && (data.children || []).length > 0 && (
          <FamilyTasks children={data.children} access={access} onRegistered={refresh} />
        )}

        {state === 'error' && (
          <section className="px-5 pt-8">
            <div className="rounded-[28px] bg-[#FFE1DB] p-5 text-[13px] leading-relaxed text-[#B23A28]">{error}</div>
            <button
              type="button"
              onClick={() => (access ? loadDevice(access) : load())}
              className="mt-3 w-full rounded-2xl bg-[#10203A] py-3.5 text-sm text-[#FFF8EF]"
            >
              Tentar de novo
            </button>
          </section>
        )}

        <SiteTabBar />
      </div>
    </div>
  );
}