import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { TrendingDown, TrendingUp, Users, Wallet } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ChildAvatar from '@/components/kid/ChildAvatar';
import { loadBalances, loadWeekTotals } from '@/lib/balances';
import { useClassroom } from '@/lib/ClassContext';
import { categoryOf, formatMoney, isoDate, shortDate, weekLabel, weekRange } from '@/lib/money';

export default function Home() {
  const { active, activeId } = useClassroom();
  const [loading, setLoading] = useState(true);
  const [kids, setKids] = useState([]);
  const [balances, setBalances] = useState({});
  const [week, setWeek] = useState({ ganho: 0, gasto: 0 });
  const [recent, setRecent] = useState([]);
  const [knownAs, setKnownAs] = useState('');

  const range = weekRange();

  useEffect(() => {
    let alive = true;
    base44.auth
      .me()
      .then((me) => {
        if (!alive) return;
        setKnownAs(me?.display_name || (me?.full_name || '').split(' ')[0] || '');
      })
      .catch(() => {});
    (async () => {
      const [kidsPage, saldos, weekTotals, latest] = await Promise.all([
        base44.entities.Child.filter({ class_id: activeId }, { sort: 'name' }),
        loadBalances(activeId),
        loadWeekTotals(isoDate(range.start), isoDate(range.end), activeId),
        base44.entities.Transaction.filter({ class_id: activeId }, { sort: '-created_date', limit: 6 }),
      ]);
      if (!alive) return;

      const list = kidsPage.items || [];
      const map = {};
      list.forEach((k) => {
        map[k.id] = saldos[k.id] || 0;
      });

      setKids(list);
      setBalances(map);
      setWeek(weekTotals);
      setRecent(latest.items || []);
      setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, [activeId]);

  const total = kids.reduce((sum, k) => sum + (balances[k.id] || 0), 0);

  if (loading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-5 pb-4 pt-8">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[11px] uppercase tracking-[0.28em] text-[#10203A]/40">
            {active?.name || 'Sua turma'} · semana de {weekLabel(range)}
          </p>
          <h1 className="mt-1 font-display text-3xl leading-none tracking-[-0.03em] sm:text-4xl">
            Olá, {knownAs || 'professora'}
          </h1>
        </div>
        <Link to="/relatorios" className="text-sm text-[#10203A]/55 hover:text-[#10203A]">
          Relatório da semana →
        </Link>
      </div>

      {/* Resumo */}
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-[28px] bg-[#10203A] p-5 text-[#FFF8EF]">
          <span className="mb-3 flex h-9 w-9 items-center justify-center rounded-2xl bg-white/10">
            <Wallet className="h-4 w-4" />
          </span>
          <p className="text-[10px] uppercase tracking-[0.24em] text-[#FFF8EF]/50">Saldo da turma</p>
          <p className="mt-1 font-display text-2xl leading-none" style={{ fontWeight: 1000 }}>
            {formatMoney(total)}
          </p>
        </div>
        <div className="rounded-[28px] bg-[#D4F7EE] p-5">
          <span className="mb-3 flex h-9 w-9 items-center justify-center rounded-2xl bg-[#12C2A0]/20 text-[#0E9B80]">
            <TrendingUp className="h-4 w-4" />
          </span>
          <p className="text-[10px] uppercase tracking-[0.24em] text-[#10203A]/45">Ganhos na semana</p>
          <p className="mt-1 font-display text-2xl leading-none text-[#0E9B80]" style={{ fontWeight: 1000 }}>
            {formatMoney(week.ganho)}
          </p>
        </div>
        <div className="rounded-[28px] bg-[#FFE1DB] p-5">
          <span className="mb-3 flex h-9 w-9 items-center justify-center rounded-2xl bg-[#FF6B57]/20 text-[#E04A36]">
            <TrendingDown className="h-4 w-4" />
          </span>
          <p className="text-[10px] uppercase tracking-[0.24em] text-[#10203A]/45">Gastos na semana</p>
          <p className="mt-1 font-display text-2xl leading-none text-[#E04A36]" style={{ fontWeight: 1000 }}>
            {formatMoney(week.gasto)}
          </p>
        </div>
      </div>

      {/* Crianças */}
      <section className="mt-10">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 font-heading text-xl font-bold">
            <Users className="h-4 w-4 text-[#10203A]/40" />
            {kids.length} crianças
          </h2>
          <Link to="/alunos" className="text-sm text-[#10203A]/55 hover:text-[#10203A]">
            Gerenciar →
          </Link>
        </div>

        {kids.length === 0 ? (
          <div className="rounded-[28px] border border-dashed border-[#10203A]/20 p-10 text-center">
            <p className="text-sm text-[#10203A]/55">Nenhuma criança cadastrada ainda.</p>
            <Link
              to="/alunos"
              className="mt-4 inline-block rounded-full bg-[#10203A] px-5 py-2.5 text-sm text-[#FFF8EF]"
            >
              Cadastrar a primeira
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {kids.map((k) => (
              <Link
                key={k.id}
                to={`/alunos/${k.id}`}
                className="flex items-center gap-3 rounded-[24px] bg-white p-3 brand-hairline transition-transform duration-200 hover:-translate-y-0.5"
              >
                <ChildAvatar child={k} />
                <div className="min-w-0">
                  <p className="truncate text-sm leading-tight text-[#10203A]">{k.name.split(' ')[0]}</p>
                  <p className="text-[11px] text-[#10203A]/45">{formatMoney(balances[k.id] || 0)}</p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* Movimentações */}
      <section className="mt-10">
        <h2 className="mb-4 font-heading text-xl font-bold">Últimos registros</h2>
        {recent.length === 0 ? (
          <p className="rounded-[24px] border border-dashed border-[#10203A]/20 p-8 text-center text-sm text-[#10203A]/45">
            Nada registrado ainda.
          </p>
        ) : (
          <div className="divide-y divide-[#10203A]/8 overflow-hidden rounded-[24px] bg-white brand-hairline">
            {recent.map((t) => {
              const cat = categoryOf(t.category);
              const income = t.type === 'ganho';
              return (
                <div key={t.id} className="flex items-center gap-3 px-4 py-3">
                  <span
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-base"
                    style={{ background: `${cat.color}22` }}
                  >
                    {cat.emoji}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm text-[#10203A]">{t.child_name || 'Criança'}</p>
                    <p className="text-[11px] text-[#10203A]/45">
                      {cat.label} · {shortDate(t.date)}
                    </p>
                  </div>
                  <span
                    className="text-sm"
                    style={{ color: income ? '#0E9B80' : '#E04A36', fontWeight: 700 }}
                  >
                    {income ? '+' : '−'} {formatMoney(t.amount)}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}