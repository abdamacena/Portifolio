import { useEffect, useState } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { ArrowRight, LogIn, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import Logo from '@/components/brand/Logo';
import CrayonDoodles from '@/components/kid/CrayonDoodles';
import { useAuth } from '@/lib/AuthContext';

export default function Entrar() {
  const { user } = useAuth();
  const [target, setTarget] = useState('');

  useEffect(() => {
    if (!user) {
      setTarget('');
      return;
    }
    let alive = true;
    (async () => {
      if (user.role === 'admin') {
        setTarget('/inicio');
        return;
      }
      const total = await base44.entities.Turma.count({});
      if (alive) setTarget(total > 0 ? '/inicio' : '/familia');
    })();
    return () => {
      alive = false;
    };
  }, [user]);

  if (user) {
    if (!target) {
      return (
        <div className="flex min-h-screen items-center justify-center bg-[#FFF8EF]">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
        </div>
      );
    }
    return <Navigate to={target} replace />;
  }

  return (
    <div className="min-h-screen bg-[#FFF8EF] px-5 py-10">
      <div className="mx-auto flex min-h-[calc(100vh-5rem)] w-full max-w-md flex-col">
        <header className="text-center">
          <Logo size="lg" className="justify-center" stacked />
          <p className="mt-4 text-sm leading-relaxed text-[#10203A]/55">
            Moedinhas que ensinam a cuidar. Escolha por onde entrar.
          </p>
        </header>

        <div className="mt-10 space-y-4">
          <Link
            to="/familia"
            className="relative block overflow-hidden rounded-[32px] bg-[#FFB627] p-6 transition-transform active:scale-[0.99]"
          >
            <CrayonDoodles />
            <div className="relative">
              <span className="inline-flex items-center gap-2 rounded-full bg-[#10203A]/10 px-3 py-1 text-[10px] uppercase tracking-[0.22em] text-[#10203A]/70">
                <Users className="h-3.5 w-3.5" /> Famílias
              </span>
              <h2 className="mt-3 font-display text-2xl leading-none tracking-[-0.03em]" style={{ fontWeight: 1000 }}>
                Área de família
              </h2>
              <p className="mt-2 max-w-[16rem] text-sm leading-snug text-[#10203A]/65">
                Faça o cadastro da criança com a ficha completa ou entre para ver o extrato.
              </p>
              <span className="mt-4 inline-flex items-center gap-2 text-sm text-[#10203A]">
                Entrar na área <ArrowRight className="h-4 w-4" />
              </span>
            </div>
          </Link>

          <Link
            to="/professora"
            className="block rounded-[32px] bg-[#10203A] p-6 text-[#FFF8EF] transition-transform active:scale-[0.99]"
          >
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-[10px] uppercase tracking-[0.22em] text-[#FFF8EF]/70">
              <LogIn className="h-3.5 w-3.5" /> Professora
            </span>
            <h2 className="mt-3 font-display text-2xl leading-none tracking-[-0.03em]" style={{ fontWeight: 1000 }}>
              Entrar no meu banco
            </h2>
            <p className="mt-2 max-w-[16rem] text-sm leading-snug text-[#FFF8EF]/65">
              Turmas, cartões e moedinhas do dia a dia da sala.
            </p>
            <span className="mt-4 inline-flex items-center gap-2 text-sm">
              Entrar <ArrowRight className="h-4 w-4" />
            </span>
          </Link>

        </div>

        <div className="mt-auto pt-8 text-center">
          <Link to="/" className="text-xs text-[#10203A]/50 underline">
            Conhecer o projeto
          </Link>
        </div>
      </div>
    </div>
  );
}