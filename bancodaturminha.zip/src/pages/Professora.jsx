import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, GraduationCap, School, Users } from 'lucide-react';
import PublicNav from '@/components/site/PublicNav';
import SiteTabBar from '@/components/site/SiteTabBar';

const steps = [
  { icon: GraduationCap, title: 'Sua conta', text: 'Nome, e-mail e senha. É por ela que você entra todos os dias.' },
  { icon: School, title: 'Escola e turma', text: 'O nome da escola e da turma. O app gera um código da turma.' },
  {
    icon: Users,
    title: 'As crianças',
    text: 'Depois você cadastra os alunos e imprime os cartões com etiqueta NFC. Ao encostar o cartão no leitor NFC, abre a página individual de cada aluno.',
  },
];

export default function Professora() {
  const [mode, setMode] = useState('entrar');

  return (
    <div className="min-h-screen bg-[#EDE3D3]">
      <div className="relative mx-auto min-h-screen w-full max-w-[430px] bg-[#FFF8EF] pb-24 shadow-[0_30px_90px_-40px_rgba(16,32,58,0.5)]">
        <PublicNav />

        <section id="professora" className="scroll-mt-20 px-5 pt-6">
          <p className="text-[10px] uppercase tracking-[0.26em] text-[#10203A]/40">Área da professora</p>
          <h1 className="balance mt-2 font-display text-[2rem] leading-[0.95] tracking-[-0.035em]">
            {mode === 'entrar' ? 'O banco da sua turma.' : 'Abrir o banco da turma.'}
          </h1>

          <div className="mt-4 grid grid-cols-2 gap-1 rounded-full bg-[#10203A]/6 p-1">
            {[
              { id: 'entrar', label: 'Entrar' },
              { id: 'criar', label: 'Criar cadastro' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setMode(tab.id)}
                className={`rounded-full py-2 text-[12px] transition-colors ${
                  mode === tab.id ? 'bg-[#10203A] text-[#FFF8EF]' : 'text-[#10203A]/60'
                }`}
                aria-pressed={mode === tab.id}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {mode === 'entrar' ? (
            <div className="mt-4 rounded-[28px] border border-[#10203A]/10 bg-white p-5">
              <p className="text-[13px] leading-relaxed text-[#10203A]/60">
                Entre com o e-mail e a senha da sua conta para ler os cartões, registrar moedinhas e enviar o relatório
                da semana.
              </p>
              <Link
                to="/login"
                className="mt-4 flex h-14 items-center justify-center gap-2 rounded-2xl bg-[#10203A] text-[15px] text-[#FFF8EF] transition active:scale-[0.99]"
              >
                Entrar na minha conta <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/forgot-password" className="mt-3 block text-center text-[12px] text-[#10203A]/55 underline">
                Esqueci a senha
              </Link>
            </div>
          ) : (
            <div className="mt-4 rounded-[28px] border border-[#10203A]/10 bg-white p-5">
              <p className="text-[13px] leading-relaxed text-[#10203A]/60">
                Em três passos o banco da turma está no ar. As famílias recebem o código da turma para cadastrar as
                crianças.
              </p>

              <ol className="mt-4 space-y-3">
                {steps.map((step, i) => (
                  <li key={step.title} className="flex gap-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#FFB627]/25 text-[#10203A]">
                      <step.icon className="h-4 w-4" />
                    </span>
                    <div className="min-w-0">
                      <p className="font-heading text-sm font-bold leading-tight">
                        {i + 1}. {step.title}
                      </p>
                      <p className="mt-0.5 text-[12px] leading-snug text-[#10203A]/50">{step.text}</p>
                    </div>
                  </li>
                ))}
              </ol>

              <Link
                to="/cadastro-professora"
                className="mt-4 flex h-14 items-center justify-center gap-2 rounded-2xl bg-[#10203A] text-[15px] text-[#FFF8EF] transition active:scale-[0.99]"
              >
                Criar conta da professora <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          )}
        </section>

        <SiteTabBar />
      </div>
    </div>
  );
}