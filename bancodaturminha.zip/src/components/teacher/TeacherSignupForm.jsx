import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import MfaFlow from '@/components/MfaFlow';
import { MfaScreen } from '@/components/MfaParts';

const field = 'h-12 rounded-2xl border-[#10203A]/15 bg-white text-[15px] text-[#10203A]';

function Field({ id, label, ...props }) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">
        {label}
      </Label>
      <Input id={id} className={field} {...props} />
    </div>
  );
}

export default function TeacherSignupForm() {
  const [step, setStep] = useState('form');
  const [known, setKnown] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [code, setCode] = useState('');
  const [challenge, setChallenge] = useState(null);
  const [error, setError] = useState('');
  const [emailTaken, setEmailTaken] = useState(false);
  const [loading, setLoading] = useState(false);

  const cleanEmail = email.trim().toLowerCase();

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setEmailTaken(false);
    if (known.trim().length < 2) return setError('Escreva como você é conhecida.');
    if (password !== confirm) return setError('As senhas não conferem.');
    if (password.length < 6) return setError('Use uma senha com pelo menos 6 caracteres.');
    setLoading(true);
    try {
      await base44.auth.register({ email: cleanEmail, password });
      setStep('otp');
    } catch (err) {
      if (err?.response?.status === 409) {
        setEmailTaken(true);
        setError('Este e-mail já tem uma conta neste banco. Entre com a senha que você criou.');
      } else {
        setError(err?.response?.data?.message || err?.message || 'Não foi possível criar a conta agora.');
      }
    } finally {
      setLoading(false);
    }
  };

  const verify = async () => {
    setError('');
    setLoading(true);
    try {
      const res = await base44.auth.verifyOtp({ email: cleanEmail, otpCode: code });
      if (res?.mfa_required) {
        setChallenge(res);
        return;
      }
      if (res?.access_token) {
        base44.auth.setToken(res.access_token);
        await base44.auth.updateMe({ display_name: known.trim() }).catch(() => {});
      }
      window.location.href = '/cadastro-professora';
    } catch (err) {
      setError(err.message || 'Código inválido.');
    } finally {
      setLoading(false);
    }
  };

  const resend = async () => {
    setError('');
    try {
      await base44.auth.resendOtp(cleanEmail);
      setCode('');
    } catch (err) {
      setError(err.message || 'Não foi possível reenviar o código.');
    }
  };

  if (challenge) {
    return (
      <MfaScreen>
        <MfaFlow challenge={challenge} returnTo="/cadastro-professora" />
      </MfaScreen>
    );
  }

  if (step === 'otp') {
    return (
      <div className="space-y-4">
        <div>
          <p className="text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">Confirme o e-mail</p>
          <p className="mt-1 text-[13px] leading-relaxed text-[#10203A]/55">
            Enviamos um código de 6 dígitos para <span className="text-[#10203A]">{cleanEmail}</span>.
          </p>
        </div>

        <div className="flex justify-center">
          <InputOTP maxLength={6} value={code} onChange={setCode} autoFocus autoComplete="one-time-code">
            <InputOTPGroup>
              <InputOTPSlot index={0} />
              <InputOTPSlot index={1} />
              <InputOTPSlot index={2} />
              <InputOTPSlot index={3} />
              <InputOTPSlot index={4} />
              <InputOTPSlot index={5} />
            </InputOTPGroup>
          </InputOTP>
        </div>

        {error && <p className="rounded-2xl bg-[#FFE1DB] px-4 py-3 text-[13px] text-[#B23A28]">{error}</p>}

        <button
          type="button"
          onClick={verify}
          disabled={loading || code.length < 6}
          className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-[#10203A] text-[15px] text-[#FFF8EF] disabled:opacity-60"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
          {loading ? 'Confirmando…' : 'Confirmar código'}
        </button>

        <div className="flex items-center justify-between text-[12px] text-[#10203A]/55">
          <button type="button" onClick={resend} className="underline">
            Reenviar código
          </button>
          <button
            type="button"
            onClick={() => {
              setStep('form');
              setCode('');
              setError('');
            }}
            className="inline-flex items-center gap-1 underline"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Trocar e-mail
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-3">
      <Field
        id="teacher-known"
        label="Como você é conhecida"
        autoComplete="nickname"
        placeholder="Prof. Cíntia"
        maxLength={40}
        value={known}
        onChange={(e) => setKnown(e.target.value)}
        required
      />
      <Field
        id="teacher-email"
        label="E-mail"
        type="email"
        autoComplete="email"
        placeholder="voce@email.com"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      <Field
        id="teacher-password"
        label="Senha"
        type="password"
        autoComplete="new-password"
        placeholder="••••••••"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <Field
        id="teacher-confirm"
        label="Confirmar senha"
        type="password"
        autoComplete="new-password"
        placeholder="••••••••"
        value={confirm}
        onChange={(e) => setConfirm(e.target.value)}
        required
      />

      {error && (
        <div className="rounded-2xl bg-[#FFE1DB] px-4 py-3 text-[13px] leading-relaxed text-[#B23A28]">
          <p>{error}</p>
          {emailTaken && (
            <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[12px]">
              <Link to="/login" className="underline">
                Entrar com esta conta
              </Link>
              <Link to="/forgot-password" className="underline">
                Esqueci a senha
              </Link>
            </div>
          )}
        </div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-[#10203A] text-[15px] text-[#FFF8EF] disabled:opacity-60"
      >
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
        {loading ? 'Criando conta…' : 'Criar conta com e-mail e senha'}
      </button>
      <p className="text-center text-[11px] leading-relaxed text-[#10203A]/45">
        Enviamos um código de 6 dígitos para confirmar o e-mail no primeiro cadastro.
      </p>
    </form>
  );
}