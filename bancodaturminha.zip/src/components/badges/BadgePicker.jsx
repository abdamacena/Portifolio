import { useState } from 'react';
import { Loader2, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import Modal from '@/components/kid/Modal';
import BadgeStamp from '@/components/badges/BadgeStamp';
import { badgeCatalog, badgeOf } from '@/lib/badges';
import { isoDate } from '@/lib/money';

export default function BadgePicker({ child, classId, given = [], onClose, onSaved }) {
  const [selected, setSelected] = useState('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  if (!child) return null;

  const give = async () => {
    if (!selected) return setError('Escolha um selo primeiro.');
    setSaving(true);
    setError('');
    try {
      let teacherId = child.teacher_user_id;
      if (!teacherId) {
        const me = await base44.auth.me();
        teacherId = me?.id || '';
      }
      await base44.entities.Badge.create({
        child_id: child.id,
        child_name: child.name,
        class_id: classId || child.class_id || '',
        badge_id: selected,
        note: note.trim(),
        date: isoDate(new Date()),
        teacher_user_id: teacherId,
      });
      setSelected('');
      setNote('');
      onSaved();
    } catch (err) {
      setError(err?.message || 'Não foi possível entregar agora.');
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id) => {
    setSaving(true);
    try {
      await base44.entities.Badge.delete(id);
      onSaved();
    } catch (err) {
      setError(err?.message || 'Não foi possível apagar agora.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={child.nickname || child.name}
      subtitle="Qual selo ela conquistou?"
    >
      <div className="grid grid-cols-2 gap-2">
        {badgeCatalog.map((b) => {
          const on = selected === b.id;
          return (
            <button
              key={b.id}
              type="button"
              onClick={() => setSelected(b.id)}
              aria-pressed={on}
              className={`flex items-center gap-2 rounded-2xl border px-2.5 py-2 text-left transition ${
                on ? 'border-[#10203A] bg-[#FFB627]/20' : 'border-[#10203A]/12 bg-white'
              }`}
            >
              <BadgeStamp badgeId={b.id} size="sm" showLabel={false} />
              <span className="min-w-0">
                <span className="block truncate text-[12px] leading-tight text-[#10203A]">{b.label}</span>
                <span className="block text-[10px] leading-tight text-[#10203A]/45">{b.hint}</span>
              </span>
            </button>
          );
        })}
      </div>

      <label className="mt-3 block">
        <span className="mb-1.5 block text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">
          Recado para a família (opcional)
        </span>
        <input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Ex.: guardou para o passeio da turma."
          className="w-full rounded-2xl border border-[#10203A]/12 bg-white px-3 py-2.5 text-[13px] outline-none focus:border-[#10203A]/40"
        />
      </label>

      {given.length > 0 && (
        <div className="mt-4">
          <p className="mb-1.5 text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">Já entregues</p>
          <div className="space-y-1">
            {given.map((g) => (
              <div key={g.id} className="flex items-center gap-2 rounded-2xl bg-[#10203A]/4 px-2.5 py-1.5">
                <span className="text-sm" aria-hidden="true">{badgeOf(g.badge_id).emoji}</span>
                <span className="min-w-0 flex-1 truncate text-[12px] text-[#10203A]/70">
                  {badgeOf(g.badge_id).label}
                  {g.note ? ` · ${g.note}` : ''}
                </span>
                <button
                  type="button"
                  onClick={() => remove(g.id)}
                  disabled={saving}
                  className="rounded-full p-1 text-[#10203A]/30 hover:bg-[#FFE1DB] hover:text-[#E04A36]"
                  aria-label="Apagar selo"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {error && <p className="mt-3 rounded-2xl bg-[#FFE1DB] px-4 py-3 text-[13px] text-[#B23A28]">{error}</p>}

      <button
        type="button"
        onClick={give}
        disabled={saving}
        className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#10203A] px-6 py-3.5 text-sm text-[#FFF8EF] disabled:opacity-60"
      >
        {saving && <Loader2 className="h-4 w-4 animate-spin" />}
        Entregar selo
      </button>
    </Modal>
  );
}