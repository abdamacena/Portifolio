import { useEffect, useState } from 'react';
import { Award, Plus } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import BadgeStamp from '@/components/badges/BadgeStamp';
import BadgePicker from '@/components/badges/BadgePicker';

export default function ChildBadges({ child, classId }) {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);

  const load = async () => {
    const page = await base44.entities.Badge.filter({ child_id: child.id }, { sort: '-date', limit: 40 });
    setItems(page.items || []);
  };

  useEffect(() => {
    load();
  }, [child.id]);

  return (
    <section className="mt-3 rounded-[24px] bg-white p-4 brand-hairline">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[10px] uppercase tracking-[0.22em] text-[#10203A]/45">Selos</p>
          <p className="text-[12px] text-[#10203A]/50">
            {items.length === 0 ? 'Nenhum selo ainda' : `${items.length} selo${items.length > 1 ? 's' : ''} · a família vê no extrato`}
          </p>
        </div>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-[#10203A]/15 px-3.5 py-2 text-[12px] text-[#10203A]"
        >
          <Plus className="h-3.5 w-3.5" /> Dar selo
        </button>
      </div>

      {items.length === 0 ? (
        <p className="mt-3 flex items-center gap-2 rounded-2xl bg-[#FFF8EF] px-3 py-2.5 text-[12px] text-[#10203A]/50">
          <Award className="h-4 w-4 shrink-0" /> Entregue uma medalha quando {child.nickname || child.name} guardar,
          doar ou esperar.
        </p>
      ) : (
        <div className="mt-3 flex flex-wrap gap-2.5">
          {items.map((b) => (
            <BadgeStamp key={b.id} badgeId={b.badge_id} size="md" />
          ))}
        </div>
      )}

      {open && (
        <BadgePicker
          child={child}
          classId={classId}
          given={items}
          onClose={() => setOpen(false)}
          onSaved={load}
        />
      )}
    </section>
  );
}