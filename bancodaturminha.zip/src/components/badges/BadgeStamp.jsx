import { badgeOf } from '@/lib/badges';
import { cn } from '@/lib/utils';

const sizes = {
  sm: 'h-9 w-9 text-base',
  md: 'h-12 w-12 text-xl',
  lg: 'h-16 w-16 text-2xl',
};

export default function BadgeStamp({ badgeId, size = 'md', showLabel = true, className }) {
  const badge = badgeOf(badgeId);

  return (
    <span className={cn('inline-flex flex-col items-center gap-1', className)} title={badge.hint}>
      <span
        className={cn('flex items-center justify-center rounded-full leading-none', sizes[size] || sizes.md)}
        style={{ background: `${badge.color}22`, boxShadow: `inset 0 0 0 2px ${badge.color}` }}
        aria-hidden="true"
      >
        {badge.emoji}
      </span>
      {showLabel && (
        <span className="max-w-[62px] text-center text-[9px] leading-tight text-[#10203A]/60">{badge.label}</span>
      )}
    </span>
  );
}