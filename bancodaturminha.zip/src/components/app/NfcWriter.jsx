import { useState } from 'react';
import { Check, Loader2, Nfc } from 'lucide-react';
import ChildAvatar from '@/components/kid/ChildAvatar';
import { cardQrValue } from '@/components/kid/QrTag';
import { nfcSupported, writeCardTag } from '@/lib/nfc';

export default function NfcWriter({ kids }) {
  const [writingId, setWritingId] = useState('');
  const [doneId, setDoneId] = useState('');
  const [msg, setMsg] = useState('');
  const supported = nfcSupported();

  const write = async (kid) => {
    setMsg('');
    setDoneId('');
    setWritingId(kid.id);
    try {
      await writeCardTag(cardQrValue(kid.id));
      setDoneId(kid.id);
    } catch (error) {
      setMsg(
        error?.name === 'NotAllowedError'
          ? 'Libere o NFC para o navegador poder gravar a etiqueta.'
          : 'Não consegui gravar. Encoste a etiqueta de novo no aparelho.'
      );
    } finally {
      setWritingId('');
    }
  };

  return (
    <div className="mt-8 rounded-[32px] bg-white p-5 brand-hairline sm:p-6">
      <div className="flex items-start gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#10203A] text-[#FFF8EF]">
          <Nfc className="h-5 w-5" />
        </span>
        <div>
          <h2 className="font-display text-xl leading-tight tracking-[-0.02em]" style={{ fontWeight: 1000 }}>
            Etiquetas NFC
          </h2>
          <p className="mt-1 text-sm leading-snug text-[#10203A]/55">
            Encoste uma etiqueta virgem no aparelho e toque em gravar. A etiqueta passa a abrir a página da criança.
          </p>
        </div>
      </div>

      {!supported && (
        <p className="mt-4 rounded-2xl bg-[#FFF8EF] px-4 py-3 text-[11px] leading-snug text-[#10203A]/60">
          A gravação funciona no Chrome do Android. No iPhone não é possível gravar pelo navegador — use as etiquetas
          já gravadas com o QR do cartão.
        </p>
      )}

      {msg && <p className="mt-3 text-[12px] leading-snug text-[#E04A36]">{msg}</p>}

      <div className="mt-4 divide-y divide-[#10203A]/8">
        {kids.map((kid) => (
          <div key={kid.id} className="flex items-center gap-3 py-2.5">
            <ChildAvatar child={kid} size="sm" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm">{kid.name}</p>
              <p className="text-[11px] text-[#10203A]/40">cartão #{kid.card_code}</p>
            </div>
            <button
              type="button"
              onClick={() => write(kid)}
              disabled={!supported || writingId === kid.id}
              className="inline-flex items-center gap-1.5 rounded-full border border-[#10203A]/15 px-3.5 py-2 text-xs text-[#10203A]/80 disabled:opacity-40"
            >
              {writingId === kid.id ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 animate-spin" /> Encoste
                </>
              ) : doneId === kid.id ? (
                <>
                  <Check className="h-3.5 w-3.5 text-[#0E9B80]" /> Gravada
                </>
              ) : (
                <>
                  <Nfc className="h-3.5 w-3.5" /> Gravar
                </>
              )}
            </button>
          </div>
        ))}
        {kids.length === 0 && (
          <p className="py-6 text-center text-sm text-[#10203A]/45">Cadastre as crianças para gravar as etiquetas.</p>
        )}
      </div>
    </div>
  );
}