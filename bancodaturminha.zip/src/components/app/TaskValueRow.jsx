import { Trash2 } from 'lucide-react';

export default function TaskValueRow({ task, onChange, onDelete }) {
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-[22px] bg-white p-2.5 brand-hairline sm:flex-nowrap">
      <input
        value={task.emoji || ''}
        onChange={(e) => onChange({ emoji: e.target.value.slice(0, 4) })}
        className="h-11 w-11 shrink-0 rounded-xl border border-[#10203A]/10 bg-[#FFF8EF] text-center text-lg outline-none"
        aria-label="Emoji da tarefa"
      />
      <input
        value={task.title || ''}
        onChange={(e) => onChange({ title: e.target.value })}
        className="h-11 min-w-0 flex-1 rounded-xl border border-[#10203A]/10 bg-white px-3 text-sm outline-none focus:border-[#10203A]/40"
        placeholder="Nome da tarefa"
      />
      <div className="flex h-11 items-center gap-1 rounded-xl border border-[#10203A]/10 bg-[#FFF8EF] px-3">
        <span className="text-[11px] text-[#10203A]/40">R$</span>
        <input
          type="number"
          step="0.25"
          min="0"
          value={task.value ?? ''}
          onChange={(e) => onChange({ value: e.target.value === '' ? '' : Number(e.target.value) })}
          className="w-20 bg-transparent text-sm outline-none"
          aria-label="Valor da tarefa"
        />
      </div>
      <button
        type="button"
        onClick={() => onChange({ active: !task.active })}
        className={`h-11 shrink-0 rounded-xl px-3 text-[11px] transition ${
          task.active ? 'bg-[#D4F7EE] text-[#0E9B80]' : 'bg-[#10203A]/8 text-[#10203A]/45'
        }`}
      >
        {task.active ? 'Ativa' : 'Pausada'}
      </button>
      <button
        type="button"
        onClick={onDelete}
        className="h-11 w-11 shrink-0 rounded-xl text-[#10203A]/30 transition hover:bg-[#FFE1DB] hover:text-[#E04A36]"
        aria-label="Excluir tarefa"
      >
        <Trash2 className="mx-auto h-4 w-4" />
      </button>
    </div>
  );
}