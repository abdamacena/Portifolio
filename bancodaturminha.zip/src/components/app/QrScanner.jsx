import { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { Loader2, X } from 'lucide-react';

export default function QrScanner({ onResult, onClose }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const resultRef = useRef(onResult);
  resultRef.current = onResult;

  const [starting, setStarting] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let stream;
    let frame;
    let stopped = false;

    const tick = () => {
      if (stopped) return;
      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (video && canvas && video.readyState >= 2 && video.videoWidth) {
        const w = video.videoWidth;
        const h = video.videoHeight;
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        ctx.drawImage(video, 0, 0, w, h);
        const img = ctx.getImageData(0, 0, w, h);
        const found = jsQR(img.data, w, h, { inversionAttempts: 'dontInvert' });
        if (found?.data) {
          stopped = true;
          if (resultRef.current) resultRef.current(found.data);
          return;
        }
      }
      frame = requestAnimationFrame(tick);
    };

    (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error('sem câmera');
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' } },
          audio: false,
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        setStarting(false);
        frame = requestAnimationFrame(tick);
      } catch {
        setStarting(false);
        setError('Não consegui abrir a câmera. Permita o acesso nas configurações ou digite o número do cartão.');
      }
    })();

    return () => {
      stopped = true;
      if (frame) cancelAnimationFrame(frame);
      if (stream) stream.getTracks().forEach((t) => t.stop());
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#10203A]">
      <div className="flex items-center justify-between px-5 py-4 text-[#FFF8EF]">
        <p className="text-sm">Aponte para o QR do cartão</p>
        <button
          type="button"
          onClick={onClose}
          aria-label="Fechar leitor"
          className="rounded-full bg-[#FFF8EF]/15 p-2"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <div className="relative flex-1 overflow-hidden">
        <video ref={videoRef} playsInline muted className="h-full w-full object-cover" />
        <canvas ref={canvasRef} className="hidden" />

        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="h-[62vw] w-[62vw] max-h-[280px] max-w-[280px] rounded-[28px] border-4 border-[#FFB627] shadow-[0_0_0_9999px_rgba(16,32,58,0.45)]" />
        </div>

        {starting && (
          <div className="absolute inset-0 flex items-center justify-center">
            <Loader2 className="h-7 w-7 animate-spin text-[#FFF8EF]" />
          </div>
        )}
      </div>

      <div className="px-5 pb-8 pt-4">
        {error ? (
          <p className="rounded-2xl bg-[#FFF8EF]/12 px-4 py-3 text-center text-[12px] leading-relaxed text-[#FFF8EF]">
            {error}
          </p>
        ) : (
          <p className="text-center text-[12px] text-[#FFF8EF]/60">
            O cartão tem o QR impresso no canto. Encaixe-o no quadrado.
          </p>
        )}
        <button
          type="button"
          onClick={onClose}
          className="mt-3 w-full rounded-2xl bg-[#FFF8EF]/15 py-3 text-sm text-[#FFF8EF]"
        >
          Digitar o número
        </button>
      </div>
    </div>
  );
}