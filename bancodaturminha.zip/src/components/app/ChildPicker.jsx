import ChildAvatar from '@/components/kid/ChildAvatar';
import { cn } from '@/lib/utils';

export default function ChildPicker({ children, onSelect, selectedId, columns = 'grid-cols-4 sm:grid-cols-6' }) {
  if (!children.length) {
    return (
      <p className="rounded-2xl border border-dashed border-[#10203A]/20 p-6 text-center text-sm text-[#10203A]/45">
        Nenhuma criança cadastrada ainda.
      </p>
    );
  }

  return (
    <div className={cn('grid gap-2.5', columns)}>
      {children.map((c) => (
        <button
          key={c.id}
          type="button"
          onClick={() => onSelect(c)}
          className={cn(
            'flex flex-col items-center gap-1.5 rounded-3xl border-2 bg-white px-2 py-3 transition',
            selectedId === c.id
              ? 'border-[#10203A] shadow-[0_12px_26px_-18px_rgba(16,32,58,0.7)]'
              : 'border-[#10203A]/10 hover:border-[#10203A]/30'
          )}
        >
          <ChildAvatar child={c} />
          <span className="w-full truncate text-center text-[11px] leading-tight text-[#10203A]/75">
            {c.name.split(' ')[0]}
          </span>
          <span className="font-mono text-[9px] uppercase tracking-[0.1em] text-[#10203A]/35">
            #{c.card_code}
          </span>
        </button>
      ))}
    </div>
  );
}