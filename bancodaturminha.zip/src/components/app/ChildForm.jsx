import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import Modal from '@/components/kid/Modal';
import CardCover from '@/components/brand/CardCover';
import { cardVariants } from '@/lib/brand';
import { symbols } from '@/lib/money';
import { cn } from '@/lib/utils';

export default function ChildForm({ child, nextCode, classId, onClose, onSaved }) {
  const { user } = useAuth();
  const [form, setForm] = useState({
    name: child?.name || '',
    card_code: child?.card_code || nextCode,
    symbol: child?.symbol || '🐻',
    cover: child?.cover || 'manga',
    guardian_contact: child?.guardian_contact || '',
  });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [confirming, setConfirming] = useState(false);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const save = async () => {
    if (!form.name.trim()) {
      setError('Escreva o nome da criança.');
      return;
    }
    if (!form.card_code.trim()) {
      setError('Defina o número do cartão.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      if (child) {
        await base44.entities.Child.update(child.id, form);
      } else {
        await base44.entities.Child.create({
          ...form,
          class_id: classId || '',
          teacher_user_id: user?.id || '',
          active: true,
          authorized: true,
        });
      }
      onSaved();
    } catch {
      setError('Não deu para salvar. Tente de novo.');
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!confirming) {
      setConfirming(true);
      return;
    }
    setSaving(true);
    await base44.entities.Transaction.deleteMany({ child_id: child.id });
    await base44.entities.Child.delete(child.id);
    onSaved();
  };

  return (
    <Modal open onClose={onClose} title={child ? 'Editar criança' : 'Nova criança'}>
      <div className="space-y-4">
        <label className="block">
          <span className="mb-2 block text-[10px] uppercase tracking-[0.22em] text-[#10203A]/40">
            Nome completo
          </span>
          <input
            value={form.name}
            onChange={set('name')}
            placeholder="Lia Ferreira"
            className="h-[50px] w-full rounded-2xl border border-[#10203A]/12 bg-white px-4 text-[15px] outline-none focus:border-[#10203A] focus:ring-4 focus:ring-[#FFB627]/25"
          />
        </label>

        <div className="grid grid-cols-[90px_1fr] gap-3">
          <label className="block">
            <span className="mb-2 block text-[10px] uppercase tracking-[0.22em] text-[#10203A]/40">Cartão</span>
            <input
              value={form.card_code}
              onChange={(e) => setForm((f) => ({ ...f, card_code: e.target.value.replace(/\D/g, '').slice(0, 3) }))}
              inputMode="numeric"
              className="h-[50px] w-full rounded-2xl border border-[#10203A]/12 bg-white px-4 text-center font-display text-lg outline-none focus:border-[#10203A] focus:ring-4 focus:ring-[#FFB627]/25"
              style={{ fontWeight: 1000 }}
            />
          </label>
          <label className="block">
            <span className="mb-2 block text-[10px] uppercase tracking-[0.22em] text-[#10203A]/40">
              Contato da família
            </span>
            <input
              value={form.guardian_contact}
              onChange={set('guardian_contact')}
              placeholder="(11) 99999-0000"
              className="h-[50px] w-full rounded-2xl border border-[#10203A]/12 bg-white px-4 text-[15px] outline-none focus:border-[#10203A] focus:ring-4 focus:ring-[#FFB627]/25"
            />
          </label>
        </div>

        <div>
          <span className="mb-2 block text-[10px] uppercase tracking-[0.22em] text-[#10203A]/40">
            Animal do cartão
          </span>
          <div className="grid grid-cols-8 gap-1.5">
            {symbols.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setForm((f) => ({ ...f, symbol: s }))}
                className={cn(
                  'flex h-9 items-center justify-center rounded-xl border-2 text-lg transition',
                  form.symbol === s ? 'border-[#10203A] bg-white' : 'border-transparent bg-white/50'
                )}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div>
          <span className="mb-2 block text-[10px] uppercase tracking-[0.22em] text-[#10203A]/40">Capa</span>
          <div className="grid grid-cols-5 gap-1.5">
            {cardVariants.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setForm((f) => ({ ...f, cover: c.id }))}
                className={cn(
                  'rounded-2xl border-2 p-1.5 transition',
                  form.cover === c.id ? 'border-[#10203A]' : 'border-transparent'
                )}
                aria-label={`Capa ${c.name}`}
              >
                <CardCover
                  variant={c}
                  holder={form.name.split(' ')[0] || 'Lia'}
                  symbol={form.symbol}
                  compact
                  className="rounded-[8px] shadow-none"
                />
              </button>
            ))}
          </div>
        </div>

        {error && <p className="text-sm text-[#FF6B57]">{error}</p>}

        <div className="flex items-center gap-2 pt-1">
          {child && (
            <button
              type="button"
              onClick={remove}
              disabled={saving}
              className={cn(
                'rounded-full px-4 py-3 text-xs transition',
                confirming ? 'bg-[#FF6B57] text-white' : 'text-[#E04A36] hover:bg-[#FFE1DB]'
              )}
            >
              {confirming ? 'Confirmar remoção' : 'Remover'}
            </button>
          )}
          <button
            type="button"
            onClick={save}
            disabled={saving}
            className="ml-auto rounded-full bg-[#10203A] px-6 py-3.5 font-display text-sm text-[#FFF8EF] disabled:opacity-50"
            style={{ fontWeight: 1000 }}
          >
            {saving ? 'Salvando…' : 'Salvar'}
          </button>
        </div>
      </div>
    </Modal>
  );
}