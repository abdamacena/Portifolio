import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { invalidateBalances } from '@/lib/balances';
import { categories, formatMoney, isoDate, parseMoney } from '@/lib/money';
import ChildAvatar from '@/components/kid/ChildAvatar';
import { cn } from '@/lib/utils';

const quickValues = [1, 2, 5, 10];

export default function TransactionSheet({ child, balance, onSaved, onCancel }) {
  const [type, setType] = useState('ganho');
  const [category, setCategory] = useState('tarefa');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const changeType = (next) => {
    setType(next);
    setCategory(categories[next][0].id);
  };

  const submit = async () => {
    const value = parseMoney(amount);
    if (value <= 0) {
      setError('Coloque um valor maior que zero.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      await base44.entities.Transaction.create({
        child_id: child.id,
        child_name: child.name,
        class_id: child.class_id || '',
        type,
        category,
        amount: value,
        description: description.trim(),
        date: isoDate(new Date()),
      });
      invalidateBalances();
      onSaved({ type, category, amount: value });
    } catch {
      setError('Não deu para registrar. Tente de novo.');
      setSaving(false);
    }
  };

  return (
    <div>
      <div className="mb-5 flex items-center gap-3 rounded-3xl bg-white p-3 brand-hairline">
        <ChildAvatar child={child} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-heading text-lg font-bold leading-tight">{child.name}</p>
          <p className="text-xs text-[#10203A]/45">
            Cartão {child.card_code} · saldo {formatMoney(balance)}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        {[
          { id: 'ganho', label: 'Ganhou', emoji: '🎉', color: '#12C2A0' },
          { id: 'gasto', label: 'Gastou', emoji: '🛒', color: '#FF6B57' },
        ].map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => changeType(t.id)}
            className={cn(
              'flex items-center justify-center gap-2 rounded-2xl border-2 py-3.5 text-sm transition',
              type === t.id ? 'text-white' : 'border-[#10203A]/10 bg-white text-[#10203A]/70'
            )}
            style={type === t.id ? { background: t.color, borderColor: t.color } : undefined}
          >
            <span className="text-lg">{t.emoji}</span>
            {t.label}
          </button>
        ))}
      </div>

      <div className="mt-5 rounded-3xl bg-white p-4 brand-hairline">
        <p className="mb-1 text-[10px] uppercase tracking-[0.24em] text-[#10203A]/40">Valor</p>
        <div className="flex items-baseline gap-2">
          <span className="font-display text-2xl" style={{ fontWeight: 1000 }}>
            R$
          </span>
          <input
            value={amount}
            onChange={(e) => {
              setAmount(e.target.value);
              setError('');
            }}
            inputMode="decimal"
            placeholder="0,00"
            className="w-full border-0 bg-transparent font-display text-4xl leading-none tracking-tight outline-none placeholder:text-[#10203A]/20"
            style={{ fontWeight: 1000 }}
            aria-label="Valor em reais"
          />
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {quickValues.map((v) => (
            <button
              key={v}
              type="button"
              onClick={() => {
                setAmount(String(v));
                setError('');
              }}
              className="rounded-full border border-[#10203A]/12 px-3.5 py-1.5 text-xs text-[#10203A]/70 transition hover:border-[#10203A]/35"
            >
              R$ {v},00
            </button>
          ))}
        </div>
      </div>

      <div className="mt-5">
        <p className="mb-2 text-[10px] uppercase tracking-[0.24em] text-[#10203A]/40">Por quê?</p>
        <div className="flex flex-wrap gap-2">
          {categories[type].map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setCategory(c.id)}
              className={cn(
                'flex items-center gap-1.5 rounded-full border-2 px-3.5 py-2 text-xs transition',
                category === c.id ? 'border-[#10203A] bg-white' : 'border-transparent bg-white/60 text-[#10203A]/60'
              )}
            >
              <span className="text-base leading-none">{c.emoji}</span>
              {c.label}
            </button>
          ))}
        </div>
      </div>

      <input
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="Observação (opcional)"
        className="mt-4 h-[50px] w-full rounded-2xl border border-[#10203A]/12 bg-white px-4 text-sm outline-none transition focus:border-[#10203A] focus:ring-4 focus:ring-[#FFB627]/25"
      />

      {error && <p className="mt-3 text-sm text-[#FF6B57]">{error}</p>}

      <div className="mt-5 flex items-center gap-2">
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="rounded-full px-4 py-3.5 text-sm text-[#10203A]/55"
          >
            Cancelar
          </button>
        )}
        <button
          type="button"
          onClick={submit}
          disabled={saving}
          className="flex-1 rounded-full bg-[#10203A] py-4 font-display text-base text-[#FFF8EF] transition disabled:opacity-50"
          style={{ fontWeight: 1000 }}
        >
          {saving ? 'Registrando…' : 'Registrar'}
        </button>
      </div>
    </div>
  );
}