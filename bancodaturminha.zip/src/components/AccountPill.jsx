import { cn } from '@/lib/utils';

export default function AccountPill({ label = 'Professora', className }) {
  const isTeacher = label === 'Professora';

  return (
    <span
      className={cn(
        'inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-[9px] uppercase tracking-[0.16em]',
        isTeacher ? 'bg-[#10203A] text-[#FFF8EF]' : 'bg-[#D4F7EE] text-[#0E9B80]',
        className
      )}
    >
      <span className={cn('h-1.5 w-1.5 rounded-full', isTeacher ? 'bg-[#FFB627]' : 'bg-[#12C2A0]')} />
      {label}
    </span>
  );
}