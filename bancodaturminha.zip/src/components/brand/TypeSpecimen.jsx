import { typeScale } from '@/lib/brand';
import { LogoWordmark } from './Logo';

export default function TypeSpecimen() {
  return (
    <div className="grid gap-6 lg:grid-cols-[1.15fr_1fr]">
      <div className="rounded-[32px] border border-[#10203A]/10 bg-white p-8 sm:p-10">
        <p className="mb-6 text-[11px] uppercase tracking-[0.3em] text-[#10203A]/40">Display</p>
        <div className="space-y-4">
          <p className="font-display text-[clamp(2.2rem,6vw,3.6rem)] leading-[0.95] tracking-[-0.03em]">
            guardar<br />é brincar
          </p>
          <div className="flex items-end gap-4">
            <LogoWordmark className="text-3xl" />
            <span className="pb-1 font-mono text-[10px] uppercase tracking-[0.18em] text-[#10203A]/40">
              VAG Rounded · 1000
            </span>
          </div>
        </div>

        <div className="mt-8 grid gap-4 border-t border-[#10203A]/10 pt-6 sm:grid-cols-2">
          <div>
            <p className="mb-2 text-[11px] uppercase tracking-[0.3em] text-[#10203A]/40">Títulos</p>
            <p className="font-heading text-2xl font-bold leading-tight">Minha primeira meta</p>
            <span className="mt-2 block font-mono text-[10px] uppercase tracking-[0.18em] text-[#10203A]/40">
              Recoleta · 700 / 900
            </span>
          </div>
          <div>
            <p className="mb-2 text-[11px] uppercase tracking-[0.3em] text-[#10203A]/40">Texto</p>
            <p className="text-sm leading-relaxed text-[#10203A]/75">
              Cada moeda guardada vira um passo mais perto do que você quer conquistar.
            </p>
            <span className="mt-2 block font-mono text-[10px] uppercase tracking-[0.18em] text-[#10203A]/40">
              Proxima Nova · 400
            </span>
          </div>
        </div>
      </div>

      <div className="overflow-hidden rounded-[32px] border border-[#10203A]/10 bg-white">
        {typeScale.map((t) => (
          <div
            key={t.label}
            className="flex items-center justify-between gap-4 border-b border-[#10203A]/8 px-6 py-4 last:border-b-0"
          >
            <div>
              <p className="text-sm text-[#10203A]">{t.label}</p>
              <p className="text-[11px] text-[#10203A]/45">{t.use}</p>
            </div>
            <div className="text-right">
              <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-[#10203A]/70">{t.font}</p>
              <p className="font-mono text-[10px] text-[#10203A]/40">{t.size}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}