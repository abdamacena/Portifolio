import { Link } from 'react-router-dom';
import Logo from './Logo';

export default function SiteFooter() {
  return (
    <footer className="no-print mt-24 border-t border-[#10203A]/10 bg-[#FFF8EF]">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-5 py-12 sm:flex-row sm:items-end sm:justify-between">
        <div className="max-w-sm">
          <Logo size="md" />
          <p className="mt-3 text-sm leading-relaxed text-[#10203A]/55">Moedinhas que ensinam a cuidar. Alunos de 4 anos,  e um cartão para cada um. Um projeto desenvolvido na Escola Infantil Cícero Pereira.

          </p>
        </div>
        <div className="flex flex-col gap-2 text-sm text-[#10203A]/45">
          <Link to="/marca" className="hover:text-[#10203A]">
            Manual da marca
          </Link>
          <Link to="/cadastro" className="hover:text-[#10203A]">
            Ficha para as famílias
          </Link>
        </div>
      </div>
    </footer>);

}