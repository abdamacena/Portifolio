const goals = [
  { name: 'Bicicleta nova', pct: 62, color: '#12C2A0', left: 'R$ 148,00' },
  { name: 'Fone de ouvido', pct: 28, color: '#8B7CF6', left: 'R$ 210,00' },
  { name: 'Viagem com a turma', pct: 88, color: '#FF6B57', left: 'R$ 40,00' },
];

export default function GoalsScreen() {
  return (
    <div className="h-full space-y-3 px-4 pb-4">
      <div>
        <p className="text-[9px] uppercase tracking-[0.2em] text-[#10203A]/40">Minhas metas</p>
        <p className="font-display text-xl leading-none tracking-[-0.03em]" style={{ fontWeight: 1000 }}>
          3 sonhos ativos
        </p>
      </div>

      {goals.map((g) => (
        <div key={g.name} className="rounded-2xl border border-[#10203A]/10 bg-white p-3">
          <p className="text-[10px] font-bold">{g.name}</p>
          <div className="mt-2 flex items-center gap-2">
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#10203A]/8">
              <div className="h-full rounded-full" style={{ width: `${g.pct}%`, background: g.color }} />
            </div>
            <span className="text-[9px] text-[#10203A]/50">{g.pct}%</span>
          </div>
          <p className="mt-2 text-[8px] text-[#10203A]/40">Faltam {g.left}</p>
        </div>
      ))}

      <div className="rounded-2xl border border-dashed border-[#10203A]/25 p-3 text-center">
        <p className="text-[9px] text-[#10203A]/50">+ Criar uma meta nova</p>
      </div>
    </div>
  );
}