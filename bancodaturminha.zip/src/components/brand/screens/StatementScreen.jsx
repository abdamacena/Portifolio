const items = [
  ['Mesada de novembro', '12 nov', '+ R$ 30,00', '#12C2A0'],
  ['Lanche na escola', '11 nov', '- R$ 8,50', '#FF6B57'],
  ['Guardado para a bike', '10 nov', '+ R$ 15,00', '#12C2A0'],
  ['Cinema com o vô', '08 nov', '- R$ 22,00', '#FF6B57'],
  ['Tarefa concluída', '07 nov', '+ R$ 5,00', '#12C2A0'],
];

export default function StatementScreen() {
  return (
    <div className="h-full space-y-3 px-4 pb-4">
      <div>
        <p className="text-[9px] uppercase tracking-[0.2em] text-[#10203A]/40">Extrato</p>
        <p className="font-display text-xl leading-none tracking-[-0.03em]" style={{ fontWeight: 1000 }}>
          Novembro
        </p>
      </div>

      <div className="rounded-2xl bg-[#10203A] p-3 text-[#FFF8EF]">
        <p className="text-[8px] uppercase tracking-[0.2em] text-[#FFF8EF]/40">Entrou no mês</p>
        <p className="mt-1 font-display text-lg leading-none" style={{ fontWeight: 1000 }}>R$ 50,00</p>
      </div>

      <div className="space-y-1.5">
        {items.map(([name, date, value, color]) => (
          <div key={name + date} className="flex items-center gap-2.5 rounded-xl bg-white px-3 py-2">
            <span
              className="h-6 w-6 shrink-0 rounded-full"
              style={{ background: `${color}22`, boxShadow: `inset 0 0 0 1px ${color}55` }}
            />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[9px] text-[#10203A]/75">{name}</p>
              <p className="text-[8px] text-[#10203A]/35">{date}</p>
            </div>
            <span className="text-[9px] font-bold" style={{ color: value.startsWith('+') ? '#0E9B80' : '#10203A' }}>
              {value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}