import CardCover from '@/components/brand/CardCover';

export default function CardScreen() {
  return (
    <div className="h-full space-y-3 px-4 pb-4">
      <div>
        <p className="text-[9px] uppercase tracking-[0.2em] text-[#10203A]/40">Meu cartão</p>
        <p className="font-display text-xl leading-none tracking-[-0.03em]" style={{ fontWeight: 1000 }}>
          Lia
        </p>
      </div>

      <CardCover variant="manga" holder="Lia" compact className="rounded-[16px]" />

      <div className="flex items-center justify-between rounded-2xl border border-[#10203A]/10 bg-white px-3 py-2.5">
        <div>
          <p className="text-[9px] text-[#10203A]/70">Cartão ativo</p>
          <p className="text-[8px] text-[#10203A]/35">Desligue se perder</p>
        </div>
        <span className="relative h-5 w-9 rounded-full bg-[#12C2A0]">
          <span className="absolute right-0.5 top-0.5 h-4 w-4 rounded-full bg-white" />
        </span>
      </div>

      <div className="rounded-2xl border border-[#10203A]/10 bg-white p-3">
        <p className="text-[8px] uppercase tracking-[0.2em] text-[#10203A]/35">Limite do dia</p>
        <p className="mt-1 text-[10px] font-bold">R$ 40,00</p>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#10203A]/8">
          <div className="h-full w-[45%] rounded-full bg-[#FFB627]" />
        </div>
        <p className="mt-2 text-[8px] text-[#10203A]/40">Definido pelo responsável</p>
      </div>

      <p className="text-center text-[8px] text-[#10203A]/35">Cartão virtual · número escondido</p>
    </div>
  );
}