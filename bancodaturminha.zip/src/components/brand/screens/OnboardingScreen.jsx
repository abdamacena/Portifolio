import { LogoMark } from '@/components/brand/Logo';

export default function OnboardingScreen() {
  return (
    <div className="flex h-full flex-col justify-between bg-[#FFB627] px-5 pb-6 pt-8 text-[#10203A]">
      <div className="flex items-center gap-2">
        <LogoMark className="h-6 w-6" bg="#FFF8EF" fg="#10203A" />
        <span className="font-display text-[9px] leading-none" style={{ fontWeight: 1000 }}>
          banco
          <br />
          da turminha
        </span>
      </div>

      <div className="flex flex-col items-center text-center">
        <LogoMark className="h-28 w-28" bg="#FFF8EF" fg="#10203A" />
        <h3 className="mt-6 font-display text-2xl leading-none tracking-[-0.03em]">
          Oi! Eu sou<br />a moedinha.
        </h3>
        <p className="mt-3 text-[11px] leading-relaxed text-[#10203A]/70">
          Vou guardar seu dinheiro com você e mostrar cada passo da sua conquista.
        </p>
      </div>

      <div className="space-y-2">
        <div className="rounded-full bg-[#10203A] py-3 text-center text-[11px] text-[#FFF8EF]">Começar</div>
        <p className="text-center text-[9px] text-[#10203A]/50">Um adulto cria a conta com você</p>
      </div>
    </div>
  );
}