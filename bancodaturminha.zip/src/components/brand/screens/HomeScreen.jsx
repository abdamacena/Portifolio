const shortcuts = ['Guardar', 'Gastar', 'Meta', 'Cartão'];

export default function HomeScreen() {
  return (
    <div className="h-full space-y-3 overflow-hidden px-4 pb-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[9px] uppercase tracking-[0.2em] text-[#10203A]/40">Bom dia</p>
          <p className="font-heading text-base font-bold leading-tight">Lia</p>
        </div>
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#8B7CF6]/20 text-[10px] font-bold">
          L
        </span>
      </div>

      <div className="rounded-2xl bg-[#FFB627] p-4">
        <p className="text-[8px] uppercase tracking-[0.24em] text-[#10203A]/50">Meu saldo</p>
        <p className="mt-1 font-display text-2xl leading-none" style={{ fontWeight: 1000 }}>R$ 128,40</p>
        <p className="mt-2 text-[9px] text-[#10203A]/60">+ R$ 12,00 esta semana</p>
      </div>

      <div className="grid grid-cols-4 gap-1.5">
        {shortcuts.map((s) => (
          <div key={s} className="rounded-xl border border-[#10203A]/10 bg-white py-2 text-center">
            <span className="mx-auto mb-1 block h-4 w-4 rounded-full bg-[#10203A]/8" />
            <span className="text-[8px] text-[#10203A]/60">{s}</span>
          </div>
        ))}
      </div>

      <div className="rounded-2xl border border-[#10203A]/10 bg-white p-3">
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold">Bicicleta nova</p>
          <span className="text-[9px] text-[#10203A]/45">62%</span>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#10203A]/8">
          <div className="h-full w-[62%] rounded-full bg-[#12C2A0]" />
        </div>
        <p className="mt-2 text-[8px] text-[#10203A]/45">Faltam R$ 148,00</p>
      </div>

      <div>
        <p className="mb-1.5 text-[8px] uppercase tracking-[0.2em] text-[#10203A]/35">Últimas conquistas</p>
        <div className="space-y-1.5">
          {[
            ['Mesada', '+ R$ 30,00'],
            ['Lanche', '- R$ 8,50'],
          ].map(([a, b]) => (
            <div key={a} className="flex items-center justify-between rounded-xl bg-white px-3 py-2">
              <span className="text-[9px] text-[#10203A]/70">{a}</span>
              <span className="text-[9px] font-bold">{b}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}