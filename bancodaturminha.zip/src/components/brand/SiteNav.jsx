import { Link, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { LogOut, Menu, X } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import AccountPill from '@/components/AccountPill';
import Logo from './Logo';

const links = [
  { to: '/inicio', label: 'Início' },
  { to: '/alunos', label: 'Crianças' },
  { to: '/tarefas', label: 'Tarefas' },
  { to: '/turmas', label: 'Turmas' },
  { to: '/desempenho', label: 'Desempenho' },
  { to: '/painel', label: 'Painel' },
  { to: '/relatorios', label: 'Relatórios' },
];

export default function SiteNav() {
  const { pathname } = useLocation();
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <header className="no-print sticky top-0 z-50 border-b border-[#10203A]/8 bg-[#FFF8EF]/90 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3">
        <Link to="/inicio" aria-label="Banco da Turminha — início">
          <Logo size="md" />
        </Link>

        <div className="flex items-center gap-2">
          <AccountPill />
          <nav className="hidden items-center gap-0.5 lg:flex">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className={`rounded-full px-3 py-2 text-[13px] transition-colors ${
                pathname === l.to
                  ? 'bg-[#10203A] text-[#FFF8EF]'
                  : 'text-[#10203A]/70 hover:bg-[#10203A]/5 hover:text-[#10203A]'
              }`}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="rounded-full border border-[#10203A]/15 p-2 text-[#10203A] lg:hidden"
          aria-label={open ? 'Fechar menu' : 'Abrir menu'}
          aria-expanded={open}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
          <button
            type="button"
            onClick={() => logout(true)}
            className="hidden items-center gap-1.5 rounded-full border border-[#10203A]/15 px-3 py-2 text-xs text-[#10203A]/60 hover:text-[#10203A] lg:flex"
          >
            <LogOut className="h-3.5 w-3.5" /> Sair
          </button>
        </div>
      </div>

      {open && (
        <nav className="flex flex-col gap-1 border-t border-[#10203A]/8 px-5 py-4 lg:hidden">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className={`rounded-xl px-4 py-3 text-sm ${
                pathname === l.to ? 'bg-[#10203A] text-[#FFF8EF]' : 'text-[#10203A]/75'
              }`}
            >
              {l.label}
            </Link>
          ))}
          <div className="mt-2 border-t border-[#10203A]/8 pt-3">
            <p className="px-4 text-[11px] leading-relaxed text-[#10203A]/45">
              Você entrou como professora{user?.email ? ` · ${user.email}` : ''}
            </p>
            <button
              type="button"
              onClick={() => logout(true)}
              className="mt-1 flex w-full items-center gap-2 rounded-xl px-4 py-3 text-sm text-[#10203A]/70"
            >
              <LogOut className="h-4 w-4" /> Sair desta conta
            </button>
          </div>
        </nav>
      )}
    </header>
  );
}