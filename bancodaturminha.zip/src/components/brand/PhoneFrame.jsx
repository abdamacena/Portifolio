export default function PhoneFrame({ children, label }) {
  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative aspect-[9/19] w-full max-w-[264px] overflow-hidden rounded-[42px] border-[9px] border-[#10203A] bg-[#FFF8EF] shadow-[0_34px_70px_-34px_rgba(16,32,58,0.5)]">
        <div className="absolute left-1/2 top-2.5 z-10 h-1.5 w-16 -translate-x-1/2 rounded-full bg-[#10203A]/20" />
        <div className="h-full overflow-hidden pt-7">{children}</div>
      </div>
      {label && (
        <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">{label}</span>
      )}
    </div>
  );
}