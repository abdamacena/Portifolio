import { useState } from 'react';
import { Check, Copy } from 'lucide-react';
import { colors } from '@/lib/brand';

export default function PaletteGrid() {
  const [copied, setCopied] = useState(null);

  const copy = async (hex) => {
    try {
      await navigator.clipboard.writeText(hex);
      setCopied(hex);
      setTimeout(() => setCopied(null), 1600);
    } catch {
      setCopied(null);
    }
  };

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
      {colors.map((c) => (
        <button
          key={c.hex}
          type="button"
          onClick={() => copy(c.hex)}
          className="group relative overflow-hidden rounded-3xl border border-[#10203A]/10 text-left transition-transform duration-300 hover:-translate-y-1"
          style={{ background: c.hex, color: c.text }}
        >
          <div className="flex h-24 items-start justify-end p-3 sm:h-32" />
          <div className="space-y-1 p-4 pt-3">
            <div className="flex items-center justify-between gap-2">
              <span className="font-heading text-lg font-bold leading-none">{c.name}</span>
              <span className="opacity-60">
                {copied === c.hex ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </span>
            </div>
            <p className="font-mono text-[11px] uppercase tracking-[0.14em] opacity-80">{c.hex}</p>
            <p className="text-[11px] leading-snug opacity-60">{c.role}</p>
          </div>
        </button>
      ))}
    </div>
  );
}