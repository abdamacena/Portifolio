import { cn } from '@/lib/utils';

export function LogoMark({ className, mono = false, bg, fg }) {
  const coin = bg || (mono ? '#10203A' : '#FFB627');
  const face = fg || (mono ? '#FFF8EF' : '#10203A');

  return (
    <svg viewBox="0 0 64 64" className={cn('h-10 w-10', className)} aria-hidden="true">
      <path
        d="M32 12C25 2.5 15.5 3.5 12.5 11.5c4.5 6 13 6.5 19.5.5Z"
        fill={face}
        opacity={mono ? 1 : 0.95}
      />
      <path
        d="M32 12c7-9.5 16.5-8.5 19.5-.5-4.5 6-13 6.5-19.5.5Z"
        fill={face}
        opacity={mono ? 1 : 0.75}
      />
      <circle cx="32" cy="37" r="22" fill={coin} />
      <circle cx="32" cy="37" r="16.5" fill="none" stroke={face} strokeWidth="1.6" opacity="0.35" />
      <circle cx="25.5" cy="34" r="2.6" fill={face} />
      <circle cx="38.5" cy="34" r="2.6" fill={face} />
      <path
        d="M25.5 42.5c3.4 4.2 9.6 4.2 13 0"
        fill="none"
        stroke={face}
        strokeWidth="3"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function LogoWordmark({ className, color = '#10203A', stacked = false, muted }) {
  if (stacked) {
    return (
      <span
        className={cn('font-display tracking-[-0.04em]', className)}
        style={{ color, fontWeight: 1000, lineHeight: 0.86 }}
      >
        banco
        <br />
        <span style={{ opacity: muted ?? 0.75, fontSize: '0.66em' }}>da turminha</span>
      </span>
    );
  }

  return (
    <span
      className={cn('font-display leading-none tracking-[-0.04em]', className)}
      style={{ color, fontWeight: 1000 }}
    >
      banco da turminha
    </span>
  );
}

export default function Logo({ className, markClassName, size = 'md', color, mono = false, stacked = false }) {
  const sizes = {
    sm: { word: 'text-base', gap: 'gap-2', mark: 'h-7 w-7' },
    md: { word: 'text-lg', gap: 'gap-2.5', mark: 'h-9 w-9' },
    lg: { word: 'text-3xl', gap: 'gap-3', mark: 'h-14 w-14' },
  };
  const s = sizes[size] || sizes.md;

  return (
    <span className={cn('inline-flex items-center', s.gap, className)}>
      <LogoMark className={cn(s.mark, markClassName)} mono={mono} />
      <LogoWordmark
        className={s.word}
        stacked={stacked}
        color={color || (mono ? '#FFF8EF' : '#10203A')}
      />
    </span>
  );
}