import { cn } from '@/lib/utils';
import { cardVariants } from '@/lib/brand';
import QrTag from '@/components/kid/QrTag';
import { LogoMark } from './Logo';

function Pattern({ variant }) {
  const ink = variant.ink;

  if (variant.pattern === 'arcs') {
    return (
      <g stroke={ink} strokeWidth="2.2" fill="none" opacity="0.28">
        {[0, 1, 2, 3, 4, 5, 6].map((i) => (
          <circle key={i} cx="286" cy="196" r={26 + i * 25} />
        ))}
      </g>
    );
  }

  if (variant.pattern === 'dots') {
    return (
      <g fill={ink} opacity="0.3">
        {Array.from({ length: 63 }).map((_, i) => (
          <circle key={i} cx={18 + (i % 9) * 36} cy={18 + Math.floor(i / 9) * 30} r="3.4" />
        ))}
      </g>
    );
  }

  if (variant.pattern === 'waves') {
    return (
      <g stroke={ink} strokeWidth="7" fill="none" opacity="0.26" strokeLinecap="round">
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <path key={i} d={`M-30 ${44 + i * 36} q 40 -24 80 0 t 80 0 t 80 0 t 80 0 t 80 0`} />
        ))}
      </g>
    );
  }

  if (variant.pattern === 'confetti') {
    const bits = [
      [30, 40, 0], [78, 120, 1], [130, 48, 2], [186, 150, 0], [238, 62, 1],
      [282, 128, 2], [54, 176, 1], [152, 100, 0], [212, 26, 2], [258, 186, 1],
      [102, 190, 2], [196, 96, 1], [12, 104, 0], [300, 40, 1],
    ];
    return (
      <g opacity="0.4">
        {bits.map(([x, y, type], i) =>
          type === 0 ? (
            <circle key={i} cx={x} cy={y} r="4" fill={ink} />
          ) : type === 1 ? (
            <rect key={i} x={x} y={y} width="12" height="4" rx="2" fill={ink} transform={`rotate(-28 ${x} ${y})`} />
          ) : (
            <path
              key={i}
              d={`M${x} ${y} l3.4 7 7.6 1.1-5.5 5.4 1.3 7.6-6.8-3.6-6.8 3.6 1.3-7.6-5.5-5.4 7.6-1.1Z`}
              fill={ink}
            />
          )
        )}
      </g>
    );
  }

  return (
    <g stroke={ink} strokeWidth="1.6" opacity="0.4">
      {Array.from({ length: 16 }).map((_, i) => (
        <line key={i} x1={i * 22 - 40} y1="0" x2={i * 22 - 80} y2="202" />
      ))}
    </g>
  );
}

function Chip({ ink, base }) {
  return (
    <svg viewBox="0 0 34 26" className="h-5 w-7 sm:h-6 sm:w-8" aria-hidden="true">
      <rect x="0.5" y="0.5" width="33" height="25" rx="5" fill={ink} opacity="0.9" />
      <g stroke={base} strokeWidth="1.2" opacity="0.8">
        <line x1="0" y1="9" x2="34" y2="9" />
        <line x1="0" y1="17" x2="34" y2="17" />
        <line x1="12" y1="0" x2="12" y2="26" />
        <line x1="23" y1="0" x2="23" y2="26" />
      </g>
    </svg>
  );
}

function Contactless({ ink }) {
  return (
    <svg viewBox="0 0 20 20" className="h-4 w-4 sm:h-5 sm:w-5" aria-hidden="true">
      <g stroke={ink} strokeWidth="1.8" fill="none" strokeLinecap="round" opacity="0.75">
        <path d="M7 5.5a6.5 6.5 0 0 1 0 9" />
        <path d="M11 3a10.5 10.5 0 0 1 0 14" />
        <path d="M3.5 8a3 3 0 0 1 0 4" />
      </g>
    </svg>
  );
}

export default function CardCover({
  variant = 'manga',
  holder = 'Lia',
  label = 'Cartão kids',
  className,
  compact = false,
  symbol,
  childId,
  login,
}) {
  const v = typeof variant === 'string'
    ? cardVariants.find((c) => c.id === variant) || cardVariants[0]
    : variant;

  return (
    <div
      className={cn(
        'relative aspect-[1.586/1] w-full overflow-hidden rounded-[20px] sm:rounded-[24px]',
        'shadow-[0_28px_60px_-30px_rgba(16,32,58,0.5)]',
        className
      )}
      style={{ background: v.base, color: v.ink }}
    >
      <svg
        className="absolute inset-0 h-full w-full"
        viewBox="0 0 320 202"
        preserveAspectRatio="xMidYMid slice"
        aria-hidden="true"
      >
        <Pattern variant={v} />
      </svg>

      <div className="pointer-events-none absolute inset-0 bg-gradient-to-tr from-black/10 via-transparent to-white/20" />

      {symbol && (
        <span
          className="card-symbol absolute left-1/2 top-1/2 flex -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full"
          style={{
            width: '30%',
            height: '30%',
            background: v.base,
            boxShadow: `0 0 0 2px ${v.ink}2E`,
            fontSize: compact ? '1.15rem' : 'clamp(1.1rem, 3.6vw, 2.2rem)',
          }}
          aria-hidden="true"
        >
          {symbol}
        </span>
      )}

      <div className={cn('relative flex h-full flex-col justify-between', compact ? 'p-[5%]' : 'p-[6%]')}>
        <div className="flex items-start justify-between">
          <span className="flex items-center gap-1.5">
            <LogoMark className={compact ? 'h-4 w-4' : 'h-5 w-5 sm:h-6 sm:w-6'} bg={v.ink} fg={v.base} />
            <span
              className="font-display tracking-[-0.03em]"
              style={{
                fontWeight: 1000,
                lineHeight: 0.92,
                fontSize: compact ? '0.5rem' : 'clamp(0.5rem, 1.35vw, 0.72rem)',
              }}
            >
              banco
              <br />
              <span style={{ opacity: 0.8 }}>da turminha</span>
            </span>
          </span>
          <Contactless ink={v.ink} />
        </div>

        <div className="flex items-end justify-between gap-3">
          <div className="min-w-0">
            <p
              className="card-label mb-1 uppercase tracking-[0.3em] opacity-70"
              style={{ fontSize: compact ? '0.4rem' : 'clamp(0.42rem, 1vw, 0.6rem)' }}
            >
              {label}
            </p>
            <p
              className="card-holder truncate font-display uppercase leading-none tracking-[-0.01em]"
              style={{ fontWeight: 1000, fontSize: compact ? '1rem' : 'clamp(0.95rem, 3vw, 1.6rem)' }}
            >
              {holder}
            </p>
            {login && (
              <p
                className="card-login truncate font-mono leading-none opacity-75"
                style={{ fontSize: compact ? '0.4rem' : 'clamp(0.42rem, 1.05vw, 0.6rem)' }}
              >
                @{login}
              </p>
            )}
          </div>
          {childId ? (
            <span
              className="shrink-0 rounded-[7px] bg-white p-[3px]"
              style={{ width: compact ? '2.4rem' : '3.4rem', height: compact ? '2.4rem' : '3.4rem' }}
            >
              <QrTag childId={childId} className="h-full w-full" />
            </span>
          ) : (
            <Chip ink={v.ink} base={v.base} />
          )}
        </div>
      </div>
    </div>
  );
}