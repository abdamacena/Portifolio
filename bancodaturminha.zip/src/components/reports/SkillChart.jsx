import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

export default function SkillChart({ data }) {
  return (
    <section className="rounded-[26px] bg-white p-4 brand-hairline">
      <p className="text-[10px] uppercase tracking-[0.22em] text-[#10203A]/40">Aprender</p>
      <h2 className="font-heading text-base font-bold">Boas práticas que mais aparecem</h2>

      {data.length === 0 ? (
        <p className="mt-3 rounded-2xl bg-[#FFF8EF] px-3 py-4 text-center text-[12px] text-[#10203A]/45">
          Marque a semana em Desempenho para os gráficos aparecerem.
        </p>
      ) : (
        <div className="mt-2 h-[230px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} layout="vertical" margin={{ top: 4, right: 14, bottom: 0, left: 0 }}>
              <XAxis type="number" hide allowDecimals={false} />
              <YAxis
                type="category"
                dataKey="label"
                width={96}
                tickLine={false}
                axisLine={false}
                tick={{ fontSize: 11, fill: '#10203A99' }}
              />
              <Tooltip
                cursor={{ fill: 'rgba(16,32,58,0.04)' }}
                formatter={(value) => [`${value} marcações`, 'Turma']}
                contentStyle={{ borderRadius: 14, border: '1px solid rgba(16,32,58,.1)', fontSize: 12 }}
              />
              <Bar dataKey="count" radius={[8, 8, 8, 8]} barSize={16}>
                {data.map((d) => (
                  <Cell key={d.id} fill={d.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </section>
  );
}