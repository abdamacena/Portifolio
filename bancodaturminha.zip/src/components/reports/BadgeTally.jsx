import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

export default function BadgeTally({ data }) {
  return (
    <section className="rounded-[26px] bg-white p-4 brand-hairline">
      <p className="text-[10px] uppercase tracking-[0.22em] text-[#10203A]/40">Selos</p>
      <h2 className="font-heading text-base font-bold">Medalhas entregues</h2>

      {data.length === 0 ? (
        <p className="mt-3 rounded-2xl bg-[#FFF8EF] px-3 py-4 text-center text-[12px] text-[#10203A]/45">
          Nenhum selo entregue ainda. Dê o primeiro na ficha da criança.
        </p>
      ) : (
        <div className="mt-2" style={{ height: Math.max(190, data.length * 32) }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} layout="vertical" margin={{ top: 8, right: 14, bottom: 0, left: 0 }}>
              <XAxis type="number" hide allowDecimals={false} />
              <YAxis
                type="category"
                dataKey="label"
                width={98}
                tickLine={false}
                axisLine={false}
                tick={{ fontSize: 11, fill: '#10203A99' }}
              />
              <Tooltip
                cursor={{ fill: 'rgba(16,32,58,0.04)' }}
                formatter={(value) => [`${value} selos`, 'Entregues']}
                contentStyle={{ borderRadius: 14, border: '1px solid rgba(16,32,58,.1)', fontSize: 12 }}
              />
              <Bar dataKey="count" barSize={16} radius={[8, 8, 8, 8]}>
                {data.map((d) => (
                  <Cell key={d.id} fill={d.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </section>
  );
}