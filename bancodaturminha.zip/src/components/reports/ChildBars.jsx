import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

export default function ChildBars({ data }) {
  return (
    <section className="rounded-[26px] bg-white p-4 brand-hairline">
      <p className="text-[10px] uppercase tracking-[0.22em] text-[#10203A]/40">Progresso</p>
      <h2 className="font-heading text-base font-bold">Cada criança</h2>

      {data.length === 0 ? (
        <p className="mt-3 rounded-2xl bg-[#FFF8EF] px-3 py-4 text-center text-[12px] text-[#10203A]/45">
          Nenhuma criança nesta turma ainda.
        </p>
      ) : (
        <>
          <div className="mt-2 flex items-center gap-4 text-[10px] text-[#10203A]/55">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: '#12C2A0' }} /> Boas práticas
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: '#FF6B57' }} /> Precisa de apoio
            </span>
          </div>
          <div style={{ height: Math.max(190, data.length * 30) }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} layout="vertical" margin={{ top: 8, right: 14, bottom: 0, left: 0 }}>
                <XAxis type="number" hide allowDecimals={false} />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={86}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: '#10203A99' }}
                />
                <Tooltip
                  cursor={{ fill: 'rgba(16,32,58,0.04)' }}
                  contentStyle={{ borderRadius: 14, border: '1px solid rgba(16,32,58,.1)', fontSize: 12 }}
                />
                <Bar dataKey="boas" name="Boas práticas" stackId="a" fill="#12C2A0" barSize={13} radius={[6, 0, 0, 6]} />
                <Bar dataKey="apoio" name="Precisa de apoio" stackId="a" fill="#FF6B57" barSize={13} radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </>
      )}
    </section>
  );
}