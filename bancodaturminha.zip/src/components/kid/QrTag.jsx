import { useEffect, useState } from 'react';
import QRCode from 'qrcode';

export const CARD_QR_BASE = 'https://steady-kids-bank-grow.base44.app';

export function studentPath(childId) {
  return `/alunos/${childId}`;
}

export function cardQrValue(childId) {
  return `${CARD_QR_BASE}${studentPath(childId)}`;
}

export function studentIdFromQr(text) {
  try {
    const url = new URL(String(text || '').trim());
    const match = url.pathname.match(/\/alunos\/([^/?#]+)/);
    return match ? match[1] : '';
  } catch {
    return '';
  }
}

export default function QrTag({ childId, className }) {
  const [src, setSrc] = useState('');

  useEffect(() => {
    let alive = true;
    if (!childId) {
      setSrc('');
      return () => {
        alive = false;
      };
    }
    QRCode.toDataURL(cardQrValue(childId), {
      margin: 1,
      width: 320,
      errorCorrectionLevel: 'M',
      color: { dark: '#10203A', light: '#FFFFFF' },
    })
      .then((url) => {
        if (alive) setSrc(url);
      })
      .catch(() => {
        if (alive) setSrc('');
      });
    return () => {
      alive = false;
    };
  }, [childId]);

  if (!src) return null;

  return <img src={src} alt="QR code do cartão" className={className} />;
}