import { X } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Modal({ open, onClose, title, subtitle, children, size = 'md' }) {
  if (!open) return null;

  const widths = { sm: 'sm:max-w-md', md: 'sm:max-w-lg', lg: 'sm:max-w-2xl' };

  return (
    <div
      className="fixed inset-0 z-[60] flex items-end justify-center bg-[#10203A]/40 backdrop-blur-sm sm:items-center sm:p-6"
      onClick={onClose}
    >
      <div
        className={cn(
          'max-h-[92vh] w-full overflow-y-auto rounded-t-[32px] bg-[#FFF8EF] p-6 shadow-2xl sm:rounded-[32px] sm:p-8',
          widths[size]
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            <h2 className="font-heading text-xl font-bold leading-tight">{title}</h2>
            {subtitle && <p className="mt-1 text-sm text-[#10203A]/50">{subtitle}</p>}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-2 text-[#10203A]/60 hover:bg-[#10203A]/5"
            aria-label="Fechar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}