import { cardVariants } from '@/lib/brand';
import { cn } from '@/lib/utils';

export default function ChildAvatar({ child, className, size = 'md' }) {
  const cover = cardVariants.find((c) => c.id === child?.cover) || cardVariants[0];
  const sizes = {
    sm: 'h-9 w-9 text-base',
    md: 'h-12 w-12 text-xl',
    lg: 'h-20 w-20 text-4xl',
  };

  return (
    <span
      className={cn(
        'flex shrink-0 items-center justify-center rounded-full leading-none',
        sizes[size] || sizes.md,
        className
      )}
      style={{ background: `${cover.base}2E`, boxShadow: `inset 0 0 0 2px ${cover.base}` }}
      aria-hidden="true"
    >
      {child?.symbol || '🐻'}
    </span>
  );
}