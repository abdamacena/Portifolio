const doodles = [
  { x: '4%', y: '8%', size: 74, rotate: -8, color: '#FFB627', kind: 'sun' },
  { x: '88%', y: '4%', size: 52, rotate: 12, color: '#8B7CF6', kind: 'star' },
  { x: '72%', y: '82%', size: 62, rotate: 6, color: '#12C2A0', kind: 'flower' },
  { x: '12%', y: '74%', size: 56, rotate: -14, color: '#FF6B57', kind: 'cloud' },
  { x: '94%', y: '52%', size: 40, rotate: 20, color: '#FFB627', kind: 'star' },
  { x: '40%', y: '94%', size: 46, rotate: -4, color: '#6AA9FF', kind: 'flower' },
];

function Shape({ kind }) {
  if (kind === 'sun') {
    return (
      <g fill="none" strokeWidth="2.4" strokeLinecap="round">
        <circle cx="32" cy="32" r="12" fill="currentColor" opacity="0.5" stroke="none" />
        {Array.from({ length: 8 }).map((_, i) => {
          const a = (i * Math.PI) / 4;
          return (
            <line
              key={i}
              x1={32 + Math.cos(a) * 17}
              y1={32 + Math.sin(a) * 17}
              x2={32 + Math.cos(a) * 24}
              y2={32 + Math.sin(a) * 24}
            />
          );
        })}
      </g>
    );
  }
  if (kind === 'star') {
    return (
      <path
        d="M32 8l6.5 15.5L54 30l-11 10.5L45 57 32 48.5 19 57l2-16.5L10 30l15.5-6.5Z"
        fill="none"
        strokeWidth="2.4"
        strokeLinejoin="round"
      />
    );
  }
  if (kind === 'flower') {
    return (
      <g fill="none" strokeWidth="2.4" strokeLinecap="round">
        <circle cx="32" cy="32" r="5" fill="currentColor" opacity="0.5" stroke="none" />
        {[0, 1, 2, 3, 4].map((i) => {
          const a = (i * 2 * Math.PI) / 5 - Math.PI / 2;
          return <ellipse key={i} cx={32 + Math.cos(a) * 13} cy={32 + Math.sin(a) * 13} rx="6" ry="8" transform={`rotate(${(a * 180) / Math.PI + 90} ${32 + Math.cos(a) * 13} ${32 + Math.sin(a) * 13})`} />;
        })}
      </g>
    );
  }
  return (
    <path
      d="M10 40a10 10 0 0 1 3-19 13 13 0 0 1 24 3 9 9 0 0 1-2 16Z"
      fill="none"
      strokeWidth="2.4"
      strokeLinejoin="round"
    />
  );
}

export default function CrayonDoodles({ className }) {
  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className || ''}`} aria-hidden="true">
      {doodles.map((d, i) => (
        <svg
          key={i}
          viewBox="0 0 64 64"
          className="absolute opacity-[0.16]"
          style={{
            left: d.x,
            top: d.y,
            width: d.size,
            height: d.size,
            color: d.color,
            stroke: d.color,
            transform: `rotate(${d.rotate}deg)`,
          }}
        >
          <Shape kind={d.kind} />
        </svg>
      ))}
    </div>
  );
}