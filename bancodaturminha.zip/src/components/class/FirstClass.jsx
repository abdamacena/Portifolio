import ClassForm from '@/components/class/ClassForm';
import Logo from '@/components/brand/Logo';
import { useClassroom } from '@/lib/ClassContext';

export default function FirstClass() {
  const { reload } = useClassroom();

  return (
    <div className="mx-auto max-w-lg px-5 py-10">
      <Logo size="md" />
      <h1 className="balance mt-4 font-display text-[1.9rem] leading-[0.98] tracking-[-0.035em]">
        Comece pela sua turma.
      </h1>
      <p className="mt-3 text-[13px] leading-relaxed text-[#10203A]/60">
        Cada turma tem as suas crianças, tarefas e cartões. Crie a primeira para começar a registrar.
      </p>
      <div className="mt-5">
        <ClassForm onCreated={reload} />
      </div>
    </div>
  );
}