import { Link } from 'react-router-dom';
import { School } from 'lucide-react';
import { useClassroom } from '@/lib/ClassContext';

export default function ClassBar() {
  const { active, classes, loading } = useClassroom();

  if (loading || !active) return null;

  return (
    <div className="no-print border-b border-[#10203A]/8 bg-[#FFF1D6]">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 py-2">
        <p className="flex min-w-0 items-center gap-2 text-[12px] text-[#10203A]/70">
          <School className="h-3.5 w-3.5 shrink-0" />
          <span className="truncate font-semibold text-[#10203A]">{active.name}</span>
          <span className="hidden text-[11px] text-[#10203A]/45 sm:inline">· código {active.code}</span>
        </p>
        <Link to="/turmas" className="shrink-0 text-[11px] text-[#10203A]/55 underline">
          {classes.length > 1 ? `Trocar turma (${classes.length})` : 'Minhas turmas'}
        </Link>
      </div>
    </div>
  );
}