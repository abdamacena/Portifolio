import { useState } from 'react';
import { Loader2, Plus } from 'lucide-react';
import { cardVariants } from '@/lib/brand';
import { createClass, normalizeClassCode } from '@/lib/classes';
import { cn } from '@/lib/utils';

const field =
  'h-[50px] w-full rounded-2xl border border-[#10203A]/12 bg-white px-4 text-[15px] text-[#10203A] outline-none transition focus:border-[#10203A]/40 focus:ring-4 focus:ring-[#FFB627]/25';

export default function ClassForm({ onCreated, teacherName }) {
  const [school, setSchool] = useState('');
  const [name, setName] = useState('');
  const [year, setYear] = useState('');
  const [color, setColor] = useState('manga');
  const [code, setCode] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (school.trim().length < 2) {
      setError('Escreva o nome da escola.');
      return;
    }
    if (name.trim().length < 3) {
      setError('Escreva o nome da turma, como “Maternal II Amarelo”.');
      return;
    }
    if (code.trim().length < 6) {
      setError('Escolha o código da turma, com pelo menos 6 letras ou números.');
      return;
    }
    setSaving(true);
    try {
      const created = await createClass({ name, school, year, color, teacherName, code });
      setSchool('');
      setName('');
      setYear('');
      setCode('');
      if (onCreated) onCreated(created);
    } catch (err) {
      setError(err?.message || 'Não foi possível criar a turma.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="rounded-[28px] border border-[#10203A]/10 bg-[#FFFDF9] p-4">
      <p className="mb-3 text-[10px] uppercase tracking-[0.22em] text-[#10203A]/40">Nova turma</p>

      <label className="block">
        <span className="mb-1.5 block text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">Escola</span>
        <input
          value={school}
          onChange={(e) => setSchool(e.target.value)}
          placeholder="Nome da escola"
          className={field}
        />
      </label>

      <label className="mt-3 block">
        <span className="mb-1.5 block text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">Nome da turma</span>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Maternal II Azul"
          className={field}
        />
      </label>

      <label className="mt-3 block">
        <span className="mb-1.5 block text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">
          Código da turma
        </span>
        <input
          value={code}
          onChange={(e) => setCode(normalizeClassCode(e.target.value))}
          placeholder="AZUL27"
          autoCapitalize="characters"
          autoCorrect="off"
          spellCheck={false}
          className={`${field} font-mono uppercase tracking-[0.14em]`}
        />
        <p className="mt-1.5 text-[11px] leading-relaxed text-[#10203A]/45">
          Obrigatório. É esse código, igual ao da sua turma, que as famílias digitam na ficha — use só letras maiúsculas
          e números, e passe o mesmo código para todas as famílias.
        </p>
      </label>

      <label className="mt-3 block">
        <span className="mb-1.5 block text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">Ano (opcional)</span>
        <input value={year} onChange={(e) => setYear(e.target.value)} placeholder="2026" className={field} />
      </label>

      <div className="mt-4">
        <span className="mb-2 block text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">Cor da turma</span>
        <div className="flex gap-2">
          {cardVariants.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setColor(c.id)}
              className={cn(
                'h-9 w-9 rounded-full transition',
                color === c.id ? 'ring-2 ring-[#10203A] ring-offset-2 ring-offset-[#FFFDF9]' : ''
              )}
              style={{ background: c.base, boxShadow: 'inset 0 0 0 1px rgba(16,32,58,.12)' }}
              aria-label={`Cor ${c.name}`}
              aria-pressed={color === c.id}
            />
          ))}
        </div>
      </div>

      {error && <p className="mt-3 rounded-2xl bg-[#FFE1DB] px-4 py-3 text-[13px] text-[#B23A28]">{error}</p>}

      <button
        type="submit"
        disabled={saving}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#10203A] py-3.5 text-[15px] text-[#FFF8EF] disabled:opacity-60"
      >
        {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
        {saving ? 'Criando…' : 'Criar turma'}
      </button>
    </form>
  );
}