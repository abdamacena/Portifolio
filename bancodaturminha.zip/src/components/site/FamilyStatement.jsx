import { LogOut } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { categoryOf, formatMoney, shortDate } from '@/lib/money';
import { skillsOf } from '@/lib/learning';
import BadgeStamp from '@/components/badges/BadgeStamp';
import FamilyWeekReport from '@/components/site/FamilyWeekReport';

const weekOf = (iso) => {
  if (!iso) return '';
  const [, m, d] = iso.split('-');
  return `semana de ${d}/${m}`;
};

function ChildStatement({ child }) {
  return (
    <article className="rounded-[28px] border border-[#10203A]/10 bg-white p-4">
      <header className="flex items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FFF1D6] text-2xl">
          {child.symbol || '🐻'}
        </span>
        <div className="min-w-0 flex-1">
          <h2 className="truncate font-heading text-[15px] font-bold leading-tight">
            {child.nickname || child.name}
          </h2>
          <p className="text-[11px] text-[#10203A]/45">Cartão nº {child.card_code}</p>
        </div>
        <div className="text-right">
          <p className="text-[10px] uppercase tracking-[0.15em] text-[#10203A]/40">Saldo</p>
          <p className="font-display text-xl leading-none" style={{ fontWeight: 1000 }}>
            {formatMoney(child.saldo)}
          </p>
        </div>
      </header>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <div className="rounded-2xl bg-[#D4F7EE] px-3 py-2">
          <p className="text-[10px] uppercase tracking-[0.15em] text-[#0E9B80]">Entrou na semana</p>
          <p className="font-heading text-sm font-bold">{formatMoney(child.week_ganho)}</p>
        </div>
        <div className="rounded-2xl bg-[#FFE1DB] px-3 py-2">
          <p className="text-[10px] uppercase tracking-[0.15em] text-[#E04A36]">Saiu na semana</p>
          <p className="font-heading text-sm font-bold">{formatMoney(child.week_gasto)}</p>
        </div>
      </div>

      {(child.learning || []).length > 0 && (
        <div className="mt-3 rounded-2xl bg-[#EAE6FF]/70 px-3 py-2.5">
          <p className="text-[10px] uppercase tracking-[0.15em] text-[#6B5BD6]">O que aprendeu</p>
          {child.learning.slice(0, 2).map((mark) => (
            <div key={mark.id} className="mt-1.5">
              <p className="text-[10px] text-[#10203A]/40">{weekOf(mark.week_start)}</p>
              <div className="mt-1 flex flex-wrap gap-1">
                {skillsOf(mark.skills).map((s) => (
                  <span
                    key={s.id}
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] ${
                      s.tone === 'good'
                        ? 'bg-white text-[#0E7280]'
                        : 'bg-[#FFE1DB] text-[#B23A28]'
                    }`}
                  >
                    <span aria-hidden="true">{s.emoji}</span>
                    {s.label}
                  </span>
                ))}
              </div>
              {mark.note && (
                <p className="mt-1 text-[11px] italic leading-relaxed text-[#10203A]/55">“{mark.note}”</p>
              )}
            </div>
          ))}
        </div>
      )}

      {(child.badges || []).length > 0 && (
        <div className="mt-3 rounded-2xl bg-[#FFF1D6] px-3 py-2.5">
          <p className="text-[10px] uppercase tracking-[0.15em] text-[#A9741A]">Selos que ganhou</p>
          <div className="mt-1.5 flex flex-wrap gap-2">
            {child.badges.map((b) => (
              <BadgeStamp key={b.id} badgeId={b.badge_id} size="sm" />
            ))}
          </div>
        </div>
      )}

      <p className="mb-2 mt-4 text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">Últimos registros</p>
      {child.transactions.length === 0 ? (
        <p className="rounded-2xl bg-[#FFF8EF] px-3 py-3 text-[12px] text-[#10203A]/50">
          Nenhuma moedinha registrada ainda.
        </p>
      ) : (
        <ul className="divide-y divide-[#10203A]/8">
          {child.transactions.map((tx) => {
            const cat = categoryOf(tx.category);
            const ganho = tx.type !== 'gasto';
            return (
              <li key={tx.id} className="flex items-center gap-2.5 py-2">
                <span className="text-base">{cat.emoji}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] leading-tight text-[#10203A]/80">{cat.label}</p>
                  <p className="text-[10px] text-[#10203A]/40">
                    {shortDate(tx.date)}
                    {tx.description ? ` · ${tx.description}` : ''}
                  </p>
                </div>
                <span
                  className={`shrink-0 text-[13px] font-semibold ${ganho ? 'text-[#0E9B80]' : 'text-[#E04A36]'}`}
                >
                  {ganho ? '+' : '−'}
                  {formatMoney(tx.amount)}
                </span>
              </li>
            );
          })}
        </ul>
      )}

      <FamilyWeekReport child={child} />
    </article>
  );
}

export default function FamilyStatement({ children, email, onExit }) {
  return (
    <section className="px-5 pt-6">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[10px] uppercase tracking-[0.26em] text-[#10203A]/40">Área da família</p>
          <h1 className="mt-1 font-display text-[1.7rem] leading-none tracking-[-0.035em]">Extrato</h1>
          {email && <p className="mt-1 truncate text-[11px] text-[#10203A]/45">{email}</p>}
        </div>
        <button
          type="button"
          onClick={() => (onExit ? onExit() : base44.auth.logout('/familia'))}
          className="flex items-center gap-1.5 rounded-full border border-[#10203A]/15 px-3 py-2 text-[11px] text-[#10203A]/60"
        >
          <LogOut className="h-3.5 w-3.5" /> Sair
        </button>
      </div>

      <div className="mt-5 space-y-3">
        {children.length === 0 ? (
          <div className="rounded-[28px] border border-[#10203A]/10 bg-white p-5 text-center">
            <p className="text-[13px] leading-relaxed text-[#10203A]/60">
              Nenhuma criança vinculada a este acesso ainda. Preencha a ficha no site ou fale com a professora.
            </p>
            <a
              href="/"
              className="mt-4 flex h-12 items-center justify-center rounded-2xl bg-[#FFB627] text-sm text-[#10203A]"
            >
              Ir para a ficha
            </a>
          </div>
        ) : (
          children.map((child) => <ChildStatement key={child.id} child={child} />)
        )}
      </div>
    </section>
  );
}