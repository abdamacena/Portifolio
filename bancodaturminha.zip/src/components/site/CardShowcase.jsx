import CardCover from '@/components/brand/CardCover';
import SectionHead from './SectionHead';
import { cardVariants } from '@/lib/brand';
import { symbols } from '@/lib/money';

export default function CardShowcase() {
  return (
    <section id="cartoes" className="scroll-mt-20 pt-12">
      <div className="px-5">
        <SectionHead
          eyebrow="Os cartões"
          title="Cinco capas, dezesseis animais."
          text="A criança reconhece o próprio banco pelo bicho do cartão, antes mesmo de saber ler. Cada criança escolhe o seu, então nenhuma turma fica igual à outra."
        />
      </div>

      <div className="mt-5 flex snap-x snap-mandatory gap-3 overflow-x-auto px-5 pb-3">
        {cardVariants.map((c, i) => (
          <div key={c.id} className="w-[168px] shrink-0 snap-start">
            <CardCover
              variant={c}
              holder={['Lia', 'Theo', 'Alice', 'Davi', 'Marina'][i]}
              symbol={symbols[i]}
              compact
            />
          </div>
        ))}
      </div>

      <div className="mt-2 flex gap-1.5 overflow-x-auto px-5 pb-1">
        {symbols.map((s) => (
          <span
            key={s}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[#10203A]/12 bg-white text-base"
          >
            {s}
          </span>
        ))}
      </div>
    </section>
  );
}