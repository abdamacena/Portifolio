import { Printer, QrCode, Sparkles } from 'lucide-react';
import SectionHead from './SectionHead';

const steps = [
  {
    icon: Printer,
    title: 'O cartão vai para casa',
    text: 'A criança escolhe um animal e recebe uma cartela de papel com o nome dela, o login e o QR. Um para cada criança da turma.',
  },
  {
    icon: QrCode,
    title: 'A moedinha é registrada',
    text: 'A professora aponta a câmera para o QR do cartão, ou digita o login, e escolhe o motivo e o valor.',
  },
  {
    icon: Sparkles,
    title: 'A sexta vira relatório',
    text: 'A folha da semana sai pronta com ganhos, gastos e saldo, e volta assinada pela família.',
  },
];

export default function HowItWorks() {
  return (
    <section id="como-funciona" className="scroll-mt-20 px-5 pt-12">
      <SectionHead
        eyebrow="Como funciona"
        title="Três passos, uma semana de descobertas."
        text="Do cartão que a criança segura ao relatório que a família lê: nada de planilha no meio do caminho."
      />

      <ol className="mt-6 space-y-2.5">
        {steps.map((s, i) => (
          <li key={s.title} className="flex gap-3 rounded-3xl bg-white p-4 brand-hairline">
            <div className="flex flex-col items-center">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FFB627] text-[#10203A]">
                <s.icon className="h-4 w-4" />
              </span>
              <span className="mt-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-[#10203A]/6 text-[10px] text-[#10203A]/45">
                {i + 1}
              </span>
            </div>
            <div className="min-w-0">
              <h3 className="font-heading text-[15px] font-bold leading-tight">{s.title}</h3>
              <p className="mt-1 text-[13px] leading-relaxed text-[#10203A]/55">{s.text}</p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}