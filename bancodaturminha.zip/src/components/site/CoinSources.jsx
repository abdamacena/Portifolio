import { categories } from '@/lib/money';
import SectionHead from './SectionHead';

export default function CoinSources() {
  return (
    <section id="moedinhas" className="scroll-mt-20 px-5 pt-12">
      <SectionHead
        eyebrow="As moedinhas"
        title="De onde vêm e para onde vão."
        text="Moedinhas não são dinheiro: são pontos da semana que mostram escolhas e conquistas da turma. Ganhar e gastar fazem parte da mesma descoberta."
      />

      <div className="mt-6 space-y-2.5">
        <div className="rounded-3xl bg-[#D4F7EE] p-4">
          <h3 className="font-heading text-[15px] font-bold text-[#0E9B80]">Entra</h3>
          <ul className="mt-3 grid grid-cols-2 gap-2">
            {categories.ganho.slice(0, 4).map((c) => (
              <li key={c.id} className="flex items-center gap-2 rounded-2xl bg-white/70 px-2.5 py-2">
                <span className="text-base">{c.emoji}</span>
                <span className="text-[11px] leading-tight text-[#10203A]/70">{c.label}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-3xl bg-[#FFE1DB] p-4">
          <h3 className="font-heading text-[15px] font-bold text-[#E04A36]">Sai</h3>
          <ul className="mt-3 grid grid-cols-2 gap-2">
            {categories.gasto.slice(0, 2).map((c) => (
              <li key={c.id} className="flex items-center gap-2 rounded-2xl bg-white/70 px-2.5 py-2">
                <span className="text-base">{c.emoji}</span>
                <span className="text-[11px] leading-tight text-[#10203A]/70">{c.label}</span>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11px] leading-relaxed text-[#10203A]/50">
            Gastar não é erro: é a primeira vez que a criança escolhe entre duas coisas.
          </p>
        </div>
      </div>
    </section>
  );
}