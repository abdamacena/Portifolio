import { useState } from 'react';
import { Loader2, LogIn } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { forgetFamilyAccess, rememberFamilyAccess, savedFamilyAccess } from '@/lib/familyDevice';

const field =
  'h-[52px] w-full rounded-2xl border border-[#10203A]/12 bg-white px-4 text-[15px] text-[#10203A] outline-none transition focus:border-[#10203A]/40 focus:ring-4 focus:ring-[#FFB627]/25';

const clean = (value) =>
  String(value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9._-]/g, '')
    .slice(0, 20);

export default function FamilyLogin({ onLoggedIn, onSignup }) {
  const saved = savedFamilyAccess();
  const [known, setKnown] = useState(Boolean(saved.class_code && saved.login));
  const [classCode, setClassCode] = useState(saved.class_code);
  const [login, setLogin] = useState(saved.login);
  const [birthDate, setBirthDate] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const trocarCrianca = () => {
    forgetFamilyAccess();
    setClassCode('');
    setLogin('');
    setBirthDate('');
    setError('');
    setKnown(false);
  };

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (!classCode.trim() || !login.trim()) {
      setError('Preencha o código da turma e o login da criança.');
      return;
    }
    if (!birthDate) {
      setError('Confirme a data de aniversário da criança.');
      return;
    }

    setSaving(true);
    try {
      const res = await base44.functions.invoke('entrarFamilia', {
        class_code: classCode.trim().toUpperCase(),
        login: login.trim(),
        birth_date: birthDate,
      });
      if (res.data?.error) throw new Error(res.data.error);

      const access = {
        class_code: res.data?.class_code || classCode.trim().toUpperCase(),
        login: res.data?.child?.login || login.trim(),
        birth_date: birthDate,
      };
      rememberFamilyAccess(access);
      if (onLoggedIn) onLoggedIn(access);
    } catch (err) {
      setError(err?.response?.data?.error || err?.message || 'Não foi possível entrar agora.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <form onSubmit={submit} className="space-y-3 rounded-[28px] border border-[#10203A]/10 bg-[#FFFDF9] p-4">
        {known ? (
          <div className="flex items-center justify-between gap-3 rounded-2xl bg-[#10203A]/5 px-4 py-3">
            <span className="min-w-0 truncate text-[12px] text-[#10203A]/60">
              Turma <strong className="font-semibold text-[#10203A]">{classCode}</strong> · login{' '}
              <strong className="font-semibold text-[#10203A]">{login}</strong>
            </span>
            <button
              type="button"
              onClick={trocarCrianca}
              className="shrink-0 text-[12px] text-[#10203A]/60 underline"
            >
              Trocar
            </button>
          </div>
        ) : (
          <>
            <label className="block">
              <span className="mb-1.5 block text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">
                Código da turma
              </span>
              <input
                value={classCode}
                onChange={(e) => setClassCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12))}
                placeholder="AZUL27"
                autoCapitalize="characters"
                autoCorrect="off"
                spellCheck={false}
                className={`${field} font-mono uppercase tracking-[0.14em]`}
              />
            </label>

            <label className="block">
              <span className="mb-1.5 block text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">
                Login da criança
              </span>
              <input
                value={login}
                onChange={(e) => setLogin(clean(e.target.value))}
                placeholder="lilo"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                className={`${field} font-mono lowercase tracking-[0.06em]`}
              />
            </label>
          </>
        )}

        <label className="block">
          <span className="mb-1.5 block text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">
            Data de aniversário
          </span>
          <input
            type="date"
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
            className={field}
          />
        </label>

        {error && <p className="rounded-2xl bg-[#FFE1DB] px-4 py-3 text-[13px] text-[#B23A28]">{error}</p>}

        <button
          type="submit"
          disabled={saving}
          className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-[#10203A] text-[15px] text-[#FFF8EF] transition active:scale-[0.99] disabled:opacity-60"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />}
          {saving ? 'Entrando…' : 'Entrar'}
        </button>

        <div className="flex items-center justify-between text-[12px] text-[#10203A]/55">
          <span />
          {onSignup ? (
            <button type="button" onClick={onSignup} className="underline">
              Enviar a ficha da criança
            </button>
          ) : null}
        </div>
      </form>

      <p className="mt-4 rounded-2xl bg-[#FFF1D6] px-4 py-3 text-[12px] leading-relaxed text-[#10203A]/60">
        Este celular guarda o código da turma e o login. A data de aniversário é sempre pedida de novo para confirmar
        que é a família da criança.
      </p>
    </div>
  );
}