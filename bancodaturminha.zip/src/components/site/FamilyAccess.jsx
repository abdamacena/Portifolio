import { useState } from 'react';
import FamilyLogin from './FamilyLogin';
import RegistrationForm from './RegistrationForm';

export default function FamilyAccess({ onLoggedIn }) {
  const [mode, setMode] = useState(() =>
    new URLSearchParams(window.location.search).get('ficha') ? 'criar' : 'entrar'
  );

  return (
    <section id="familia" className="scroll-mt-20 px-5 pt-6">
      <p className="text-[10px] uppercase tracking-[0.26em] text-[#10203A]/40">Área da criança</p>
      <h1 className="balance mt-2 font-display text-[2rem] leading-[0.95] tracking-[-0.035em]">
        {mode === 'entrar' ? 'O painel da sua criança.' : 'Envie a ficha da criança.'}
      </h1>

      <div className="mt-4 grid grid-cols-2 gap-1 rounded-full bg-[#10203A]/6 p-1">
        {[
          { id: 'entrar', label: 'Entrar' },
          { id: 'criar', label: 'Enviar ficha' },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setMode(tab.id)}
            className={`rounded-full py-2 text-[12px] transition-colors ${
              mode === tab.id ? 'bg-[#10203A] text-[#FFF8EF]' : 'text-[#10203A]/60'
            }`}
            aria-pressed={mode === tab.id}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="mt-3">
        {mode === 'entrar' ? (
          <FamilyLogin onLoggedIn={onLoggedIn} onSignup={() => setMode('criar')} />
        ) : (
          <RegistrationForm embedded onCreated={onLoggedIn} />
        )}
      </div>
    </section>
  );
}