import { useState } from 'react';
import { Loader2 } from 'lucide-react';
import GoogleIcon from '@/components/GoogleIcon';
import { signInWithProvider } from '@/lib/authMfaFlow';

export default function GoogleSignInButton({
  label = 'Continuar com o Google',
  returnTo,
  prepare,
  onError,
  className = '',
}) {
  const [loading, setLoading] = useState(false);

  const click = async () => {
    const dest =
      (prepare ? prepare() : returnTo) || `${window.location.pathname}${window.location.search}`;
    if (!dest) return;
    setLoading(true);
    try {
      await signInWithProvider('google', dest);
    } catch (err) {
      setLoading(false);
      if (onError) onError(err?.message || 'Não foi possível abrir o Google agora.');
    }
  };

  return (
    <button
      type="button"
      onClick={click}
      disabled={loading}
      className={`flex h-[52px] w-full items-center justify-center gap-2.5 rounded-2xl border border-[#10203A]/12 bg-white text-[15px] text-[#10203A] transition active:scale-[0.99] disabled:opacity-60 ${className}`}
    >
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <GoogleIcon className="h-5 w-5" />}
      {loading ? 'Abrindo o Google…' : label}
    </button>
  );
}