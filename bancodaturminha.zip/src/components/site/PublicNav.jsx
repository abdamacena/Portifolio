import { Link } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import AccountPill from '@/components/AccountPill';
import Logo from '@/components/brand/Logo';

export default function PublicNav() {
  const { user } = useAuth();

  return (
    <header className="sticky top-0 z-40 border-b border-[#10203A]/8 bg-[#FFF8EF]/92 backdrop-blur-xl">
      <div className="flex items-center justify-between gap-3 px-5 py-3">
        <a href="#topo" aria-label="Banco da Turminha — início">
          <Logo size="md" />
        </a>
        {user ? (
          <AccountPill label="Família" />
        ) : (
          <Link
            to="/familia"
            className="rounded-full bg-[#10203A] px-4 py-2 text-xs text-[#FFF8EF] transition active:scale-95"
          >
            Entrar
          </Link>
        )}
      </div>
    </header>
  );
}