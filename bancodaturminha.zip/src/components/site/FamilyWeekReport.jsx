import { useEffect } from 'react';
import { Printer } from 'lucide-react';
import Logo from '@/components/brand/Logo';
import { badgeOf } from '@/lib/badges';
import { skillsOf } from '@/lib/learning';
import { categoryOf, formatMoney, isoDate, shortDate, weekLabel, weekRange } from '@/lib/money';

export default function FamilyWeekReport({ child }) {
  const range = weekRange(new Date());
  const weekStart = isoDate(range.start);

  useEffect(() => {
    const done = () => document.body.classList.remove('report-only');
    window.addEventListener('afterprint', done);
    return () => {
      window.removeEventListener('afterprint', done);
      document.body.classList.remove('report-only');
    };
  }, []);

  const print = () => {
    document.body.classList.add('report-only');
    window.setTimeout(() => window.print(), 80);
  };

  const weekTxs = child.week_transactions || [];
  const marks = (child.learning || []).filter((m) => m.week_start === weekStart);
  const badges = (child.badges || []).filter((b) => String(b.date || '') >= weekStart);

  return (
    <>
      <button
        type="button"
        onClick={print}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-[#10203A]/15 py-3 text-[13px] text-[#10203A]/70"
      >
        <Printer className="h-4 w-4" /> Imprimir relatório da semana
      </button>

      <div className="print-sheet hidden bg-white text-[#10203A] print:block">
        <div className="px-[10mm] py-[6mm]">
          <div className="flex items-start justify-between gap-4 border-b border-[#10203A]/15 pb-4">
            <div>
              <Logo size="sm" />
              <p className="mt-2 text-[10px] uppercase tracking-[0.2em] text-[#10203A]/50">
                Relatório semanal da criança
              </p>
            </div>
            <div className="text-right">
              <p className="text-[9px] uppercase tracking-[0.18em] text-[#10203A]/50">Semana</p>
              <p className="text-[12px] font-semibold">{weekLabel(range)}</p>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FFF1D6] text-2xl">
              {child.symbol || '🐻'}
            </span>
            <div>
              <p className="font-heading text-lg font-bold leading-tight">{child.name}</p>
              <p className="text-[11px] text-[#10203A]/50">
                Cartão nº {child.card_code}
                {child.login ? ` · @${child.login}` : ''}
              </p>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-3 gap-2">
            <div className="rounded-2xl bg-[#D4F7EE] px-3 py-2">
              <p className="text-[9px] uppercase tracking-[0.15em] text-[#0E9B80]">Entrou</p>
              <p className="font-heading text-base font-bold">{formatMoney(child.week_ganho)}</p>
            </div>
            <div className="rounded-2xl bg-[#FFE1DB] px-3 py-2">
              <p className="text-[9px] uppercase tracking-[0.15em] text-[#E04A36]">Saiu</p>
              <p className="font-heading text-base font-bold">{formatMoney(child.week_gasto)}</p>
            </div>
            <div className="rounded-2xl bg-[#FFF1D6] px-3 py-2">
              <p className="text-[9px] uppercase tracking-[0.15em] text-[#A9741A]">Saldo</p>
              <p className="font-heading text-base font-bold">{formatMoney(child.saldo)}</p>
            </div>
          </div>

          <p className="mt-5 text-[10px] uppercase tracking-[0.18em] text-[#10203A]/50">
            Movimentações da semana
          </p>
          {weekTxs.length === 0 ? (
            <p className="mt-2 text-[12px] text-[#10203A]/50">Nesta semana ainda não houve movimentações.</p>
          ) : (
            <table className="mt-1 w-full text-left">
              <tbody>
                {weekTxs.map((tx) => {
                  const cat = categoryOf(tx.category);
                  const ganho = tx.type !== 'gasto';
                  return (
                    <tr key={tx.id} className="border-b border-[#10203A]/10">
                      <td className="py-1.5 pr-2 align-top text-[11px] text-[#10203A]/50">
                        {shortDate(tx.date)}
                      </td>
                      <td className="py-1.5 pr-2 align-top text-[12px]">
                        <span className="mr-1">{cat.emoji}</span>
                        {cat.label}
                        {tx.description ? (
                          <span className="text-[#10203A]/50"> · {tx.description}</span>
                        ) : null}
                      </td>
                      <td
                        className={`py-1.5 text-right align-top text-[12px] font-semibold ${
                          ganho ? 'text-[#0E9B80]' : 'text-[#E04A36]'
                        }`}
                      >
                        {ganho ? '+' : '−'}
                        {formatMoney(tx.amount)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          {marks.length > 0 && (
            <div className="print-break mt-4 rounded-2xl bg-[#EAE6FF]/70 px-3 py-2.5">
              <p className="text-[10px] uppercase tracking-[0.15em] text-[#6B5BD6]">O que aprendeu</p>
              {marks.map((mark) => (
                <div key={mark.id} className="mt-1.5">
                  <div className="flex flex-wrap gap-1">
                    {skillsOf(mark.skills).map((s) => (
                      <span
                        key={s.id}
                        className="inline-flex items-center gap-1 rounded-full bg-white px-2 py-0.5 text-[10px] text-[#0E7280]"
                      >
                        <span aria-hidden="true">{s.emoji}</span>
                        {s.label}
                      </span>
                    ))}
                  </div>
                  {mark.note && (
                    <p className="mt-1 text-[11px] italic leading-relaxed text-[#10203A]/55">“{mark.note}”</p>
                  )}
                </div>
              ))}
            </div>
          )}

          {badges.length > 0 && (
            <div className="print-break mt-3 rounded-2xl bg-[#FFF1D6] px-3 py-2.5">
              <p className="text-[10px] uppercase tracking-[0.15em] text-[#A9741A]">Selos da semana</p>
              <div className="mt-1.5 flex flex-wrap gap-2">
                {badges.map((b) => {
                  const badge = badgeOf(b.badge_id);
                  return (
                    <span key={b.id} className="inline-flex items-center gap-1 text-[11px] text-[#10203A]/75">
                      <span aria-hidden="true">{badge.emoji}</span>
                      {badge.label}
                    </span>
                  );
                })}
              </div>
            </div>
          )}

          <div className="mt-6 flex items-end justify-between gap-6 border-t border-[#10203A]/10 pt-4">
            <p className="max-w-[62%] text-[10px] leading-relaxed text-[#10203A]/50">
              Cada moedinha foi conquistada em casa, na escola ou com os amigos. Converse com a criança sobre as
              escolhas da semana.
            </p>
            <div className="text-right">
              <div className="mb-1 w-40 border-b border-[#10203A]/30" />
              <p className="text-[9px] uppercase tracking-[0.18em] text-[#10203A]/40">Assinatura da família</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}