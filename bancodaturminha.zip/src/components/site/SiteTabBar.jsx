import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ClipboardList, Coins, CreditCard, Home, Users } from 'lucide-react';

const anchors = [
  { id: 'topo', label: 'Início', icon: Home },
  { id: 'moedinhas', label: 'Moedinhas', icon: Coins },
  { id: 'cartoes', label: 'Cartões', icon: CreditCard },
  { id: 'ficha', label: 'Ficha', icon: ClipboardList },
];

export default function SiteTabBar() {
  const location = useLocation();
  const navigate = useNavigate();
  const [active, setActive] = useState('#topo');
  const onFamily = location.pathname === '/familia';

  useEffect(() => {
    if (!location.hash) return;
    const timer = setTimeout(() => {
      document.getElementById(location.hash.slice(1))?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
    return () => clearTimeout(timer);
  }, [location.hash, location.pathname]);

  const go = (id) => {
    setActive(`#${id}`);
    if (location.pathname === '/') {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      navigate(`/#${id}`);
    }
  };

  const itemClass = (on) =>
    `flex flex-col items-center gap-1 rounded-2xl py-2 text-[10px] transition ${
      on ? 'text-[#10203A]' : 'text-[#10203A]/40'
    }`;

  return (
    <nav className="fixed bottom-0 left-1/2 z-50 w-full max-w-[430px] -translate-x-1/2 border-t border-[#10203A]/10 bg-[#FFF8EF]/95 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1.5 backdrop-blur-xl">
      <div className="grid grid-cols-5">
        {anchors.map((t) => (
          <button key={t.id} type="button" onClick={() => go(t.id)} className={itemClass(active === `#${t.id}`)}>
            <t.icon className={`h-5 w-5 ${active === `#${t.id}` ? 'stroke-[2.4]' : 'stroke-[1.8]'}`} />
            {t.label}
          </button>
        ))}
        <Link to="/familia" onClick={() => setActive('#familia')} className={itemClass(onFamily)}>
          <Users className={`h-5 w-5 ${onFamily ? 'stroke-[2.4]' : 'stroke-[1.8]'}`} />
          Família
        </Link>
      </div>
    </nav>
  );
}