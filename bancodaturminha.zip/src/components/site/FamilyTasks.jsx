import { useEffect, useState } from 'react';
import { Check, Home, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { formatMoney } from '@/lib/money';

const field =
  'h-[48px] w-full rounded-2xl border border-[#10203A]/12 bg-white px-4 text-[14px] text-[#10203A] outline-none transition focus:border-[#10203A]/40 focus:ring-4 focus:ring-[#FFB627]/25';

export default function FamilyTasks({ children = [], access = null, onRegistered }) {
  const [tasks, setTasks] = useState([]);
  const [childId, setChildId] = useState(children[0]?.id || '');
  const [taskId, setTaskId] = useState('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const activeChild = children.find((c) => c.id === childId) || children[0];
  const classId = activeChild?.class_id || '';

  useEffect(() => {
    if (!classId) return;
    base44.entities.Task.filter({ active: true, class_id: classId }, { sort: 'title', limit: 50 }).then(
      (page) => setTasks(page.items || [])
    );
  }, [classId]);

  useEffect(() => {
    if (!childId && children[0]) setChildId(children[0].id);
  }, [children, childId]);

  const register = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!childId || !taskId) {
      setError('Escolha a criança e a tarefa.');
      return;
    }
    setSaving(true);
    try {
      const res = await base44.functions.invoke('registrarTarefa', {
        child_id: childId,
        task_id: taskId,
        note,
        ...(access
          ? { class_code: access.class_code, login: access.login, birth_date: access.birth_date }
          : {}),
      });
      if (res.data?.error) throw new Error(res.data.error);
      const child = children.find((c) => c.id === childId);
      setSuccess(
        `${res.data.title} registrada! +${formatMoney(res.data.amount)} para ${
          child?.nickname || child?.name || 'a criança'
        }.`
      );
      setTaskId('');
      setNote('');
      if (onRegistered) onRegistered();
    } catch (err) {
      setError(err?.response?.data?.error || err?.message || 'Não foi possível registrar agora.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <section id="tarefas-casa" className="scroll-mt-20 px-5 pt-4">
      <div className="rounded-[28px] border border-[#10203A]/10 bg-white p-4">
        <div className="flex items-center gap-2.5">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#EAE6FF] text-[#8B7CF6]">
            <Home className="h-4 w-4" />
          </span>
          <div>
            <h2 className="font-heading text-[15px] font-bold leading-tight">Tarefas de casa</h2>
            <p className="text-[11px] text-[#10203A]/45">Registre o que a criança fez e as moedinhas entram na hora.</p>
          </div>
        </div>

        {tasks.length === 0 ? (
          <p className="mt-3 rounded-2xl bg-[#FFF8EF] px-3 py-3 text-[12px] text-[#10203A]/50">
            A professora ainda não cadastrou tarefas.
          </p>
        ) : (
          <form onSubmit={register} className="mt-4 space-y-3">
            {children.length > 1 && (
              <div className="flex flex-wrap gap-2">
                {children.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setChildId(c.id)}
                    className={`flex items-center gap-1.5 rounded-full border px-3 py-2 text-[12px] transition ${
                      childId === c.id
                        ? 'border-[#10203A] bg-[#FFF1D6] text-[#10203A]'
                        : 'border-[#10203A]/12 text-[#10203A]/55'
                    }`}
                  >
                    <span>{c.symbol || '🐻'}</span>
                    {c.nickname || c.name}
                  </button>
                ))}
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              {tasks.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTaskId(t.id)}
                  className={`flex flex-col items-start gap-1 rounded-2xl border p-3 text-left transition ${
                    taskId === t.id ? 'border-[#10203A] bg-[#FFF1D6]' : 'border-[#10203A]/12 bg-[#FFFDF9]'
                  }`}
                  aria-pressed={taskId === t.id}
                >
                  <span className="text-xl">{t.emoji || '🧹'}</span>
                  <span className="text-[12px] leading-tight text-[#10203A]/80">{t.title}</span>
                  <span className="text-[11px] font-semibold text-[#0E9B80]">{formatMoney(t.value)}</span>
                </button>
              ))}
            </div>

            <input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="O que ela fez? (opcional)"
              className={field}
            />

            {error && <p className="rounded-2xl bg-[#FFE1DB] px-4 py-3 text-[13px] text-[#B23A28]">{error}</p>}

            {success && (
              <p className="flex items-center gap-2 rounded-2xl bg-[#D4F7EE] px-4 py-3 text-[13px] text-[#0E9B80]">
                <Check className="h-4 w-4 shrink-0" /> {success}
              </p>
            )}

            <button
              type="submit"
              disabled={saving}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#12C2A0] py-3.5 text-[15px] text-white transition active:scale-[0.99] disabled:opacity-60"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              {saving ? 'Registrando…' : 'Registrar tarefa'}
            </button>
          </form>
        )}
      </div>
    </section>
  );
}