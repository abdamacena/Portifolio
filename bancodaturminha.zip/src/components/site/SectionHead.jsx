export default function SectionHead({ eyebrow, title, text }) {
  return (
    <>
      <p className="text-[10px] uppercase tracking-[0.26em] text-[#10203A]/40">{eyebrow}</p>
      <h2 className="balance mt-2 font-display text-[1.9rem] leading-[0.96] tracking-[-0.035em]">{title}</h2>
      {text && <p className="mt-3 text-[13px] leading-relaxed text-[#10203A]/55">{text}</p>}
    </>
  );
}