import { useEffect, useState } from 'react';
import { ArrowRight, Check, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { cardVariants } from '@/lib/brand';
import { symbols } from '@/lib/money';
import { rememberFamilyAccess } from '@/lib/familyDevice';

const initial = {
  class_code: '',
  name: '',
  login: '',
  birth_date: '',
  symbol: '🐻',
  cover: 'manga',
  guardian_name: '',
  guardian_contact: '',
};

const field =
  'h-[52px] w-full rounded-2xl border border-[#10203A]/12 bg-white px-4 text-[15px] text-[#10203A] outline-none transition focus:border-[#10203A]/40 focus:ring-4 focus:ring-[#FFB627]/25';

function Label({ children }) {
  return (
    <span className="mb-1.5 block text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">{children}</span>
  );
}

export default function RegistrationForm({ onCreated, embedded = false }) {
  const [form, setForm] = useState(initial);
  const [authorized, setAuthorized] = useState(false);
  const [step, setStep] = useState('form');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(null);
  const [user, setUser] = useState(null);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  useEffect(() => {
    base44.auth
      .isAuthenticated()
      .then((ok) => (ok ? base44.auth.me() : null))
      .then((me) => {
        if (!me) return;
        setUser(me);
        setForm((f) => ({
          ...f,
          guardian_name: f.guardian_name || me.full_name || '',
        }));
      })
      .catch(() => setUser(null));
  }, []);

  const createChild = async (data) => {
    const res = await base44.functions.invoke('cadastrarCrianca', { ...data, authorized: true });
    if (res.data?.error) throw new Error(res.data.error);
    setDone({
      ...res.data,
      class_code: data.class_code.trim().toUpperCase(),
      birth_date: data.birth_date,
    });
    setStep('done');
    setForm(initial);
    setAuthorized(false);
  };

  const fichaProblem = () => {
    if (!form.class_code.trim()) return 'Informe o código da turma que a professora passou.';
    if (form.name.trim().length < 2) return 'Escreva o nome da criança.';
    if (form.login.trim().length < 3) {
      return 'Escolha o login da criança com pelo menos 3 letras ou números.';
    }
    if (form.guardian_name.trim().length < 2) return 'Escreva o nome do responsável.';
    if (form.guardian_contact.trim().length < 8) return 'Informe o telefone com DDD.';
    if (!form.birth_date) return 'Informe a data de nascimento: ela confirma o acesso da família.';
    if (!authorized) return 'Marque a autorização para continuar.';
    return '';
  };

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    const problem = fichaProblem();
    if (problem) return setError(problem);

    setSaving(true);
    try {
      await createChild(form);
    } catch (err) {
      setError(err?.response?.data?.error || err?.message || 'Não foi possível concluir agora.');
    } finally {
      setSaving(false);
    }
  };

  const goToStatement = () => {
    const access = {
      class_code: done?.class_code || '',
      login: done?.login || '',
      birth_date: done?.birth_date || '',
    };
    rememberFamilyAccess(access);
    setDone(null);
    setStep('form');
    if (onCreated) onCreated(access);
  };

  if (step === 'done' && done) {
    return (
      <section id={embedded ? undefined : 'ficha'} className={embedded ? undefined : 'scroll-mt-20 px-5 pt-12'}>
        <div className="rounded-[28px] bg-[#D4F7EE] p-6 text-center">
          <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[#12C2A0] text-white">
            <Check className="h-7 w-7" />
          </span>
          <h2 className="mt-4 font-display text-[1.7rem] leading-none tracking-[-0.03em]">Ficha enviada!</h2>
          <p className="mt-2 text-[13px] leading-relaxed text-[#10203A]/60">
            {done.name} já está na turma {done.class_name || ''}. A professora entrega o cartão em sala.
          </p>
          <div className="mt-5 flex items-center justify-center gap-3 rounded-2xl bg-white/80 px-4 py-3">
            <span className="text-3xl">{done.symbol}</span>
            <div className="text-left">
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">Cartão</p>
              <p className="font-display text-2xl leading-none" style={{ fontWeight: 1000 }}>
                nº {done.card_code}
              </p>
              <p className="mt-0.5 font-mono text-[11px] text-[#10203A]/50">@{done.login}</p>
            </div>
          </div>
          <p className="mt-3 text-[11px] leading-relaxed text-[#10203A]/50">
            Para ver o extrato, entre com o código da turma, o login e a data de aniversário.
          </p>
          {onCreated ? (
            <button
              type="button"
              onClick={goToStatement}
              className="mt-4 flex w-full items-center justify-center rounded-2xl bg-[#12C2A0] py-3.5 text-sm text-white"
            >
              Ver o extrato da criança
            </button>
          ) : (
            <a
              href="/familia"
              onClick={goToStatement}
              className="mt-4 flex w-full items-center justify-center rounded-2xl bg-[#12C2A0] py-3.5 text-sm text-white"
            >
              Ver o extrato da criança
            </a>
          )}
          <button
            type="button"
            onClick={() => {
              setDone(null);
              setStep('form');
            }}
            className="mt-2 w-full rounded-2xl border border-[#10203A]/15 py-3.5 text-sm text-[#10203A]/70"
          >
            Preencher outra ficha
          </button>
        </div>
      </section>
    );
  }

  return (
    <section id="ficha" className="scroll-mt-20 px-5 pt-12">
      <p className="text-[10px] uppercase tracking-[0.26em] text-[#10203A]/40">Ficha de cadastro</p>
      <h2 className="balance mt-2 font-display text-[1.9rem] leading-[0.96] tracking-[-0.035em]">
        Preencha aqui, sem papel.
      </h2>
      <p className="mt-3 text-[13px] leading-relaxed text-[#10203A]/55">
        Leva dois minutos. A criança escolhe o animal e a cor do cartão, e a família já sai com o acesso ao extrato.
      </p>

      <form onSubmit={submit} className="mt-5 space-y-4 rounded-[28px] border border-[#10203A]/10 bg-[#FFFDF9] p-4">
        <label className="block">
          <Label>Código da turma</Label>
          <input
            value={form.class_code}
            onChange={(e) =>
              setForm((f) => ({
                ...f,
                class_code: e.target.value
                  .toUpperCase()
                  .normalize('NFD')
                  .replace(/[^A-Z0-9]/g, '')
                  .slice(0, 12),
              }))
            }
            placeholder="AZUL27"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            className={`${field} font-mono uppercase tracking-[0.14em]`}
          />
          <p className="mt-1.5 text-[11px] leading-relaxed text-[#10203A]/45">
            A professora passa esse código para a ficha entrar na turma certa. Use só letras maiúsculas e números.
          </p>
        </label>

        <label className="block">
          <Label>Nome da criança</Label>
          <input value={form.name} onChange={set('name')} placeholder="Nome completo" className={field} />
        </label>

        <label className="block">
          <Label>Nascimento</Label>
          <input type="date" value={form.birth_date} onChange={set('birth_date')} className={field} />
        </label>

        <label className="block">
          <Label>Login da criança</Label>
          <input
            value={form.login}
            onChange={(e) =>
              setForm((f) => ({
                ...f,
                login: e.target.value
                  .toLowerCase()
                  .normalize('NFD')
                  .replace(/[^a-z0-9._-]/g, '')
                  .slice(0, 20),
              }))
            }
            placeholder="lilo"
            autoCapitalize="none"
            autoCorrect="off"
            spellCheck={false}
            className={`${field} font-mono lowercase tracking-[0.06em]`}
          />
          <p className="mt-1.5 text-[11px] leading-relaxed text-[#10203A]/45">
            É a entrada da criança no extrato e vai impressa no cartão. Só letras, números, ponto e hífen.
          </p>
        </label>

        <div>
          <Label>Animal do cartão</Label>
          <div className="grid grid-cols-8 gap-1.5">
            {symbols.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setForm((f) => ({ ...f, symbol: s }))}
                className={`flex h-10 items-center justify-center rounded-xl border text-lg transition ${
                  form.symbol === s ? 'border-[#10203A] bg-[#FFB627]/25' : 'border-[#10203A]/12 bg-white'
                }`}
                aria-label={`Animal ${s}`}
                aria-pressed={form.symbol === s}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div>
          <Label>Cor do cartão</Label>
          <div className="flex gap-2">
            {cardVariants.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setForm((f) => ({ ...f, cover: c.id }))}
                className={`h-10 w-10 rounded-full transition ${
                  form.cover === c.id ? 'ring-2 ring-[#10203A] ring-offset-2 ring-offset-[#FFFDF9]' : ''
                }`}
                style={{ background: c.base, boxShadow: 'inset 0 0 0 1px rgba(16,32,58,.12)' }}
                aria-label={`Capa ${c.name}`}
                aria-pressed={form.cover === c.id}
              />
            ))}
          </div>
        </div>

        <div className="h-px bg-[#10203A]/8" />

        <label className="block">
          <Label>Responsável</Label>
          <input
            value={form.guardian_name}
            onChange={set('guardian_name')}
            placeholder="Nome do responsável"
            className={field}
          />
        </label>

        <label className="block">
          <Label>WhatsApp</Label>
          <input
            value={form.guardian_contact}
            onChange={set('guardian_contact')}
            placeholder="(11) 90000-0000"
            inputMode="tel"
            className={field}
          />
        </label>

        <button
          type="button"
          onClick={() => setAuthorized((v) => !v)}
          className="flex w-full items-start gap-3 rounded-2xl border border-[#10203A]/12 bg-white p-3 text-left"
          aria-pressed={authorized}
        >
          <span
            className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition ${
              authorized ? 'border-[#12C2A0] bg-[#12C2A0] text-white' : 'border-[#10203A]/25'
            }`}
          >
            {authorized && <Check className="h-3.5 w-3.5" />}
          </span>
          <span className="text-[12px] leading-relaxed text-[#10203A]/65">
            Autorizo a participação no Banco da Turminha e o registro das atividades para o relatório da semana.
          </span>
        </button>

        {error && <p className="rounded-2xl bg-[#FFE1DB] px-4 py-3 text-[13px] text-[#B23A28]">{error}</p>}

        <button
          type="submit"
          disabled={saving}
          className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-[#10203A] text-[15px] text-[#FFF8EF] transition active:scale-[0.99] disabled:opacity-60"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
          {saving ? 'Enviando…' : 'Enviar ficha'}
          {!saving && <ArrowRight className="h-4 w-4" />}
        </button>
      </form>
    </section>
  );
}