import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Image } from '@/components/ui/image';
import CardCover from '@/components/brand/CardCover';

const numbers = [
  ['1', 'cartão por criança', '#FFB627'],
  ['16', 'animais para escolher', '#12C2A0'],
  ['2', 'toques por registro', '#8B7CF6'],
  ['1', 'relatório por semana', '#FF6B57'],
];

export default function SiteHero() {
  return (
    <section id="topo" className="scroll-mt-20 px-5 pt-6">
      <span className="inline-flex items-center gap-2 rounded-full border border-[#10203A]/12 bg-white/70 px-3 py-1.5 text-[10px] uppercase tracking-[0.22em] text-[#10203A]/55">
        <span className="h-1.5 w-1.5 rounded-full bg-[#FFB627]" />
        Educação infantil
      </span>

      <h1 className="balance mt-4 font-display text-[2.6rem] leading-[0.92] tracking-[-0.04em]">
        Um banco do tamanho de uma criança.
      </h1>

      <p className="mt-4 text-[15px] leading-relaxed text-[#10203A]/60">
        Um cartão com animal para cada criança, moedinhas que se ganham arrumando os brinquedos ou ajudando um amigo e um
        extrato que a família acompanha. Funciona com a turma pequena ou cheia.
      </p>

      <div className="mt-6 grid gap-2.5">
        <Link
          to="/familia"
          className="flex h-14 items-center justify-center gap-2 rounded-2xl bg-[#FFB627] text-[15px] text-[#10203A] shadow-[0_16px_30px_-18px_rgba(255,182,39,0.9)] transition active:scale-[0.98]"
        >
          Área da criança <ArrowRight className="h-4 w-4" />
        </Link>
        <Link
          to="/professora"
          className="flex h-14 items-center justify-center rounded-2xl border border-[#10203A]/18 bg-white/60 text-[15px] text-[#10203A]/75 transition active:scale-[0.98]"
        >
          Sou a professora
        </Link>
      </div>

      <div className="relative mt-7 flex items-center gap-3 overflow-hidden rounded-[26px] border border-[#10203A]/10 bg-white p-3 shadow-[0_18px_40px_-30px_rgba(16,32,58,0.6)]">
        <Image
          src="https://media.base44.com/images/public/6aef51b8d3f430ea0cca3ff1/93eb0cc57_generated_image.png"
          alt="A moedinha, mascote do Banco da Turminha"
          className="h-24 w-24 shrink-0 rounded-[18px]"
          fittingType="fit"
        />
        <div className="min-w-0 flex-1">
          <p className="font-heading text-sm font-bold leading-tight">Moedinhas que ensinam a cuidar</p>
          <p className="mt-1 text-[11px] leading-snug text-[#10203A]/50">
            Ganhou, gastou, guardou: tudo registrado pela professora e enviado para a família na sexta.
          </p>
        </div>
        <div className="w-24 shrink-0 rotate-[-7deg]">
          <CardCover variant="menta" holder="Lia" symbol="🐻" compact />
        </div>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2.5">
        {numbers.map(([n, l, dot]) => (
          <div key={l} className="rounded-2xl bg-white/70 px-4 py-3 brand-hairline">
            <span className="mb-1.5 block h-1.5 w-6 rounded-full" style={{ background: dot }} />
            <p className="font-display text-2xl leading-none" style={{ fontWeight: 1000 }}>
              {n}
            </p>
            <p className="mt-1 text-[11px] leading-snug text-[#10203A]/45">{l}</p>
          </div>
        ))}
      </div>
    </section>
  );
}