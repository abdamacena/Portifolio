import { ChevronRight } from 'lucide-react';
import ChildAvatar from '@/components/kid/ChildAvatar';
import SkillChip from '@/components/learning/SkillChip';
import { skillsOf } from '@/lib/learning';

export default function LearningRow({ kid, mark, onOpen }) {
  const skills = skillsOf(mark?.skills);

  return (
    <button
      type="button"
      onClick={onOpen}
      className="flex w-full items-center gap-3 rounded-[22px] bg-white px-3.5 py-3 text-left brand-hairline transition active:scale-[0.995]"
    >
      <ChildAvatar child={kid} size="sm" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm text-[#10203A]">{kid.nickname || kid.name}</p>
        {skills.length === 0 ? (
          <p className="mt-0.5 text-[11px] text-[#10203A]/40">Sem registro nesta semana</p>
        ) : (
          <div className="mt-1 flex flex-wrap items-center gap-1">
            {skills.slice(0, 3).map((s) => (
              <SkillChip key={s.id} skill={s} size="sm" />
            ))}
            {skills.length > 3 && (
              <span className="text-[10px] text-[#10203A]/40">+{skills.length - 3}</span>
            )}
          </div>
        )}
      </div>
      <ChevronRight className="h-4 w-4 shrink-0 text-[#10203A]/25" />
    </button>
  );
}