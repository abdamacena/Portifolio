import ChildAvatar from '@/components/kid/ChildAvatar';
import SkillChip from '@/components/learning/SkillChip';
import Logo from '@/components/brand/Logo';
import { formatMoney } from '@/lib/money';
import { learningSkills, skillsOf } from '@/lib/learning';

function Stat({ label, value, tone = '#10203A', bg = '#FFF8EF' }) {
  return (
    <div className="rounded-2xl px-3 py-2.5" style={{ background: bg }}>
      <p className="text-[9px] uppercase tracking-[0.16em]" style={{ color: tone, opacity: 0.7 }}>
        {label}
      </p>
      <p className="font-display text-lg leading-tight" style={{ fontWeight: 1000, color: tone }}>
        {value}
      </p>
    </div>
  );
}

export default function ClassProgress({ rows, className, weekText }) {
  const totals = rows.reduce(
    (acc, r) => ({ ganho: acc.ganho + r.ganho, gasto: acc.gasto + r.gasto, saldo: acc.saldo + r.saldo }),
    { ganho: 0, gasto: 0, saldo: 0 }
  );

  const marked = rows.filter((r) => (r.mark?.skills || []).length > 0);

  const counts = {};
  marked.forEach((r) => {
    (r.mark.skills || []).forEach((id) => {
      counts[id] = (counts[id] || 0) + 1;
    });
  });
  const ranking = learningSkills
    .filter((s) => counts[s.id])
    .sort((a, b) => counts[b.id] - counts[a.id]);
  const max = ranking[0] ? counts[ranking[0].id] : 1;

  const support = rows
    .map((r) => ({
      kid: r.kid,
      watch: skillsOf(r.mark?.skills).filter((s) => s.tone === 'watch'),
    }))
    .filter((r) => r.watch.length > 0);

  return (
    <div className="print-sheet rounded-[32px] bg-white p-5 brand-hairline sm:p-7">
      <div className="mb-5 flex items-start justify-between gap-4 border-b border-[#10203A]/10 pb-4">
        <div>
          <Logo size="sm" />
          <p className="mt-2 text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">
            Desempenho da turma · {className || 'turma'}
          </p>
        </div>
        <div className="text-right">
          <p className="text-[9px] uppercase tracking-[0.2em] text-[#10203A]/40">Semana</p>
          <p className="text-[12px]">{weekText}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Stat label="Acompanhadas" value={`${marked.length}/${rows.length}`} bg="#EAE6FF" tone="#6B5BD6" />
        <Stat label="Entrou" value={formatMoney(totals.ganho)} bg="#D4F7EE" tone="#0E9B80" />
        <Stat label="Saiu" value={formatMoney(totals.gasto)} bg="#FFE1DB" tone="#B23A28" />
        <Stat label="Saldo da turma" value={formatMoney(totals.saldo)} bg="#FFF1D6" tone="#10203A" />
      </div>

      <section className="mt-6">
        <h2 className="mb-2 font-heading text-[15px] font-bold">O que a turma praticou</h2>
        {ranking.length === 0 ? (
          <p className="rounded-2xl bg-[#FFF8EF] px-3 py-3 text-[12px] text-[#10203A]/50">
            Ninguém marcado nesta semana ainda. Comece pela aba “Marcar a semana”.
          </p>
        ) : (
          <ul className="space-y-1.5">
            {ranking.map((s) => (
              <li key={s.id} className="flex items-center gap-2">
                <span className="w-6 shrink-0 text-center text-sm">{s.emoji}</span>
                <span className="w-[130px] shrink-0 truncate text-[12px] text-[#10203A]/75">{s.label}</span>
                <span className="h-2 flex-1 overflow-hidden rounded-full bg-[#10203A]/6">
                  <span
                    className="block h-full rounded-full"
                    style={{
                      width: `${Math.max(8, (counts[s.id] / max) * 100)}%`,
                      background: s.tone === 'good' ? '#12C2A0' : '#FF6B57',
                    }}
                  />
                </span>
                <span className="w-6 shrink-0 text-right text-[11px] text-[#10203A]/45">{counts[s.id]}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {support.length > 0 && (
        <section className="mt-6 rounded-[22px] bg-[#FFF6F4] p-3.5">
          <h2 className="mb-1.5 font-heading text-[13px] font-bold text-[#B23A28]">
            Precisa de um empurrãozinho
          </h2>
          <ul className="space-y-1.5">
            {support.map(({ kid, watch }) => (
              <li key={kid.id} className="flex flex-wrap items-center gap-1.5 text-[12px]">
                <span className="mr-1 text-[#10203A]/70">{kid.nickname || kid.name}:</span>
                {watch.map((s) => (
                  <SkillChip key={s.id} skill={s} size="sm" />
                ))}
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="mt-6">
        <h2 className="mb-2 font-heading text-[15px] font-bold">Progresso de cada criança</h2>
        <div className="space-y-2.5">
          {rows.length === 0 && (
            <p className="py-4 text-center text-[12px] text-[#10203A]/45">Nenhuma criança na turma.</p>
          )}
          {rows.map(({ kid, ganho, gasto, saldo, mark }) => {
            const skills = skillsOf(mark?.skills);
            return (
              <div key={kid.id} className="print-break rounded-[22px] bg-[#FFFDF9] p-3 brand-hairline">
                <div className="flex items-center gap-2.5">
                  <ChildAvatar child={kid} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] text-[#10203A]">{kid.name}</p>
                    <p className="text-[10px] text-[#10203A]/45">
                      <span className="text-[#0E9B80]">+{formatMoney(ganho)}</span>
                      {' · '}
                      <span className="text-[#E04A36]">−{formatMoney(gasto)}</span>
                      {' · guardado '}
                      {formatMoney(saldo)}
                    </p>
                  </div>
                  <span className="shrink-0 rounded-full bg-[#10203A]/5 px-2 py-1 text-[10px] text-[#10203A]/50">
                    {skills.length} {skills.length === 1 ? 'marca' : 'marcas'}
                  </span>
                </div>

                {skills.length > 0 ? (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {skills.map((s) => (
                      <SkillChip key={s.id} skill={s} size="sm" />
                    ))}
                  </div>
                ) : (
                  <p className="mt-2 text-[11px] text-[#10203A]/40">Sem habilidades marcadas nesta semana.</p>
                )}

                {mark?.note && (
                  <p className="mt-2 rounded-xl bg-white px-2.5 py-2 text-[11px] italic leading-relaxed text-[#10203A]/60">
                    “{mark.note}”
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </section>

      <p className="mt-5 border-t border-[#10203A]/10 pt-3 text-[10px] leading-relaxed text-[#10203A]/40">
        As habilidades acima foram observadas pela professora durante a semana e também aparecem no extrato das
        famílias.
      </p>
    </div>
  );
}