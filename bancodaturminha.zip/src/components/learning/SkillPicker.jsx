import { useState } from 'react';
import { Loader2, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import Modal from '@/components/kid/Modal';
import ChildAvatar from '@/components/kid/ChildAvatar';
import { goodSkills, watchSkills } from '@/lib/learning';

function Group({ title, items, selected, onToggle }) {
  return (
    <div>
      <p className="mb-2 text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">{title}</p>
      <div className="flex flex-wrap gap-1.5">
        {items.map((s) => {
          const on = selected.includes(s.id);
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => onToggle(s.id)}
              aria-pressed={on}
              className={`flex items-center gap-1.5 rounded-full border px-3 py-2 text-[12px] transition ${
                on
                  ? s.tone === 'good'
                    ? 'border-[#12C2A0] bg-[#D4F7EE] text-[#0E7280]'
                    : 'border-[#FF6B57] bg-[#FFE1DB] text-[#B23A28]'
                  : 'border-[#10203A]/12 bg-white text-[#10203A]/65'
              }`}
            >
              <span aria-hidden="true">{s.emoji}</span>
              {s.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function SkillPicker({ child, mark, weekStart, classId, teacherUserId, onClose, onSaved }) {
  const [selected, setSelected] = useState(mark?.skills || []);
  const [note, setNote] = useState(mark?.note || '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  if (!child) return null;

  const toggle = (id) =>
    setSelected((prev) => (prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]));

  const save = async () => {
    setSaving(true);
    setError('');
    try {
      const payload = {
        child_id: child.id,
        child_name: child.name,
        class_id: classId,
        week_start: weekStart,
        skills: selected,
        note: note.trim(),
        teacher_user_id: teacherUserId,
      };
      const saved = mark?.id
        ? await base44.entities.LearningMark.update(mark.id, payload)
        : await base44.entities.LearningMark.create(payload);
      onSaved(saved);
    } catch (err) {
      setError(err?.message || 'Não foi possível salvar agora.');
    } finally {
      setSaving(false);
    }
  };

  const clear = async () => {
    if (!mark?.id) return onClose();
    setSaving(true);
    try {
      await base44.entities.LearningMark.delete(mark.id);
      onSaved(null);
    } catch (err) {
      setError(err?.message || 'Não foi possível apagar agora.');
      setSaving(false);
    }
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={child.nickname || child.name}
      subtitle="O que ela praticou nesta semana?"
    >
      <div className="mb-4 flex items-center gap-3 rounded-2xl bg-white px-3 py-2.5">
        <ChildAvatar child={child} size="sm" />
        <p className="text-[12px] leading-relaxed text-[#10203A]/55">
          Toque no que aconteceu. Dá para marcar mais de um.
        </p>
      </div>

      <div className="space-y-4">
        <Group title="Boas práticas" items={goodSkills} selected={selected} onToggle={toggle} />
        <Group title="Precisa de apoio" items={watchSkills} selected={selected} onToggle={toggle} />

        <label className="block">
          <span className="mb-1.5 block text-[10px] uppercase tracking-[0.2em] text-[#10203A]/40">
            Recado para a família (opcional)
          </span>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={3}
            placeholder="Ex.: juntou moedinhas para o adesivo da semana."
            className="w-full rounded-2xl border border-[#10203A]/12 bg-white px-3 py-2.5 text-[13px] outline-none focus:border-[#10203A]/40"
          />
        </label>

        {error && <p className="rounded-2xl bg-[#FFE1DB] px-4 py-3 text-[13px] text-[#B23A28]">{error}</p>}

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={save}
            disabled={saving}
            className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-[#10203A] px-6 py-3.5 text-sm text-[#FFF8EF] disabled:opacity-60"
          >
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            Salvar semana
          </button>
          {mark?.id && (
            <button
              type="button"
              onClick={clear}
              disabled={saving}
              className="inline-flex items-center gap-1.5 rounded-full border border-[#10203A]/15 px-4 py-3.5 text-[12px] text-[#10203A]/55"
            >
              <Trash2 className="h-3.5 w-3.5" /> Apagar
            </button>
          )}
        </div>
      </div>
    </Modal>
  );
}