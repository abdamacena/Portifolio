import { cn } from '@/lib/utils';

const tones = {
  good: 'bg-[#D4F7EE] text-[#0E7280] ring-[#12C2A0]/40',
  watch: 'bg-[#FFE1DB] text-[#B23A28] ring-[#FF6B57]/40',
};

export default function SkillChip({ skill, size = 'md', className }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full ring-1',
        size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-[11px]',
        tones[skill.tone] || tones.good,
        className
      )}
    >
      <span aria-hidden="true">{skill.emoji}</span>
      {skill.label}
    </span>
  );
}