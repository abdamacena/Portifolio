import { GraduationCap, Home, Sparkles } from 'lucide-react';

const teacher = [
  'Marque as habilidades na sexta-feira: abra Desempenho, toque na criança e marque o que ela fez na semana.',
  'Use o que você já viu em sala como prova: guardou moedinhas no lanche? marque “Guardou”.',
  'Imprima o relatório e escreva à mão um destaque e um próximo passo para cada criança.',
  '“Precisa de apoio” não é castigo: é convite para repetir a experiência com ajuda.',
];

const family = [
  'O extrato da família mostra as mesmas habilidades que você marcou aqui.',
  'Pergunte em casa: “o que você guardou essa semana?” — a conversa vale mais que a moedinha.',
  'Combine um objetivo pequeno (um adesivo, um passeio) e registrem as tarefas de casa no site.',
  'Se aparecer “comprou por impulso”, combine uma espera de um dia antes da próxima compra.',
];

function Column({ icon: Icon, color, bg, title, items }) {
  return (
    <div className="rounded-[24px] bg-[#FFFDF9] p-4 brand-hairline">
      <div className="flex items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-xl" style={{ background: bg, color }}>
          <Icon className="h-4 w-4" />
        </span>
        <p className="font-heading text-[13px] font-bold leading-tight">{title}</p>
      </div>
      <ul className="mt-2.5 space-y-2">
        {items.map((text) => (
          <li key={text} className="flex gap-2 text-[12px] leading-relaxed text-[#10203A]/60">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: color }} />
            {text}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function FollowTips() {
  return (
    <div className="no-print mt-5">
      <div className="mb-2 flex items-center gap-2">
        <Sparkles className="h-4 w-4 text-[#FFB627]" />
        <h2 className="font-heading text-[15px] font-bold">Como acompanhar junto</h2>
      </div>
      <div className="grid gap-2.5 sm:grid-cols-2">
        <Column
          icon={GraduationCap}
          color="#8B7CF6"
          bg="#EAE6FF"
          title="Para a professora"
          items={teacher}
        />
        <Column icon={Home} color="#0E9B80" bg="#D4F7EE" title="Para as famílias" items={family} />
      </div>
    </div>
  );
}