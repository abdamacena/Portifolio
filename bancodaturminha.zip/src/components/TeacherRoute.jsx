import { useEffect, useState } from 'react';
import { Link, Outlet } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import AccountPill from '@/components/AccountPill';

export default function TeacherRoute() {
  const { user, logout } = useAuth();
  const [state, setState] = useState('checking');

  useEffect(() => {
    let alive = true;
    (async () => {
      if (!user) return;
      if (user.role === 'admin') {
        setState('teacher');
        return;
      }
      const total = await base44.entities.Turma.count({});
      if (!alive) return;
      if (total > 0) {
        setState('teacher');
        return;
      }
      // Ainda sem turma: só barra se a conta tiver criança vinculada (conta de família).
      let hasKids = false;
      try {
        const res = await base44.functions.invoke('extratoFamilia', {});
        hasKids = (res.data?.children || []).length > 0;
      } catch {
        hasKids = false;
      }
      if (!alive) return;
      setState(hasKids ? 'family' : 'teacher');
    })();
    return () => {
      alive = false;
    };
  }, [user]);

  if (!user) return null;

  if (state === 'checking') {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#FFF8EF]">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
      </div>
    );
  }

  if (state === 'teacher') return <Outlet />;

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#EDE3D3] px-5">
      <div className="w-full max-w-[360px] rounded-[28px] bg-[#FFF8EF] p-6 text-center">
        <AccountPill label="Família" />
        <h1 className="mt-3 font-display text-[1.6rem] leading-tight tracking-[-0.03em]">
          Esta parte é da professora.
        </h1>
        <p className="mt-2 text-[13px] leading-relaxed text-[#10203A]/55">
          Você entrou com a conta da família{user?.email ? ` (${user.email})` : ''}. Por ela você vê o extrato e as
          tarefas da sua criança.
        </p>
        <Link
          to="/familia"
          className="mt-4 flex h-12 items-center justify-center rounded-2xl bg-[#10203A] text-sm text-[#FFF8EF]"
        >
          Ir para a área da família
        </Link>
        <button
          type="button"
          onClick={() => logout(true)}
          className="mt-2 flex h-11 w-full items-center justify-center rounded-2xl border border-[#10203A]/15 text-sm text-[#10203A]/65"
        >
          Sair e entrar com a conta da professora
        </button>
      </div>
    </div>
  );
}