import { Outlet } from 'react-router-dom';
import SiteNav from '@/components/brand/SiteNav';
import SiteFooter from '@/components/brand/SiteFooter';
import ClassBar from '@/components/class/ClassBar';
import FirstClass from '@/components/class/FirstClass';
import { ClassProvider, useClassroom } from '@/lib/ClassContext';

function TeacherShell() {
  const { loading, active } = useClassroom();

  return (
    <div className="min-h-screen bg-[#FFF8EF] font-body text-[#10203A]">
      <SiteNav />
      <ClassBar />
      <main>
        {loading ? (
          <div className="flex min-h-[50vh] items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#FFB627]/30 border-t-[#FFB627]" />
          </div>
        ) : active ? (
          <Outlet />
        ) : (
          <FirstClass />
        )}
      </main>
      <SiteFooter />
    </div>
  );
}

export default function Layout() {
  return (
    <ClassProvider>
      <TeacherShell />
    </ClassProvider>
  );
}