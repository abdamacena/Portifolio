import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Navigate, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import TeacherRoute from '@/components/TeacherRoute';
import Layout from '@/components/Layout';
import Entrar from '@/pages/Entrar';
import Home from '@/pages/Home';
import Cartoes from '@/pages/Cartoes';
import Cadastro from '@/pages/Cadastro';
import AppMockups from '@/pages/AppMockups';
import Ler from '@/pages/Ler';
import Alunos from '@/pages/Alunos';
import Aluno from '@/pages/Aluno';
import Relatorios from '@/pages/Relatorios';
import Marca from '@/pages/Marca';
import Site from '@/pages/Site';
import Professora from '@/pages/Professora';
import Familia from '@/pages/Familia';
import Tarefas from '@/pages/Tarefas';
import Desempenho from '@/pages/Desempenho';
import Painel from '@/pages/Painel';
import Turmas from '@/pages/Turmas';
import Login from '@/pages/Login';
import CadastroProfessora from '@/pages/CadastroProfessora';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Mfa from '@/pages/Mfa';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/cadastro-professora" element={<CadastroProfessora />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/mfa" element={<Mfa />} />
      <Route path="/" element={<Site />} />
      <Route path="/entrar" element={<Entrar />} />
      <Route path="/professora" element={<Professora />} />
      <Route path="/site" element={<Navigate to="/" replace />} />
      <Route path="/familia" element={<Familia />} />

      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<TeacherRoute />}>
          <Route element={<Layout />}>
          <Route path="/inicio" element={<Home />} />
          <Route path="/ler" element={<Ler />} />
          <Route path="/alunos" element={<Alunos />} />
          <Route path="/alunos/:id" element={<Aluno />} />
          <Route path="/relatorios" element={<Relatorios />} />
          <Route path="/desempenho" element={<Desempenho />} />
          <Route path="/painel" element={<Painel />} />
          <Route path="/tarefas" element={<Tarefas />} />
          <Route path="/turmas" element={<Turmas />} />
          <Route path="/cartoes" element={<Cartoes />} />
          <Route path="/cadastro" element={<Cadastro />} />
          <Route path="/marca" element={<Marca />} />
          <Route path="/app" element={<AppMockups />} />
          </Route>
        </Route>
      </Route>

      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App